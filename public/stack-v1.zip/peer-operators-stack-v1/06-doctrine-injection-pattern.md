# Skill 06: Doctrine Injection Pattern

A two-prompt sequence for any craft task (copy, headlines, voice, ads, proposals, contract review). Prompt one loads canon and forces the model to dissect the techniques. Prompt two generates using the dissected techniques. The dissection step is load-bearing; skipping it produces base-model-flavored output.

## When to use

Use this on any task where the difference between "good" and "shippable" is craft, not facts. Cold model output on a craft task tends to land in the bland middle of the training distribution. Doctrine Injection moves the model toward a specific tradition (yours, a teacher's, a school of thought) before generation begins.

Concrete triggers:

- Writing landing-page copy
- Drafting cold-outbound messages
- Composing ads, headlines, taglines, or hooks
- Editing a draft for voice rather than substance
- Reviewing a contract against a particular school's negotiation principles

## Step-by-step

### Prompt 1: Dissect

Load 2 to 4 canonical sources for the craft. For each, hand them to the model and ask it to extract:

- The 3 to 5 techniques the author uses repeatedly
- Specific passages that show each technique in action
- The principle underneath (what the author believes about the reader)
- The anti-pattern (what the author refuses to do)

Save the dissection output. Re-use it across multiple generation runs in the same session: you only have to pay for it once.

### Prompt 2: Generate

Start a fresh context (or new turn that explicitly references the saved dissection). Provide:

- The dissection from Prompt 1
- The brief for what you're writing
- The constraint: "Use the techniques in the dissection. When in doubt, follow the anti-pattern guidance."

Generate. Critique the output against the dissection. Iterate.

## Canon source examples

| Craft | Canon to load |
|---|---|
| Cold outbound | A few high-converting cold emails from a known operator; one chapter from a classic on direct mail |
| Long-form copy | One Eugene Schwartz piece; one Gary Halbert letter; one modern landing page you admire |
| Voice (your own) | Three of your own pieces you're proud of; one piece by a writer whose voice you've borrowed from honestly |
| Proposals | Two proposals you've sent that closed; the relevant section of *The Win Without Pitching Manifesto* |
| Contract review | A redline of a contract you negotiated well; the relevant chapter in a negotiation book |

Keep canon in `~/.claude/canon/<craft>/` so the dissection prompt has stable paths to load from.

## Why the dissection step

A cold prompt that says "write in the style of X" produces an impression of X based on training averages. The dissection step changes the model's working set: it now has explicit techniques in context, paired with the principle behind each technique, paired with examples. Generation pulls from this working set, not from training-distribution priors. The output gets noticeably closer to the canon source. The difference is reproducible enough to be worth the extra prompt.

## Underlying philosophy

Banked from Dennis DeMarino's "Doctrine Injection" pattern. The model isn't bad at craft; it's been trained on too many priors that pull toward the mean. Injecting doctrine narrows the prior. The model becomes a competent instance of a specific tradition rather than a competent average of all traditions.

## Before / after

Before: "Write a cold email to a fintech founder." The model produces something polite, generic, and indistinguishable from a hundred others.

After: Prompt 1 dissects three cold emails from a single operator known for high-conversion outbound. The dissection surfaces: "opens with a specific observation, not a compliment; names a cost the reader is already paying; offers one concrete next step." Prompt 2 generates a cold email and the result reads like the canon, not like the model's idea of cold email.

## Adaptation

- Build your canon library incrementally. One craft per month is plenty. After a year you have 12 well-stocked craft folders
- The dissection output is reusable across many generation runs in the same craft. Don't redo it every time. Save it to `~/.claude/canon/<craft>/_dissection.md` once the dissection feels stable
- Pair with Skill 05 (voice linter): Doctrine Injection gets the draft into the right tradition; the linter scrubs the banned tokens before ship
