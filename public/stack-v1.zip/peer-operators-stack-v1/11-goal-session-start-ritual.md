# Skill 11: /goal Session-Start Ritual

A short ritual that opens every significant build session by naming the completion condition. The agent works toward the named goal across turns rather than drifting from prompt to prompt. The ritual is three steps: name the goal, plan it, then accept managed-outcome grading where it applies.

## When to use

Use this on any session that will produce code, a deliverable, or a non-trivial document. Skip it for tiny edits, info lookups, and chat-style exploration. The ritual takes about three minutes; for a session that will run thirty minutes or more, the cost pays back many times over.

Concrete triggers:

- Starting a feature implementation
- Starting a multi-step research task
- Beginning a writing session for a deliverable longer than a paragraph
- Picking up work from a previous session where you lost context

## The ritual: three steps

### Step 1: /goal

State the completion condition Claude will work toward across turns. Format:

```
/goal <one-sentence outcome>

Done when:
- <specific, observable, checkable outcome 1>
- <outcome 2>
- <outcome 3>

Out of scope:
- <thing you might be tempted to do but won't>
- <thing you'd otherwise gold-plate>
```

The "Done when" list is the contract. The "Out of scope" list is the protection against drift.

### Step 2: Plan Mode

Have the agent produce a read-only plan before any mutation. The plan lists:

- The files it will touch
- The order it will work in
- The verification it will run at each step
- The assumptions it's making that the user should confirm before code starts

You read the plan. You either approve it as-is or push back. No code gets written until you've approved the plan.

### Step 3: Managed Outcomes (where applicable)

For tasks with clear pass/fail criteria (tests, evals, parseable outputs), define the grader. The grader is a checker the agent runs after each iteration; it either passes (move on) or fails with a specific reason (the agent retries against that reason).

This step is optional. Skip it for prose work, exploratory tasks, and creative outputs where the grader is "your judgment."

## Why each step matters

**/goal** stops drift. Without a stated goal, the agent reasonably interprets each turn as a fresh request. Across a long session, this produces work that wanders.

**Plan Mode** stops premature mutation. Most session-failure modes start with the agent writing code before alignment. The plan surfaces the alignment failure cheaply, before any code exists to fix.

**Managed Outcomes** stops shallow verification. When a grader exists, the agent has to satisfy a checkable condition, not just generate something that looks done.

## Underlying philosophy

Banked from the Anthropic May 2026 release plus the Superpowers methodology lock. The session-start ritual is what turns the agent from a turn-taker into a goal-pursuer. The cost is three minutes of friction. The return is sessions that produce the named outcome instead of an interesting but not-quite-it artifact.

The ritual also pairs cleanly with the gap-analysis workflow used in any project's safety net. The gap analysis surfaces unstated assumptions; the goal locks the assumptions you've decided to honor.

## Adaptation

- For solo operators on small tasks, the ritual can collapse to a one-sentence goal in your head. For anything you'll re-touch tomorrow, write it down
- For teams, the goal becomes the artifact you commit to git at the start of the session. It's the contract you can refer back to in async review
- For long sessions (multi-day projects), re-run the ritual at the start of each new day. The goal you wrote yesterday is yesterday's goal; today's may be narrower or wider
- The "Out of scope" list earns its keep most. Most session drift is "while we're here, let's also..." Writing the boundary down at the start makes it cheap to honor

## Before / after

Before: Session opens with "okay, let's build the auth flow." Six hours later you have an auth flow that works, a refactor of the user model nobody asked for, three new utility functions, and the original test suite is now red because someone changed an unrelated import.

After: Session opens with /goal "Ship login + signup with Supabase Auth. Done when: e2e test passes for both flows, no other tests break, README has the env var list. Out of scope: user model refactor, social login, password reset." Six hours later you have login + signup, green tests, updated README, and the user-model refactor is in `_handoff.md` as a banked item.
