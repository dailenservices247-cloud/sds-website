# Skill 08: Drop-Overclaim Editing Pass

A single-pass edit you run on a draft after first-draft is done. The pass strips overclaim, softens unprovable assertions, and replaces hype with specifics. Treats overclaim as a class of bug, not a stylistic preference.

## When to use

Use this on any draft that will ship under your name and is making claims about outcomes, transformations, results, or status. The first draft is where you write what you mean. The Drop-Overclaim pass is where you check what you wrote against what you can defend.

Concrete triggers:

- Landing page copy with words like "transform," "10x," "game-changing"
- Case studies where outcomes might be overstated
- Cold outreach that promises results
- Bio copy or "about" pages where status claims appear
- Any post that uses superlatives ("best," "most," "fastest")

## The pass: six checks

Run these in order. Each takes about 30 seconds per paragraph.

### 1. Numeric claims

For every number in the draft, ask: can I cite the source in one sentence if challenged? If no, soften ("around 200" instead of "200 exactly") or remove. "3x" is the most-abused number on the internet; delete or substantiate.

### 2. Superlatives

Every "best," "most," "fastest," "first" earns a justification or gets deleted. If you can't beat "the best in the space" with one sentence of evidence, you're overclaiming. Replace with the specific thing you can defend ("the only one that ships with a banned-words list" instead of "the best banned-words tool").

### 3. Outcome promises

Any sentence that promises a reader outcome ("you'll save 10 hours," "you'll close more deals") needs either a citation, a hedge, or deletion. The honest replacement names the mechanism rather than the outcome ("the lint catches the banned tokens; whether you close more deals depends on a lot more than that").

### 4. Transformation language

Words like "transform," "revolutionize," "unlock," "10x" almost never survive this check. Most "transformations" are workflow upgrades. Most "10x" is "1.4x with better instrumentation so it feels like more." Name the actual change in concrete terms.

### 5. Status claims

"World-class," "industry-leading," "top," "elite." If a third party hasn't said this about you, you can't say it about yourself in copy. Drop or replace with the work that earned the status ("we ran 47 of these reviews last quarter" instead of "industry-leading review service").

### 6. Universal quantifiers

"Always," "never," "everyone," "no one." Almost all of these are false at the edges. Replace with the honest scope ("for the operators we've worked with" instead of "for everyone").

## Why this is a separate pass

It is tempting to do this during first-draft. Don't. The first-draft brain wants to write the claim; the editing brain wants to test it. Separate the two so each can do its job. If you try to overclaim-check while drafting, you'll write defensively and the draft will lose momentum. If you try to draft while overclaim-checking, you'll lose specificity.

The pass also pairs cleanly with the linter (Skill 05) and the banned-words list (Skill 07). The linter handles the lexical layer; this pass handles the semantic layer. They catch different bugs.

## Before / after

Before: "Our system unlocks 10x productivity for AI consultants, transforming how they work with their stacks. It's the industry-leading way to ship faster."

After: "The system catches three classes of friction we saw repeatedly in our own work: handoff drift, voice slop, and skill-discovery loss. It's been used by us and 18 other operators across the last quarter. Most reported saving an hour or two per week on the first two; the third is harder to measure."

The second version is less impressive on first read and more impressive on second read. That's the trade you want.

## Underlying philosophy

Overclaim is a tax on trust. Each unsupported claim costs you a small amount of credibility with the reader who notices, and most readers notice more than copywriters assume. The honest, scoped, specific claim feels less impressive but compounds better. The Drop-Overclaim pass is the discipline of paying that tax explicitly during editing instead of letting it be charged silently to your reputation.

## Adaptation

- For social posts, run a compressed version of this pass (numeric + transformation + status). The whole pass is overkill for a 200-character post
- For long-form essays, run the full pass twice: once on the first draft, once on the final
- Build a checklist as a `.md` file you keep next to your draft. The 30 seconds of overhead per paragraph saves the post-publish revision cost
- Pair with a trusted reader who has explicit permission to flag overclaim in your drafts. The pass catches most; a second pair of eyes catches the rest
