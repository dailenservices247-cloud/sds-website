# Skill 01: Atomic Node Template

A single-claim memory unit. Each decision, inference, snapshot, or test is its own typed markdown file with frontmatter that links it into a graph of nodes you can later traverse.

## When to use

Use this any time you would otherwise add a paragraph to a long-running "decisions log" or "notes" file. The moment a thought is worth the cost of writing down, it is worth the cost of writing down atomically. The cost is small. The compounding return is large because nodes you author this month become retrievable next month without you remembering they exist.

Concrete triggers:

- A decision was just locked in a session and you would have written one line in a journal
- An inference about how a system, market, or user behaves was just formed
- A snapshot of the current state of a project would be useful to compare against in a quarter
- A test outcome (eval, experiment, dry run) produced a result worth keeping

## Step-by-step

1. Open `AI Hub/Decisions/`, `AI Hub/Inferences/`, `AI Hub/Contexts/`, or `AI Hub/Tests/` depending on the type
2. Create a new file named `<type>-YYYY-MM-DD-<slug>.md`
3. Paste the frontmatter and body skeleton (below)
4. Fill exactly one claim, one decision, or one observation. If you find yourself wanting two, write two files
5. Link backwards via `derived_from`, `supports`, `contradicts`, `related_to` to the IDs of older nodes
6. Update the rolling index (`Decisions Log.md`, `Inferences Log.md`) with a one-line entry plus a link to this node

## Frontmatter skeleton

```
---
id: <type>-YYYY-MM-DD-<slug>
type: decision | inference | context | test
date: YYYY-MM-DD
summary: <one sentence, under 140 chars>
authored_by: <you>
supports: []
derived_from: []
contradicts: []
related_to: []
---

## Context
What was true before this node existed.

## Decision / Inference / Snapshot / Test
The single claim.

## Why this over alternatives
What you considered and rejected, briefly.

## Status
draft | pilot | locked | superseded
```

## Underlying philosophy

This pattern is lifted from the AI Impact "Infinite Brain" approach. The behavior change is moving from prose-style journals (which the future agent has to skim and summarize) to graph-style nodes (which the future agent can pull by ID, type, or relationship). Prose journals decay because the cost of finding the right paragraph six months later is too high. Atomic nodes do not decay because each node carries its own retrieval handles.

Pairs with Skill 02 (Retrieval Contract): the contract is what tells the agent which nodes to pull and when. Pairs with Skill 03 and Skill 04 (rolling indexes): those keep the human-readable browse view alive while the atomic store grows underneath.

## Before / after

Before: `Decisions Log.md` is a 1,200-line file. To find what was decided about pricing in March, you Ctrl-F "pricing" and skim. The agent doing the same lookup burns 4k tokens reading paragraphs that mention pricing in passing.

After: `Decisions/decision-2026-03-08-pricing-tier-149.md` is 200 words. The rolling index has one line: `2026-03-08: Locked $149 price for Peer Operator's Stack v1 → decision-2026-03-08-pricing-tier-149.md`. The agent reads the index, then loads only the relevant node.

## Adaptation

You can use this without the rest of the stack. Pick one type to start (decisions are easiest), commit to atomic nodes for 30 days, then expand to inferences. Do not migrate your back catalog up front. Let it grow forward and let the old journal age out naturally. Tools-of-choice (Obsidian, plain VS Code, Notion) do not matter; what matters is that each node lives at its own URI so the agent can resolve a single one without reading the whole journal.
