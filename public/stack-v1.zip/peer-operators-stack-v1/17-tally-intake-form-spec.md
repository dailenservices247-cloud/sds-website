# Skill 17: Tally Intake Form Spec

A 13-question intake form a paid client fills before the kickoff call. Designed to collect the context that makes the call useful: stack, problem framing, prior attempts, decision authority. Avoids the questions that should happen on the call itself.

## When to use

Use this for any paid engagement where you need context before a call to make the call worth the price. The intake replaces the "tell me about your business" warm-up that wastes the first 15 minutes of a paid call. The cost to the buyer is 10-15 minutes pre-call. The return for both of you is a 90-minute call that gets right to the work.

Concrete triggers:

- Paid strategy or audit call ($500+)
- Coaching or consulting kickoff
- Any session where you'll be giving recommendations that depend on the client's specific stack or situation

## The form: 13 questions

Build this in Tally (or Typeform, or Google Forms: Tally has the cleanest free tier and a good redirect-to-confirmation flow).

### Section 1: Who and what (questions 1-3)

1. **Your name and role**
   *Short text*

2. **Company name and a one-line description**
   *Short text. Example: "Acme Bookkeeping: automated bookkeeping for SaaS startups"*

3. **Where you are in your stage**
   *Multiple choice, single select:*
   - Pre-product (still building)
   - Early product, under $10k MRR
   - $10k-$100k MRR
   - $100k+ MRR
   - I run this as a service business, not a product

### Section 2: The stack (questions 4-7)

4. **What AI tools are you running today?**
   *Long text. Probe: "List the agents, MCPs, automations, copilots, and AI products you use in your day-to-day. No need to be exhaustive: list what you actually open in a week."*

5. **What's working in your stack right now?**
   *Long text. Probe: "One paragraph on what you'd be sad to lose."*

6. **What's not working, or has been frustrating, in the last 30 days?**
   *Long text. This is the most-load-bearing question. The honest answer here drives most of the call.*

7. **Have you tried fixing the not-working part? If yes, what did you try?**
   *Long text. Filters out problems already in motion vs. problems you've been avoiding.*

### Section 3: The work (questions 8-10)

8. **What outcome would make this call clearly worth your money?**
   *Long text. The buyer's version of /goal. Tells you what to land on.*

9. **What outcome would feel like a soft win: useful but not transformative?**
   *Long text. The fallback target if the swing-for-the-fences outcome isn't reachable on the call.*

10. **What's the budget context for any follow-up work, if it makes sense?**
    *Multiple choice, single select:*
    - Under $1k/month
    - $1k-$5k/month
    - $5k-$15k/month
    - $15k+/month
    - Not budgeting for follow-up right now

### Section 4: Decision authority and constraints (questions 11-13)

11. **Are you the decision-maker for changes to your AI stack?**
    *Single select: Yes / Mostly, with one or two stakeholders / No: I'll need to bring back recommendations*

12. **Any constraints I should know about? (regulatory, vendor lock-in, team capacity, internal politics)**
    *Long text. Catches the things that would invalidate a recommendation if I didn't know.*

13. **Anything else you want me to know before the call?**
    *Long text. Open-ended. Often the most valuable question.*

## Why each question earns its keep

- **1-3** establish baseline. Without these the call's first 5 minutes are wasted on context-setting
- **4-7** map the stack. The "what's not working" question is the spine of the entire call
- **8-9** lock the success criteria. The split between swing-for-the-fences and soft-win is the version of /goal scoped to the buyer's perspective
- **10** prevents the awkward end-of-call "so what about ongoing?": you know whether a follow-up makes sense before pitching it
- **11-13** catch the failures of recommendations that don't survive contact with the org

## What's deliberately NOT on the form

- Anything about competitors ("who else have you talked to?"): feels interview-y, low value
- Long open-ended "tell me about your vision": wastes their time, you can ask on the call if you need to
- Multiple-choice grids of tool checkboxes: long text gets you better signal than checking boxes
- Pricing pre-qualification at this stage (other than budget bucket): you've already collected payment

## Setup in Tally

1. Build the form in Tally with the 13 questions above
2. Configure the response email to land at your inbox + auto-thread to the client's email (Tally supports both)
3. Add the form link to the Stripe `hosted_confirmation` message (Skill 16) so it appears immediately after payment
4. Pre-fill the email field via Tally's URL parameter: `?email={{invitee_email}}` if you pass it through Calendly's confirmation redirect

## Underlying philosophy

A paid call is leverage on context. The more context the operator has going in, the more useful the call is. The intake form is the cheapest possible way to load that context: async, on the buyer's time, before the meter starts. Most operators skip this step and start every call from zero. Fixing that single failure mode is worth most of the cost difference between a $500 call and a $1,500 call.

## Adaptation

- For shorter engagements ($200-$500 calls), trim to 7 questions. Drop the budget question and the follow-up planning questions
- For longer engagements ($2,500+ or multi-session), add a calendar-availability question and a stakeholder list question
- For non-AI domains, swap section 2 wording (e.g., "marketing stack," "ops stack") but keep the structure
- The "what's not working" question is sacred. Don't drop it. Every shortcut to a useful call routes through that answer
