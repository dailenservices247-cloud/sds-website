# Skill 09: Find-Skill Router

A gateway router that enumerates installed skills, scores them against the user's request, and recommends the top 1 to 3 with rationale and invocation hints. Solves the "I have too many skills to remember which one fits" problem.

## When to use

Use this when you've crossed the threshold where the installed skill set is bigger than your working memory. The threshold is around 15 to 20 skills for most operators. Past that, the cognitive cost of remembering which skill fits which task starts to dominate the benefit of having skills at all.

Concrete triggers:

- A task could match multiple installed skills and you're unsure which to call
- You're starting a multi-step workflow where skill chaining would help
- A teammate or contractor needs to use your skill set without having memorized it
- You've added a new skill and want to test that routing still picks the right one

## How it works (algorithm)

### Step 1: Enumerate installed skills

Read SKILL.md files from all three locations Claude Code resolves at runtime:

- `~/.claude/plugins/cache/<marketplace>/<plugin>/<version>/skills/*/SKILL.md`
- `~/.claude/plugins/cache/<marketplace>/<plugin>/<version>/SKILL.md`
- `~/.claude/skills/*/SKILL.md`

```bash
find ~/.claude/plugins/cache -maxdepth 6 -name SKILL.md 2>/dev/null
find ~/.claude/skills -maxdepth 2 -name SKILL.md 2>/dev/null
```

Parse the YAML frontmatter from each file. Extract `name` and `description`. Skip files where either is missing.

### Step 2: Score each candidate (0 to 100)

- **Keyword overlap** (40 pts): direct token matches between the user's request and the skill's name + description. Weight noun phrases heavier than common verbs
- **Intent match** (40 pts): does the skill's stated trigger language line up with the user's actual job? A request to "score a feature backlog" matches `feature-prioritize` on intent even if no exact keywords overlap
- **Scope fit** (20 pts): is the skill's granularity right for the task? A one-line question shouldn't route to a multi-hour workflow

Anything below 50 is too weak to recommend.

### Step 3: Rank and cap at 3

Sort descending by score. Take the top 3 that score 50 or higher. If only 1 or 2 clear the bar, return only those.

### Step 4: Output format

```
# Skill routing for: <restatement of the user's task>

## Top matches

| Rank | Skill | Why it fits | How to invoke |
|------|-------|-------------|---------------|
| 1 | `<name>` | <one-sentence rationale> | `/<name>` |
| 2 | ... | ... | ... |
| 3 | ... | ... | ... |

## Recommendation
<one sentence picking the best fit, or noting that two should chain>
```

## No-match rule

If no candidate scores 50 or higher, do not invent a recommendation. Return:

```
# Skill routing for: <task>

No installed skill scored a confident match. The closest candidates were:
- <name> (score: N) <one line on why it almost fit>

You can proceed without a skill, or author a new one via skill-creator.
```

A bad recommendation costs more than no recommendation, because it sends the user down a path that wasn't built for their problem.

## Anti-patterns

- Don't invent skills that don't exist. Only recommend skills whose SKILL.md you read in step 1
- Don't recommend a skill the user said NOT to use (honor exclusions)
- Don't return more than 3 matches
- Don't route to multi-hour workflows for one-line questions
- Don't pad rationale with marketing language

## Underlying philosophy

Two design choices matter here:

**Index the installed set, not the global universe.** The point of routing is to recommend something the user has access to, not something that exists somewhere in the world. The router scans local skills only.

**Deterministic rationale step.** Claude Code already auto-selects skills via descriptions. The value of this router is the explicit rationale the user sees, so misroutes are catchable before the skill runs.

## Adaptation

- For solo operators with under 15 skills, this router is overkill. Memorize them and move on
- For teams or for operators with 25+ skills, the router becomes the entry point to skill use rather than a fallback
- The scoring weights are tunable. If you find the router over-fitting to keyword matches, lower the keyword weight to 30 and raise intent to 50
- The full skill text is in the canonical `find-skill/SKILL.md` shipped with this Stack at `~/.claude/skills/find-skill/SKILL.md`

## Before / after

Before: User asks "I need to plan out the next quarter's roadmap." Operator runs through skills mentally, picks `roadmap-update`, runs it. Two days later they realize `feature-prioritize` would have ranked the candidates first and the planning would have been cleaner. Time lost.

After: User asks the same. Find-Skill returns: rank 1 `feature-prioritize`, rank 2 `roadmap-update`, recommendation: "chain: prioritize first, then update roadmap with the ranked list." Two days saved.
