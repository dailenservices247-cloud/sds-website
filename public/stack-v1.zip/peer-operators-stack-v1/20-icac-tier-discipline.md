# Skill 20: ICAC Tier Discipline (Full / Light / No)

A three-tier ingest discipline for sources entering your memory system. Full tier means the source gets the complete treatment (atomic-node authoring, retrieval registration, index entry). Light tier means a one-line capture. No tier means consciously dropping the source. The discipline keeps the memory system from drowning in every URL you saw this week.

## When to use

Use this any time a source crosses your desk that's tempting to ingest. The temptation is to ingest everything; the cost is a memory system that becomes unsearchable. ICAC forces an explicit tier decision before ingest happens, which keeps the noise floor low.

Concrete triggers:

- A YouTube video you watched and want to bank
- A long-form article you read and want to remember
- A podcast episode worth referencing later
- A book chapter, a Slack thread, a Twitter thread, a paper, a Loom

The ICAC name: "Ingest, Capture, And Categorize": but the action is more honest as "decide the tier first."

## The three tiers

### Full tier: the source earns a node

Use when the source meaningfully changes a decision, an inference, or your view of how something works. Full-tier ingest:

1. Watch / read the source end-to-end
2. Extract 1-3 banked items as atomic nodes (one decision or inference per node)
3. Register the source in `AI Hub/Inventories/sources.md` with date, URL, summary
4. Update the relevant rolling index (Skill 03 or 04)
5. Link the new nodes to existing nodes they support, contradict, or relate to

Cost: 30-60 minutes per source. Use sparingly. Expect maybe 5-10 Full-tier sources per month.

### Light tier: the source earns a one-line capture

Use when the source is interesting but not immediately load-bearing. Light-tier ingest:

1. Add one line to `AI Hub/Inventories/lightweight-sources.md`:

```
- **YYYY-MM-DD** — <source title>, <author> — <URL> — *banked: <one-sentence why it matters>*
```

2. Stop. No atomic nodes. No index updates. The one-liner is the whole capture

Cost: 60 seconds per source. Most sources land here. Expect 5-20 Light-tier sources per week.

### No tier: the source gets consciously dropped

Use when the source is interesting in the moment but does not earn a place in your memory. No-tier discipline:

1. Close the tab
2. Don't bank, don't bookmark, don't add to read-later
3. If it really matters, it'll surface again from another angle and you can re-evaluate

Cost: zero. This is the highest-volume tier and the one operators skip most often, which is why their read-later lists become graveyards.

## How to decide the tier

Ask one question: "If I never saw this source again, would the answer to my actual current question still be reachable?"

- **No, this source is the only path to the answer** → Full tier
- **Yes, but having a pointer would speed up next time** → Light tier
- **Yes, easily, this is a confirmation of what I already think** → No tier

Most sources are No tier. Most operators tier them as Light. Most "Light" sources never get re-read.

## Why this exists

Memory systems fail in two ways: empty (no signal) and full of noise (signal exists but is unfindable). Operators with disciplined memory practices usually fail the second way: they ingest everything, the system becomes a swamp, and finding the one decision they wrote down two months ago takes longer than it would have to re-derive it from scratch.

The tier discipline keeps the signal-to-noise ratio high by forcing the tier decision before ingest. The forcing function matters; without it the default is "Light, just in case" which is functionally indistinguishable from "Full" once the volume scales.

## Underlying philosophy

The honest answer to "should I bank this?" is usually "no." The default of "yes, just in case" is what makes memory systems collapse. ICAC formalizes the "no" as a real tier so it doesn't feel like a failure to ingest. Choosing No tier is an active act of curation, not a passive miss.

Pairs with retrieval contracts (Skill 02). The contract tells the agent what to pull; the tier discipline keeps the pull-able set small enough to be useful.

## Adaptation

- For research-heavy weeks (you're reading a lot in a new domain), expect the Full / Light ratio to skew briefly. Reset it after the deep-dive ends
- For team operations, the tier discipline lives best as a shared norm. "Tier this before you bank it" becomes a team phrase
- The 30-day audit catches drift: scroll back through the last 30 days of Light-tier captures. How many did you re-reference? If the answer is under 10%, your tier discipline is loose and Light is doing the work of No

## Before / after

Before: Operator has 800 saved articles in Pocket, 200 banked items in Obsidian, and a "things to come back to" folder with 1,400 PDFs. They never use any of it. They write a new strategy doc that re-derives an idea that's been banked three times.

After: Operator banks 8 Full-tier nodes in 30 days. 25 Light-tier captures. Drops about 80 No-tier sources without remorse. When they need to find the idea, it's reachable. When they don't, the system isn't slowing them down.
