# Skill 12: Plan-Mode Brief Template

A short, structured brief the agent produces in plan mode before writing any code or making any mutation. Read-only. Surface the plan, the assumptions, and the verification strategy. The user approves before mutation begins.

## When to use

Use this any time the agent is about to write code, edit files, run migrations, or take an action with a footprint. Skip for read-only exploration. The plan is cheap to write and cheap to revise; the cost of catching a mistake here is one prompt. The cost of catching the same mistake after the mutation is one bug-hunt.

Concrete triggers:

- Building a feature
- Refactoring across multiple files
- Running a migration or a data backfill
- Generating a non-trivial deliverable

## The template

```markdown
# Plan: <one-sentence summary>

## Goal recap

The goal for this session (from /goal step):
- <restate the goal in one sentence>

## Files I will touch

| File | Change | Why |
|---|---|---|
| `src/auth/login.ts` | new function `handleLogin` | implements the login flow |
| `src/auth/signup.ts` | new function `handleSignup` | implements the signup flow |
| `tests/auth.e2e.test.ts` | new test cases | covers the two flows |
| `README.md` | add env var section | documents `SUPABASE_URL`, `SUPABASE_ANON_KEY` |

## Order I will work in

1. Write the e2e test cases (red)
2. Implement `handleLogin` to make login tests pass
3. Implement `handleSignup` to make signup tests pass
4. Update README
5. Run full test suite to confirm no regression

## Verification at each step

| Step | Check |
|---|---|
| After step 1 | `npm test auth.e2e` fails with the expected error |
| After step 2 | `npm test auth.e2e` passes the login cases |
| After step 3 | `npm test auth.e2e` passes both cases |
| After step 5 | `npm test` is fully green |

## Assumptions I'm making

- Supabase Auth is already configured in the project (env vars set in `.env`)
- The existing `useAuth` hook handles state; I will not modify it
- No magic-link flow needed in this pass — email + password only

## Out of scope (not doing in this session)

- Social login
- Password reset flow
- 2FA
- User-model refactor

## What I need from you before I start

- Confirm the assumptions list above
- Confirm the file list is complete
- Flag any out-of-scope item you actually want in scope
```

## How to use the brief

1. Agent produces the brief in plan mode (no mutations)
2. User reads it; pushes back on assumptions, file list, or verification strategy
3. Agent revises if needed; user approves
4. Agent exits plan mode and works the plan
5. After completion, agent posts a short "diff vs plan" summary: what changed vs the original plan, and why

## Why each section earns its keep

- **Goal recap**: keeps the plan anchored to the /goal step
- **Files I will touch**: surfaces scope before any keystroke. Catches "wait, you're going to edit which file?" mistakes
- **Order I will work in**: surfaces the agent's mental model. If the order is wrong, the user catches it before the work
- **Verification at each step**: forces the agent to think about how it'll know each step succeeded. Stops the "I think it works" failure mode
- **Assumptions**: externalizes the silent assumptions that usually only surface as bugs
- **Out of scope**: the protection against "while we're here" expansion
- **What I need from you before I start**: gives the user a clear approval prompt

## Underlying philosophy

Most session failures are alignment failures, not capability failures. The agent can do the work; it does the wrong work because nobody verified the alignment up front. Plan Mode is the cheapest possible alignment check: the agent describes its plan in natural language, the user reads, both move forward only after agreement.

The pattern pairs with /goal (Skill 11) as the second step of the session-start ritual. /goal sets the destination; the plan brief picks the route.

## Adaptation

- For tiny tasks, the brief can collapse to "I'm going to add this one line to this one file. Y/N?"
- For large tasks, the brief may grow to a one-pager. That's fine; the cost is still less than the cost of the wrong code
- For teams, the brief becomes a PR draft you can review async before code is written. Useful when the actual implementor is offline
- For repeating tasks, the brief becomes a template you reuse. Each instance fills the slots

## Before / after

Before: User says "build the login flow." Agent starts writing code, makes assumptions about which Supabase Auth method to use, picks the wrong one, writes 300 lines, runs tests, half fail. User reads the diff and notices the wrong method. Agent revises, fixes, but spends an hour on the wrong path first.

After: User says "build the login flow." Agent produces the plan brief. User notices "you assumed magic-link; I want email + password." User pushes back. Agent revises. Agent then writes the right 300 lines on the first pass.
