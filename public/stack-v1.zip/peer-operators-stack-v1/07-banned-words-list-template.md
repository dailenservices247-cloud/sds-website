# Skill 07: Banned Words List Template

A typed, scoped, justified list of the words and phrases you've decided not to ship. Pairs with the lint (Skill 05) which enforces it. Pairs with Drop-Overclaim (Skill 08) which removes hype after the fact.

## When to use

Use this whenever you find yourself repeatedly removing the same word from drafts. The third time you delete "really" from a paragraph is the signal that the word belongs on the list, not in your prose. Externalize the discipline; stop spending willpower on it.

Concrete triggers:

- Auditing drafts after writing for a month and noticing recurring filler
- Adopting a new craft tradition (via Skill 06) that has explicit don'ts
- Onboarding a writer to your voice
- Cleaning up an AI-generated draft that read more "AI" than you wanted

## Step-by-step

1. Create `~/.claude/canon/voice/banned-words.md`
2. Open it as a markdown table with four columns: `Word | Why banned | Allowed exception | Replacement`
3. Start with the universal list below
4. Add 1 to 3 entries per week as you notice them in your own drafts
5. Cap the list around 30 to 50 entries. Past that, the lint slows down and the list becomes unreadable
6. Re-export the regex list (Skill 05) when the table changes

## Universal starter list

| Word / pattern | Why banned | Allowed exception | Replacement |
|---|---|---|---|
| `—` (em-dash) | AI tell; overused | Inside `code` | Use a period, a comma, or a colon |
| `just` | Filler; hedges the verb | In quoted speech | Delete it |
| `really` | Filler; intensifier doing no work | In quoted speech | Delete it or use a stronger word |
| `basically` | Filler; signals about to oversimplify | In quoted speech | Delete it |
| `actually` | Filler; signals contrast that often isn't there | If contrast is real, use "in fact" | Delete it |
| `leverage` (as verb) | Hype verb; tech-marketing slop | If the noun is a financial leverage point | "use" |
| `unlock` (as verb) | Hype verb; consultant tell | Literal locks | "make available" or "open up" |
| `supercharge` | Marketing tell | Never | "improve" |
| `seamless` | Hype adjective; rarely true | If you can prove it | "smooth" or delete |
| `frictionless` | Hype adjective; rarely true | Same | "low-effort" or delete |
| `cutting-edge` | Marketing tell | Never | Delete or name the specific tech |
| `world-class` | Marketing tell; unprovable | Never | Delete or replace with concrete claim |
| `synergy` | Consultant tell | Never | Name the specific overlap |
| `at the end of the day` | Filler phrase | Never | Delete it |
| `in today's fast-paced world` | AI tell | Never | Delete the whole sentence |
| `revolutionize` / `revolutionary` | Overclaim | Never | "change" or be specific |
| `game-changer` / `game-changing` | Overclaim | Never | Name the change |
| `whether...or not` | Verbose for "whether" | Never | "whether" |
| `in order to` | Verbose for "to" | Never | "to" |
| `utilize` | Verbose for "use" | Never | "use" |

## Underlying philosophy

A banned list is a stand-in for taste you don't want to keep re-running in working memory. Taste is expensive cognitively; rules are cheap. Externalizing the taste-rule into a list lets the lint enforce it for you, which frees your attention for the parts of writing that can't be ruled.

The list is personal. There is no universal correct list. The point is consistency: once a word goes on your list, it stays off your pages. The lint enforces what your eye won't always catch on a tired day.

## Adaptation

- Pet peeves go on the list. If "literally" makes you flinch, ban it. Personal voice is built out of accumulated micro-decisions, and this list externalizes them
- Allowed exceptions matter. "Just" inside a quoted speech is fine; the lint should let it through. Document the exception
- Replacements are optional. For some entries the right move is delete-and-leave-silence; for others a swap is cleaner
- Review the list quarterly. Words that once belonged on the list may have aged off; new ones will have aged on

## Before / after

Before: A 400-word post has six instances of "just," two "really"s, an em-dash, and a "leverage." The reader notices the texture is slightly off but can't say why.

After: Lint catches all ten. You replace or delete. The post reads cleaner. The reader notices the argument, not the texture.

## Pair with

- Skill 05 (linter): enforces the list automatically
- Skill 08 (Drop-Overclaim): removes hype that survived the lint
- Skill 06 (Doctrine Injection): front-loads voice so the lint catches fewer
