# Install Guide: Peer Operator's Stack v1

This guide covers installing the 20 skills into the three most common operator setups: Claude Code, Claude Desktop, and OpenAI Codex. Pick the section that matches your harness. If you use a different harness, the patterns adapt: the artifacts are markdown files; what changes is where they live.

## What you got

A folder with 20 numbered skill files (`01-` through `20-`), this guide, a README, a license, and a changelog. The files are intentionally markdown so you can grep, edit, and fork without any custom tooling.

## Setup: Claude Code

Claude Code resolves skills from three locations. The Peer Operator's Stack is designed to live as user-scope skills.

### Step 1: Copy the files

```bash
mkdir -p ~/.claude/skills/peer-operators-stack
cp -r /path/to/peer-operators-stack-v1/* ~/.claude/skills/peer-operators-stack/
```

The skills are now resolvable by Claude Code on session start.

### Step 2: Make the high-value skills first-class

A handful of the skills (Find-Skill, /goal ritual, Plan-Mode Brief) work best if you wire them into Claude Code's slash-command or skill-trigger mechanism. The Stack ships them as markdown patterns; turning them into invokable skills is a 10-minute task per skill:

```bash
mkdir ~/.claude/skills/find-skill
# Paste the relevant SKILL.md frontmatter and body from skill 09
```

If you already have a `find-skill` skill installed, the version in this Stack supersedes it. Replace the contents and reload.

### Step 3: Optional: install the voice linter as a pre-commit hook

```bash
cp 05-brand-voice-linter.md ~/voice-lint.mjs   # save the reference implementation
chmod +x ~/voice-lint.mjs
# Add to .git/hooks/pre-commit in any repo where you want the lint to run
```

The pre-commit hook fires on any commit that touches a markdown file. Adjust the file filter to match your stack.

## Setup: Claude Desktop

Claude Desktop loads skills from `~/Library/Application Support/Claude/skills/` on macOS or the equivalent on Windows. The Stack drops into the same path:

```bash
mkdir -p "~/Library/Application Support/Claude/skills/peer-operators-stack"
cp -r /path/to/peer-operators-stack-v1/* "~/Library/Application Support/Claude/skills/peer-operators-stack/"
```

Restart Claude Desktop. The skills appear in your skill list.

Note: Claude Desktop doesn't run shell commands the same way Claude Code does, so the voice-linter reference implementation needs a separate runtime (Node installed locally, run from the terminal).

## Setup: OpenAI Codex / Cursor / other harnesses

These harnesses don't have a native "skills" concept the same way Claude does. The Stack still works; the install pattern is to:

1. Put the files in a location your harness can read (typically `~/skills/` or a `docs/` folder inside the project)
2. Reference the relevant skill file in your system prompt or rules file
3. Treat each skill file as a working spec you can paste into the chat when needed

For Cursor specifically, the `.cursorrules` file is the right place to reference the Stack patterns:

```
# Cursor rules
- For session starts, run /goal ritual (see ~/skills/peer-operators-stack/11-goal-session-start-ritual.md)
- Before any mutation, produce a plan brief (see 12-plan-mode-brief-template.md)
- Author memory as atomic nodes (see 01-atomic-node-template.md)
```

## Verification

After install, verify the Stack is reachable:

### Claude Code

```bash
ls ~/.claude/skills/peer-operators-stack/
```

You should see all 20 numbered files plus README, INSTALL, LICENSE, CHANGELOG.

### Claude Desktop

Open Claude Desktop, start a new session, ask: "List the skills you have available." The Stack-affiliated skills should appear.

### Codex / Cursor

Open the harness, reference one of the patterns explicitly. The harness should be able to read the file path.

## Day-1 habit

Don't install all 20 patterns into active use on day 1. Pick one:

- **If your friction is "I keep losing context across sessions"** → start with skill 01 (atomic nodes)
- **If your friction is "my drafts read AI-flavored"** → start with skill 05 + 07 (linter + banned list)
- **If your friction is "I have too many skills and can't find the right one"** → start with skill 09 (find-skill)
- **If your friction is "sessions drift and I don't know where I ended up"** → start with skill 11 (/goal ritual)
- **If your friction is "I don't know where my stack is weakest"** → run skill 19 (8-layer diagnostic) as a self-audit

Use it for 7 days. Then pick the next adjacent skill.

## Update path

Each skill is a single markdown file. Update by editing the file in place. The Stack does not have a centralized update mechanism by design: the artifacts live in your control and your fork is the source of truth for your usage.

## Support

For questions specific to your install, reply to the Stripe receipt email. For broader discussion, check the launch announcement for community-link details.
