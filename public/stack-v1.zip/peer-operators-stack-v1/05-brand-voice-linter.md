# Skill 05: Brand Voice Linter v1

A regex-based pre-commit lint that catches the words and patterns your brand voice has banned. Word-boundary aware. Skips backtick-wrapped code. Skips quoted blocks. Picks up verb-stem variants automatically.

## When to use

Use this on any text that ships under your name: blog posts, ads, microcopy, proposals, emails, social posts, even commit messages if you're particular. The lint is meant to run before a human eye does, so the human reviewer can focus on substance and shape instead of catching the same forty banned tokens for the hundredth time.

Concrete triggers:

- Drafting copy you'd be embarrassed to see in someone else's voice
- Onboarding a contractor who is about to write under your byline
- Reviewing a generated draft from any LLM before it ships
- Auditing existing site copy that has accumulated tonal drift

## Step-by-step

1. Decide your banned-words list (see Skill 07). Keep it under 30 entries for v1
2. Author a regex per entry. Use word boundaries (`\b`) so "just" doesn't fire on "adjust"
3. Add exemptions: skip text inside backticks, skip lines starting with `>` (block quotes), skip frontmatter
4. For verbs, use stem-detection: `\bjust(ly)?\b`, `\breal(ly)?\b`. Don't enumerate every conjugation
5. Run the linter against the file. The output is a list of `<line>:<column>: banned: <word>` rows
6. Fix or justify each hit. A `<!-- voice-allow: <word> reason="..." -->` inline comment lets a known good usage through

## Reference implementation (Node, single file)

```js
// voice-lint.mjs
import fs from 'node:fs';

const BANNED = [
  { pat: /—/g, name: 'em-dash' },
  { pat: /\bjust(ly)?\b/gi, name: 'just' },
  { pat: /\breal(ly)?\b/gi, name: 'really' },
  { pat: /\bbasic(ally)?\b/gi, name: 'basically' },
  { pat: /\bleverage\b/gi, name: 'leverage' },
  { pat: /\bunlock\b/gi, name: 'unlock (filler verb)' },
  { pat: /\bsupercharge\w*/gi, name: 'supercharge (hype)' },
];

function lint(file) {
  const text = fs.readFileSync(file, 'utf8');
  const hits = [];
  const lines = text.split(/\n/);
  let inFence = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (/^```/.test(line)) { inFence = !inFence; continue; }
    if (inFence) continue;
    if (/^>/.test(line)) continue;

    // strip inline backtick spans
    const scrub = line.replace(/`[^`]*`/g, m => ' '.repeat(m.length));

    for (const { pat, name } of BANNED) {
      let m;
      pat.lastIndex = 0;
      while ((m = pat.exec(scrub))) {
        hits.push({ line: i + 1, col: m.index + 1, word: m[0], name });
      }
    }
  }
  return hits;
}

const target = process.argv[2];
const hits = lint(target);
if (hits.length === 0) {
  console.log(`OK ${target}`);
  process.exit(0);
}
for (const h of hits) {
  console.log(`${target}:${h.line}:${h.col} — banned: ${h.name} ("${h.word}")`);
}
process.exit(1);
```

Run: `node voice-lint.mjs draft.md`

## Why regex, not LLM

Regex is deterministic, fast, free, and reviewable. An LLM-based "voice judge" is none of those. The point of a v1 lint is to catch the easy 80% reliably; subtler voice issues are for the human reviewer, not for another model. The lint is a floor, not a ceiling.

## Underlying philosophy

Banked from the working-builder posture: write down what you do not want, then enforce it with the cheapest tool that works. Voice is a discipline of what to remove, not what to add. The lint formalizes the removal half of the work and leaves the additive half (cadence, rhythm, taste) to the human.

## Before / after

Before: A 600-word post ships with "really," "just," and an em-dash in the second paragraph. Three readers notice but say nothing. You notice in the published version a day later, fix it, push, lose the day.

After: The pre-commit hook caught all three in one second. The post ships clean. The reviewer reads for the actual argument, not for the banned tokens.

## Adaptation

- Start with the universal banned list (em-dash, just, really, basically, leverage, unlock). Add 5 to 10 of your own pet peeves over the first month
- The list is personal. What's banned for one operator is fine for another. The point is consistency to your voice, not adherence to anyone else's
- Run the lint at three points: pre-commit (catches drafts), pre-publish (catches edits), and quarterly across the whole site (catches drift)
