# Skill 03: Decisions Log Rolling Index Pattern

A one-line-per-decision index file that links into the atomic decision nodes. The index stays browsable for humans. The nodes stay loadable for agents. Neither one carries the full prose weight.

## When to use

Use this when you adopt atomic nodes (Skill 01) but still want a single file you can scroll on a slow morning to remember what's been decided. The index does what the old long-form journal did: gives a chronological browse view. What it doesn't do: hold the full content of any decision.

Concrete triggers:

- You're migrating from a long-form `Decisions Log.md` to atomic decision files
- New team member needs a 5-minute orientation to "what we've decided"
- You want to skim the last quarter's decisions in 30 seconds before a strategy session

## Step-by-step

1. Keep the existing `Decisions Log.md` file in `AI Hub/`. Do not delete it
2. Rewrite each existing entry into a one-line summary, in this format:

```
- **YYYY-MM-DD** — <one-line summary, under 120 chars> → [decision-YYYY-MM-DD-slug](Decisions/decision-YYYY-MM-DD-slug.md)
```

3. From this point forward, every time you author a new decision node, also add a one-line entry to the top of the rolling index
4. Keep entries reverse-chronological (newest at top)
5. Group by quarter under `## 2026-Q2` headers when the index passes ~50 entries
6. Never paste the body of a decision into the index. If a decision needs context, the linked node carries it

## Format example

```
## 2026-Q2

- **2026-05-14** — Locked v9.3 spec; atomic-node memory becomes default → [decision-2026-05-14-atomic-node-default](Decisions/decision-2026-05-14-atomic-node-default.md)
- **2026-05-08** — Adopted Doctrine Injection for all craft work → [decision-2026-05-08-doctrine-injection](Decisions/decision-2026-05-08-doctrine-injection.md)
- **2026-04-30** — Minimum-viable becomes the default scope posture → [decision-2026-04-30-mvp-default](Decisions/decision-2026-04-30-mvp-default.md)
```

## Underlying philosophy

The rolling index serves a different job from the atomic node. Atomic nodes serve the agent (retrieval, citation, contradiction tracking). The index serves the human (scan, recall, orient). Conflating the two is what made the old long-form `Decisions Log.md` slow to load and expensive for the agent to read. Splitting them lets each surface do its job well.

A useful side effect: writing the one-line summary is itself a clarity test. If you can't summarize the decision in 120 characters, the decision isn't ready to lock. Keep it as a draft node and add the index entry once it is.

## Adaptation

- For inference indexes, build a parallel `Inferences Log.md` with the same one-line format. Inferences are claims about how the world is, not decisions about what you'll do, so they earn their own index
- For solo operators, the index can be the same file you keep open in a side pane. For teams, the index becomes the read-only doc you link in onboarding
- The 120-char limit isn't sacred. It's tight enough to force clarity and loose enough to fit a real decision. If 140 fits your style better, fine; just commit to one and stay consistent

## Before / after

Before: `Decisions Log.md` is 2,400 lines. Looking up "when did we decide on the Stripe Connect routing model" requires a search, a skim of three nearby paragraphs, and a guess.

After: `Decisions Log.md` is 60 lines of one-liners. Looking up Stripe Connect is a Ctrl-F to the one line, click the link to the decision node, full context in one focused file. Total time: under 30 seconds. Token cost for the agent: about a tenth of the old approach.
