# Skill 13: Self-Verify Chrome DevTools MCP Install + Usage

A short installable workflow for adding the Chrome DevTools MCP to a Claude Code setup, then using it to verify what's actually happening in a browser instead of trusting the agent's report. The verification layer that closes the loop between "the code compiled" and "the user sees what you intended."

## When to use

Use this any time the work involves a web UI and the agent's "looks good to me" can't be trusted. The agent reads code; it doesn't see the rendered page. The DevTools MCP gives it eyes. Without it, you spend cycles correcting the agent's hallucinated DOM state.

Concrete triggers:

- Building a feature where the visual result matters
- Debugging "it works locally but not in browser" issues
- Verifying responsive layouts at specific breakpoints
- Checking network calls, console errors, or accessibility tree state without manually opening DevTools

## Install

1. Confirm Claude Code is up to date
2. Add the Chrome MCP via the standard MCP install path. Most environments accept:

```bash
claude mcp add chrome-devtools \
  --command "npx" \
  --args "@modelcontextprotocol/server-chrome-devtools"
```

or the GUI install path your harness exposes.

3. Confirm Chrome is running with the remote debugging port enabled. The simplest way: open Chrome from the terminal:

```bash
open -a "Google Chrome" --args --remote-debugging-port=9222
```

4. Verify the MCP is connected. Ask Claude: "List the chrome-devtools tools you have." A connected MCP returns a tool list. A disconnected one returns nothing.

## Usage pattern: the verify-after-mutation loop

After any UI mutation the agent makes, run this loop:

1. Agent navigates to the page being changed (`navigate` tool)
2. Agent takes a screenshot (`screenshot` tool)
3. Agent reads the DOM / accessibility tree at the relevant selector
4. Agent reads the console for errors
5. Agent reads the network panel for failed requests
6. Agent compares observed state to expected state from the plan brief (Skill 12)
7. If mismatch, agent reports the mismatch concretely and either fixes or asks the user

This loop is the verification "tier" that should sit between "code compiles" and "user signs off." Without it, code-compiles is treated as ship-ready and the gap shows up only when the user opens the page.

## Self-verify before reporting "done"

The agent reports "done" only after running the verify-after-mutation loop and confirming all of:

- The screenshot shows the intended state
- The console has zero new errors
- The network panel shows no unexpected 4xx/5xx
- The accessibility tree includes the intended landmarks / labels

If any of these are off, the agent reports specifically what is off, not "done."

## What this catches

- Tailwind class typos that compiled fine but rendered nothing
- React state updates that fired but didn't propagate to the DOM
- API calls that succeeded but returned malformed JSON
- Layout that works at 1440px but breaks at 393px
- Console warnings that signal future runtime errors

## What this does not catch

- Visual taste issues (the agent doesn't have aesthetics)
- Cross-browser bugs (DevTools sees Chrome only)
- User-flow issues that need full e2e traversal
- Accessibility issues subtler than tree-level

For those, you still need e2e tests (Playwright, Cypress) and human review.

## Underlying philosophy

The agent's working model of the world is text. The browser's actual state is rendered, interactive, networked. The gap between the two is where most "agent said done but it isn't" failures live. The DevTools MCP narrows the gap. It doesn't close it: visual taste and human flow still need human eyes: but it closes the easy 70% that's been costing you cycles.

Pairs with the plan brief (Skill 12) which states what the verified state should look like. Pairs with the /goal ritual (Skill 11) which named the completion condition. The DevTools MCP is the proof-of-completion step.

## Adaptation

- For non-web work, the analog is the equivalent MCP for your stack: filesystem MCP for files, GitHub MCP for repo state, Supabase MCP for DB state. The principle is the same: verify against the real system, not against the agent's text model of it
- For PWA work, the DevTools MCP also lets you verify service-worker behavior and offline caching, which is otherwise painful to inspect
- For accessibility-sensitive work, build a short "a11y verify" sub-loop that reads the accessibility tree at a specific selector and confirms label, role, and focusable state

## Before / after

Before: Agent says "the login form is wired up." User opens the page; the button doesn't fire. Console has a "Cannot read property 'x' of undefined" error from a state init that ran before the form mounted. User spends 20 minutes finding it. Agent fixes in 2 minutes.

After: Agent says "the login form is wired up" and pastes a screenshot + console summary showing no errors and the network call returning 200. Total time: same code path, but the cycle catches the failure mode before the user sees it.
