# Skill 16: Calendly Confirmation-Page Redirect-to-Stripe Pattern

A booking flow where Calendly's confirmation page redirects the booker to a Stripe Payment Link. The booker schedules first, pays second. The pattern decouples the calendar tool from the payment tool, lets you use whichever is best at each job, and keeps the no-show rate low because the slot isn't actually held until payment clears.

## When to use

Use this for any paid call or session where you want the booker to pick a slot first and pay second. The other order (pay first, then schedule) works for some flows but punishes the buyer's psychology: they're paying for an abstract thing. Booking first creates a concrete slot, which makes paying for it feel like confirming something already in motion.

Concrete triggers:

- Paid discovery calls ($100 to $500 range)
- Paid strategy sessions ($500 to $2,500 range)
- Paid audits or reviews with a kickoff call
- Any productized service that opens with a scheduled call

## The flow

1. **Booker lands on your `/work-with-me` page.** Page sells the service and links to Calendly
2. **Booker picks a slot in Calendly.** Free 30-min discovery, paid 90-min strategy, whatever the service offers
3. **Calendly shows the confirmation page.** This page is configured to auto-redirect to your Stripe Payment Link after a 3-5 second delay so the booker can read the "you're being redirected to payment" message
4. **Booker pays at Stripe.** Successful payment fires the Stripe `checkout.session.completed` webhook
5. **Stripe `hosted_confirmation` page shows the post-pay message.** Includes the engagement-letter PDF link, the intake-form link (Skill 17), and the expected timeline
6. **Optional automation:** a webhook listener (Zapier, Make, custom) auto-cancels the Calendly booking if payment doesn't clear within X hours

## Calendly setup

In the event type settings:

- Confirmation page → Redirect to an external page
- URL: your Stripe Payment Link (e.g., `https://buy.stripe.com/abc123`)
- Pass query string: append `?prefilled_email={{invitee_email}}` so Stripe prefills the email field. Calendly's templating supports this

Optional: add a brief description on the Calendly booking page that says "Payment ($X) is collected on the next page. Your slot is held for 30 minutes pending payment."

## Stripe setup

Create a Payment Link in Stripe:

- Product: <service name>
- Price: <amount, one-time>
- After payment → Show confirmation page
- Confirmation message (use markdown):

```
Thanks for booking and paying. Here's what happens next:

1. You'll get a Calendly calendar invite within 5 minutes
2. The engagement letter is attached to the receipt email
3. The pre-call intake form is here: <link>
4. I'll send a Zoom link 24 hours before the call

Reply to the receipt email if anything's off.
```

This `hosted_confirmation` custom message pattern is what closes the loop. The buyer paid; they want to know what happens next; this answers it before they need to email you.

## Why this order

**Calendar first, payment second** because:

- The slot is concrete; the buyer is choosing a specific thing they can imagine
- It surfaces availability friction up front (if no slots work, you find out before payment)
- It generates the calendar event automatically; you don't need to manually invite

**Payment second** because:

- Skin-in-the-game discipline: paid bookings show up at a much higher rate than free bookings
- The Stripe receipt becomes the contract trigger (engagement letter delivered with it)
- Payment failure auto-cancels the slot without manual cleanup

## Underlying philosophy

The pattern works because it respects how booking psychology actually works. Buyers don't pay for "a service"; they pay for a specific time on their calendar. Selecting the time first makes the payment a confirmation, not a leap. The order also lets each tool do its job: Calendly is excellent at calendars, Stripe is excellent at payments, neither needs to know about the other.

The hidden benefit is no-show reduction. A free-call no-show rate of 40% drops to about 5% once payment is required, in our experience and consistent with what other productized-service operators report.

## Adaptation

- For lower-priced services ($50-150), consider charging on booking (Stripe Checkout in Calendly's payment integration). The redirect pattern shines at the $500+ tier where the engagement letter matters
- For higher-priced services ($2,500+), some buyers want to talk first. Run a free 15-min discovery in front of the paid session; route only qualified bookers to the paid flow
- The 24-hour pre-call email window can move. Some operators use a 48-hour pre-call email + a 1-hour day-of reminder; others rely on Calendly's defaults

## Before / after

Before: $1,500 strategy call sells via cold email. Booker emails to schedule. You manually invoice. They take 4 days to pay. Slot is half-blocked the whole time. They flake at the last minute and you've held the slot for nothing.

After: Same offer. Booker picks a slot, gets redirected to Stripe, pays in 90 seconds, gets the confirmation flow + engagement letter + intake form automatically. Total operator effort post-booking: zero, until the call itself.
