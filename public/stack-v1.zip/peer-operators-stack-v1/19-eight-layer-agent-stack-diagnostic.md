# Skill 19: 8-Layer Agent Stack Diagnostic

A scoring instrument that maps an operator's current agent stack across eight layers and surfaces the highest-leverage gap. Used as the spine of the paid architecture review, also useful as a self-audit any operator can run on their own stack in 20 minutes.

## When to use

Use this when you want a structured read of where an agent stack is weak. The instrument is most useful at quarterly intervals or before a substantial investment of effort in any one layer. Running the diagnostic catches the case where the layer you were about to upgrade is already fine and the actual bottleneck is two layers upstream.

Concrete triggers:

- Quarterly review of your own stack
- Before deciding to migrate memory infrastructure
- Before adding a new MCP, agent, or orchestration tool
- Before pitching an audit to a prospective consulting client (use it on yourself first; you should pass your own bar)
- During a paid architecture review for a client

## The 8 layers

| # | Layer | What it covers | Check question |
|---|---|---|---|
| 1 | **Organizational frame** | Who the agent serves; what it's for; the role it plays in the business | "If I described the agent's job to a new hire, could they tell me what it does in one sentence?" |
| 2 | **Tactical layer** | Specific tasks the agent runs (not abstract capabilities, named tasks) | "What are the 5 specific tasks this agent ran this week?" |
| 3 | **Vertical loop** | The agent's repeatable workflow per task (input, work, output, verification) | "What does the agent do when given task X? Step by step." |
| 4 | **Artifact layer** | Deliverable format; audience fit; what the agent produces | "Does the output format match what the recipient needs, or is the recipient doing extra work?" |
| 5 | **Memory authoring** | Atomic nodes, decisions, inferences, contradiction tracking | "Can the agent cite a specific past decision by ID, or is it summarizing chat history?" |
| 6 | **Orchestration** | How multiple agents or sessions coordinate; handoff format; queue discipline | "When session A's work feeds session B, is the handoff a written artifact or a vague memory?" |
| 7 | **Goal and methodology** | Plan mode, gap analysis, Socratic spec, /goal ritual | "Does the agent know what the session's completion condition is before mutation starts?" |
| 8 | **Retrieval contract** | What gets pulled, when, how filtered; token budget per turn | "Does this project have a retrieval contract, or does the agent read whatever it can find?" |

## Scoring per layer

For each layer, score one of:

- **Present** (2 points): the layer is in place, documented, and used in practice
- **Partial** (1 point): the layer exists but is undocumented, inconsistent, or only used sometimes
- **Absent** (0 points): the layer is missing or is only an idea

Total possible: 16 points. Realistic operator scores:

- **0-5** Starting: the stack is mostly informal. The next move is to write down the organizational frame and pick one task to formalize
- **6-10** Building: pieces are in place, but coverage is uneven. The next move is to identify the one weakest layer and bring it up to par before adding new capability
- **11-14** Compounding: the stack works. The next move is to refine the lowest-scoring layer and start orchestrating across projects
- **15-16** Mature: rare; usually means either you're being generous in scoring or the stack is genuinely well-tuned. Stress-test by asking a peer to score it

## How to run the diagnostic (self-audit version)

1. Block 20 minutes
2. For each layer, write one paragraph (3-5 sentences) describing the current state
3. Score Present / Partial / Absent honestly. The honesty is the work
4. Identify the lowest-scoring layer
5. Identify the single move that would bring it up one level
6. Write that move as your next 30-day commitment

## How to run the diagnostic (client-facing version)

This is the spine of a paid architecture review:

1. Pre-call intake (Skill 17) gives you draft scoring for layers 1, 2, 4, and 8
2. The 90-minute call elicits the remaining four layers through conversation
3. Score during the call; verify with the client
4. The deliverable PDF presents the scoring as a table, names the top 3 leverage points (always the lowest-scoring layers), and includes a 30/60/90-day roadmap

## Underlying philosophy

The 8-layer model is descriptive of where agent stacks tend to fail, not prescriptive of how to build one. The layers were extracted from looking at where operator stacks actually break: rarely capability, often coordination. Most stacks have respectable capability in layers 1-3 and weak coverage in layers 5-8. The diagnostic surfaces this imbalance.

The diagnostic also resists the common error of "I need a new tool." Most operators score Absent on memory authoring or retrieval contract while adding a sixth MCP. The honest answer is usually to fix the contract before adding the tool.

## Adaptation

- For teams, run it per-agent rather than across the whole stack. A bookkeeping agent and a content agent score differently
- For solo operators, the whole stack is one column; the diagnostic still works
- The two-point scale (P / P / A) is deliberately coarse. A finer-grained scoring instrument is harder to use honestly. Coarseness keeps the diagnostic honest

## Before / after

Before: Operator thinks "my stack feels slow." They migrate from one orchestration tool to another. Three months and $4k later the stack feels the same way slow.

After: Operator runs the diagnostic. Memory authoring scores Absent. Retrieval contract scores Absent. The orchestration layer they were going to migrate was already fine. They fix memory authoring with Skills 01-04. Three months later the stack feels faster because the actual bottleneck got fixed.
