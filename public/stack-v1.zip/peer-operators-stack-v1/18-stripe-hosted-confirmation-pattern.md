# Skill 18: Stripe Payment Link Hosted-Confirmation Custom-Message Pattern

A Stripe Payment Link configured to show a custom post-purchase message that includes the next-steps the buyer needs (engagement letter link, intake-form link, expected timeline) right at the moment of highest attention. Replaces the generic "thanks for your purchase" page with a working handoff.

## When to use

Use this for any productized service or product sold via Stripe Payment Link where the buyer has work to do after paying (fill an intake form, schedule a call, download a file, sign an engagement letter). The standard Stripe receipt is fine; the hosted confirmation page is your only chance to catch the buyer's attention before they switch contexts.

Concrete triggers:

- Selling a paid call where an intake form follows
- Selling a paid product where a download link is the next step
- Selling a service with an engagement letter that needs acknowledgment
- Any flow where the buyer's first 60 seconds post-payment determine whether they complete onboarding

## Configuration

In Stripe Dashboard → Payment Links → your link → After payment:

- Show confirmation page (instead of "Don't show a confirmation page")
- Custom message: paste a markdown-formatted message (Stripe renders basic markdown)

Markdown template:

```markdown
## You're booked. Here's what's next.

1. **Engagement letter** is attached to your receipt email. Quick read; reply to the email if anything's off.
2. **Pre-call intake form** (10-15 minutes): https://<your-intake-form-link>
3. **Calendar invite** lands in your inbox within 5 minutes.
4. **Zoom link** is in the calendar invite and re-sent 24 hours before the call.

Reply to the receipt email with any questions. See you then.
```

Keep it to 4-6 lines. Past that, attention falls off and the buyer skips the most important step.

## What goes in the message

- **The next-action link, on its own line.** The intake form, the download, the scheduling link: whatever the buyer needs to do next
- **The thing already happening.** Calendar invite within 5 minutes, receipt with engagement letter, etc. Sets expectations so they don't email "did this go through?"
- **The contact path for anything off.** "Reply to the receipt email" is the simplest; the receipt is in their inbox in seconds and reply-threading keeps the conversation organized

## What does NOT go in the message

- A sales pitch for the next product
- Testimonials or social proof (they already bought)
- A long welcome letter (save for the email)
- A second payment link

## Why the custom message matters

The default Stripe confirmation is generic ("Thanks for your purchase"). It does not link to anything. It does not tell the buyer what happens next. Most operators leave the default in place and then send the next steps in an email, where it competes with everything else in the inbox.

The custom message catches the buyer at peak attention: they clicked Pay one second ago; they're still on the success page; they're already in a "what's next" frame of mind. Putting the next action there closes the loop instantly. Buyers who would have ghosted a follow-up email complete the intake form because the link was on the success page.

## The receipt email complement

Stripe also sends an automated receipt email. Configure this in your Stripe Dashboard → Settings → Email receipts:

- Custom footer text: repeat the next-action links from the confirmation page
- Optional attachment: the engagement letter PDF, if you've automated the attach via a webhook listener

The confirmation page catches buyers who act immediately. The receipt email catches buyers who close the tab and come back later. Together they catch ~95% of the buyer base.

## Underlying philosophy

Every productized service has an onboarding choke point. For a paid call, it's the intake form. For a download product, it's the actual download. For a subscription, it's the first login. The choke point is where buyers drop off when the path forward is unclear. The Stripe hosted-confirmation message is the cheapest possible fix: same UI surface they're already on, zero extra latency, zero email friction.

This pairs with the Calendly redirect pattern (Skill 16) and the intake-form spec (Skill 17) to close the full booking-to-context loop.

## Adaptation

- For pure-download products (the Peer Operator's Stack itself, ironically), the message is "Your download link is in the receipt email + here: [link]"
- For higher-touch services, add a one-line "I read every intake form myself" so the buyer knows the form isn't going into a void
- For multi-step onboarding (course, cohort), number the steps so the buyer can see how many remain
- Test the message length by reading it after running through your own checkout in a private window. If you scroll, it's too long

## Before / after

Before: Buyer pays. Default Stripe "Thanks for your purchase" page. Buyer closes tab. Receipt email arrives 30 seconds later, gets buried under other inbox traffic. Buyer never fills the intake form. You email them the next day; they fill it 48 hours later; the call is now happening with stale context.

After: Buyer pays. Custom message with intake link is right there. Buyer clicks it within the same minute. Form is filled before they leave the success page. Call happens with fresh, complete context. Onboarding completion rate jumps from ~60% to ~90%.
