# Skill 04: Inferences Log Rolling Index Pattern

An index file that separates claim-shaped captures (inferences about how the world is) from decision-shaped captures (commitments to act). Same one-line-per-entry format as the decisions index, kept in its own file so the two never bleed together.

## When to use

Use this when you notice yourself adding "I think X is true about the market / users / the codebase" entries to your decisions log. Those aren't decisions. They're inferences, and they earn their own track because they need different upkeep: inferences get falsified or updated as new evidence arrives, while decisions get superseded only by new decisions.

Concrete triggers:

- You wrote a "decisions" entry that started with "I think" or "It seems like"
- You want to track which of your model-of-the-world claims have held up over time
- You're about to commit to a strategy that rests on an unstated assumption: write the inference first, then decide

## Step-by-step

1. Create `AI Hub/Inferences Log.md` (parallel to `Decisions Log.md`)
2. Use the same one-line format:

```
- **YYYY-MM-DD** — <claim, under 120 chars> → [inference-YYYY-MM-DD-slug](Inferences/inference-YYYY-MM-DD-slug.md) — *status: <holds | revised | falsified>*
```

3. Every inference node uses the atomic-node template (Skill 01) with `type: inference` in frontmatter
4. Status is a real field, not decoration. Update it when evidence moves
5. When an inference is falsified, do not delete the entry. Append a new node that supersedes it and link both ways. The history is the value

## Status values

- **holds**: inference still appears true; latest evidence does not contradict it
- **revised**: wording was tightened or scope narrowed; the spirit holds
- **falsified**: evidence has accumulated against this; the inference is dead but kept for the record
- **pending**: newly captured, not yet stress-tested

## Format example

```
## 2026-Q2

- **2026-05-12** — Ryan-Doser-style skill packs sell better at $99-$199 than at $49 → [inference-2026-05-12-skill-pack-pricing](Inferences/inference-2026-05-12-skill-pack-pricing.md) — *status: holds*
- **2026-04-22** — Cold outbound to AI consultants converts under 1% without a strong artifact lead-in → [inference-2026-04-22-cold-outbound-ai-consultants](Inferences/inference-2026-04-22-cold-outbound-ai-consultants.md) — *status: pending*
- **2026-03-30** — Most "AI memory" products are vector-DB demos, not workflow tools → [inference-2026-03-30-memory-products-are-demos](Inferences/inference-2026-03-30-memory-products-are-demos.md) — *status: holds*
```

## Underlying philosophy

The split between decisions and inferences matters because they decay differently. A decision stays valid until you make a new one. An inference stays valid only as long as the world it claims to describe stays put. Mixing them in one log obscures which entries are commitments and which are conjectures. The atomic-node infrastructure (Skill 01) makes the split cheap; the rolling index makes the browse view possible.

Pairs especially well with the "scope deliberately" discipline: inferences are where you write down the assumption a strategy rests on before you commit to the strategy. Strategy decisions are then traceable back to the inferences they depend on, which means revising an inference automatically flags the dependent decisions for review.

## Adaptation

- If you're new to this split, start by going through your last 30 days of "decisions" entries. Most operators find that 1 in 3 was actually an inference in disguise
- The `status` field is your honesty mechanism. If you can't bring yourself to mark anything "falsified," the discipline is decorative
- For teams, inferences are where you make tacit assumptions explicit. A team that writes inferences down argues better because the disagreement surfaces at the claim level instead of the decision level

## Before / after

Before: "We decided to focus on AI consultants as the buyer for the Stack." Six months later, sales are flat. The team relitigates whether the focus was right. Nobody remembers the assumption underneath ("AI consultants have ~$300 discretionary monthly tool spend").

After: The decision links to the inference. The inference has status `falsified` as of three weeks ago. The team's first question is not "was the decision wrong" but "what inference changed, and which other decisions rest on it."
