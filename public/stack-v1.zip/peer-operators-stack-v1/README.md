# Peer Operator's Stack v1

A library of 20 named skills and templates for operators who run AI inside their own businesses. Built from working-builder methodology, not theory. Pulled from the practices behind Black Sheep 247 LLC / Synapse Dynamics Segmented.

Authored by Dailen Huntley.

## What's inside

20 self-contained skill files, grouped into five categories. Each file is a working pattern with a stated trigger, step-by-step instructions, the philosophy underneath, and adaptation guidance for forking it to your own use.

### Category 1: Memory and retrieval

| # | Skill | What it does |
|---|---|---|
| 01 | Atomic Node Template | Single-claim memory units with typed frontmatter, linked into a graph |
| 02 | Retrieval Contract Template | A short file per project that defines what the agent needs to know |
| 03 | Decisions Log Rolling Index Pattern | One-line index linking into atomic decision nodes |
| 04 | Inferences Log Rolling Index Pattern | Same pattern for claim-shaped captures, kept separate from decisions |

### Category 2: Voice and craft

| # | Skill | What it does |
|---|---|---|
| 05 | Brand Voice Linter v1 | Regex-based pre-commit lint that catches banned tokens |
| 06 | Doctrine Injection Pattern | Two-prompt sequence for craft work: dissect canon, then generate |
| 07 | Banned Words List Template | Typed, scoped list paired with the linter |
| 08 | Drop-Overclaim Editing Pass | Six-check pass that strips hype after the first draft |

### Category 3: Workflow and skills

| # | Skill | What it does |
|---|---|---|
| 09 | Find-Skill Router | Gateway router that scores installed skills against the user's task |
| 10 | CLAUDE.md TOC Pattern | Keeps CLAUDE.md under 200 lines as a router into specialized docs |
| 11 | /goal Session-Start Ritual | Three-step opening: goal, plan, managed outcomes |
| 12 | Plan-Mode Brief Template | Read-only plan the agent writes before any mutation |
| 13 | Chrome DevTools MCP Verification | Self-verify what the browser actually renders |
| 14 | Subagent Dispatch Template | Decide when to spawn, what to brief, what return shape to require |

### Category 4: Engagement layer

| # | Skill | What it does |
|---|---|---|
| 15 | Engagement Letter Template | Liability-capped engagement letter for productized services |
| 16 | Calendly-to-Stripe Redirect Pattern | Schedule first, pay second, no-show rate near zero |
| 17 | Tally Intake Form Spec | 13-question pre-call intake form |
| 18 | Stripe Hosted-Confirmation Pattern | Custom post-purchase message that closes the onboarding loop |

### Category 5: Bonus / diagnostic

| # | Skill | What it does |
|---|---|---|
| 19 | 8-Layer Agent Stack Diagnostic | Scoring instrument for auditing an agent stack |
| 20 | ICAC Tier Discipline | Full / Light / No tier-gated ingest for memory hygiene |

## Who this is for

Operators who:

- Run multiple AI tools inside their own workflows (Claude Code, Claude Desktop, Codex, Cursor, n8n, MCPs)
- Have hit the wall where adding more tools made the stack less useful, not more
- Want a working library to fork, not a course to watch
- Prefer working-builder posture to hype

## Who this is not for

- Operators looking for a no-code "set it and forget it" automation kit. These skills assume you'll fork, adapt, and maintain
- Operators who haven't yet picked up a coding assistant. Some skills depend on running Claude Code, Codex, or an equivalent
- Operators who want a single end-to-end SaaS. This is a library of patterns; you assemble the stack

## How to use this library

1. Read `INSTALL.md` for setup
2. Pick the one skill that addresses the friction you feel most right now (probably one of: 01, 05, 09, 11, or 19)
3. Fork it. Adapt it to your stack. Use it for a week
4. Add the next adjacent skill once the first one is habit
5. Don't try to install all 20 at once. The library is designed to be picked from, not installed wholesale

## License

Single-buyer license. See `LICENSE.md`. The short version: use it inside your business, fork freely, don't resell as-is.

## Changelog

See `CHANGELOG.md`.
