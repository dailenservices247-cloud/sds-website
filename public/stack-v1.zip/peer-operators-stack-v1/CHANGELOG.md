# Changelog: Peer Operator's Stack

All notable changes to the Peer Operator's Stack will be documented here. The format follows the spirit of Keep a Changelog, adapted for a productized skill library rather than a software project.

## v1.0.0: 2026-05-16

Initial launch.

### Included

20 named skills across five categories:

**Memory and retrieval**
- 01 Atomic Node Template
- 02 Retrieval Contract Template
- 03 Decisions Log Rolling Index Pattern
- 04 Inferences Log Rolling Index Pattern

**Voice and craft**
- 05 Brand Voice Linter v1
- 06 Doctrine Injection Pattern
- 07 Banned Words List Template
- 08 Drop-Overclaim Editing Pass

**Workflow and skills**
- 09 Find-Skill Router
- 10 CLAUDE.md TOC Pattern
- 11 /goal Session-Start Ritual
- 12 Plan-Mode Brief Template
- 13 Chrome DevTools MCP Verification
- 14 Subagent Dispatch Template

**Engagement layer**
- 15 Engagement Letter Template
- 16 Calendly-to-Stripe Redirect Pattern
- 17 Tally Intake Form Spec
- 18 Stripe Hosted-Confirmation Pattern

**Bonus / diagnostic**
- 19 8-Layer Agent Stack Diagnostic
- 20 ICAC Tier Discipline

### Meta files

- README.md
- INSTALL.md
- LICENSE.md
- CHANGELOG.md (this file)

### Known limitations at v1

- No automated installer. The install is manual file copy. A small bash installer is on the v1.1 list
- No skill-to-skill chaining metadata. Each skill stands alone; the README groups them by category, but a machine-readable dependency graph is not shipped at v1
- Voice linter ships as a reference implementation only. A packaged npm module is on the v1.2 list
- The 8-layer diagnostic does not ship with a scoring spreadsheet. A printable / digital-fillable version is on the v1.1 list

### What's intentionally not shipped

- Vector-store integrations. The Stack is opinionated against vector stores at the small-operator scale. If you disagree, fork freely
- Multi-agent orchestration patterns beyond Subagent Dispatch (Skill 14). The Stack's stance is that orchestration is overrated relative to memory and retrieval; the operator who feels orchestration-poor is usually memory-poor
- A workflow runner. The Stack provides patterns; you bring your own runner (Claude Code, Codex, n8n, Trigger.dev)

### Pricing

Launch price: $149 USD, one-time, lifetime access to v1 and to any v1.x updates (v1.1, v1.2, etc.). v2 will be a separate purchase if and when it ships.

### Refund window

14 days, no questions asked. Reply to the Stripe receipt email.

---

## Future versions

When the next version ships, the changelog grows upward. Each entry will name what was added, what was deprecated, and what was migrated. v1.x versions remain available to v1 buyers.
