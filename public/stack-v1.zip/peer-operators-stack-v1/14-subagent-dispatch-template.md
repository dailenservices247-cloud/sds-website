# Skill 14: Subagent Dispatch Template

A template for deciding when to spawn a subagent, what to brief it with, and what return shape to require. Keeps the main thread focused; keeps the subagent's scope tight; gives a clean handoff back to the main session.

## When to use

Use this when a task in the current session is meaningfully separable from the main work: independent enough that doing it in the main thread would pollute context, and self-contained enough that a fresh-context agent can do it given a tight brief.

Concrete triggers:

- A research task you want done in parallel ("read these 30 GitHub issues and tell me which are about pricing")
- A scoped implementation chunk that doesn't need the main thread's full context ("write a script that does X, given these inputs, returning this shape")
- A verification or QA pass on existing work ("review this PR diff for security issues")
- An out-of-scope item you want flagged for later without derailing the current session

## NOT when to use

Skip subagents when:

- The task is short enough to do inline (under 5 minutes of main-thread time)
- The task needs the full conversation history to make sense
- The task is exploratory chat, not a defined unit of work
- You haven't written a clean brief yet: the cost of a vague brief to a subagent is much higher than the cost of a vague prompt to the main thread, because the subagent can't ask follow-up questions cheaply

## The dispatch template

```markdown
# Subagent brief: <one-sentence title>

## Goal
<single sentence stating what the subagent must produce>

## Inputs
- <input 1, with full content or absolute path>
- <input 2>

## Context the subagent does NOT have
- <thing it might assume but shouldn't>
- <relevant constraint not in inputs>

## Return shape
The subagent must return exactly:
- <field 1>: <description>
- <field 2>: <description>
- <field 3>: <description>

Format as a JSON object / markdown table / plain text — pick one and require it.

## What success looks like
<2-3 specific, checkable criteria>

## Out of scope
<things the subagent must NOT do, even if they look adjacent>
```

## Brief checklist before dispatching

Before you spawn, confirm:

- [ ] The goal is one sentence. If it's two, split into two subagent tasks
- [ ] All inputs are either inline or at absolute paths the subagent can read
- [ ] The "context the subagent does NOT have" section names at least one thing. If you can't think of one, you probably haven't thought hard enough about what's specific to your main thread
- [ ] The return shape is explicit. No "report findings"; specifically "return a table with these columns"
- [ ] The success criteria are checkable from the return, not from inspecting the subagent's reasoning
- [ ] The out-of-scope list is non-empty

If any are missing, fix the brief before dispatch. A bad subagent brief costs more than no subagent.

## After the subagent returns

1. Read the return shape only. Don't read the subagent's full conversation unless something looks off
2. Verify against the success criteria
3. If the return is good, integrate it back into the main thread with one sentence: "Subagent returned X. Continuing from where we were."
4. If the return is bad, decide whether to re-dispatch with a tighter brief or do the work in the main thread

## Underlying philosophy

A subagent is a tool, not a coworker. The main thread is where the real reasoning happens; the subagent is offloaded execution. Treating subagents as coworkers ("go figure out what we should do") is where they fail: they don't have the context to figure things out at that altitude. Treating them as tools ("given X, produce Y in Z format") is where they earn their keep.

The brief is the contract. A well-specified brief makes the subagent reliable. A vague brief makes it a coin flip.

## Adaptation

- For solo operators, subagents are most useful as a parallelization tool (research, batch processing). For most live coding work, the cost of context-handoff exceeds the benefit
- For larger workflows, you can chain subagents: subagent A produces input for subagent B. Be careful: each handoff is a fresh failure surface
- The "context the subagent does NOT have" section deserves the most attention. It's also the one operators skip most often, which is why their subagents underperform

## Before / after

Before: Main thread says "go review these 30 issues and tell me what they're about." Subagent returns 30 paragraphs of varying quality. You spend the saved time reading the paragraphs and re-extracting the structured signal you wanted.

After: Main thread sends the brief with return shape: `| issue # | category (one of: bug, feature, pricing, other) | one-line summary |`. Subagent returns a clean 30-row table. You scan it in 90 seconds and integrate the signal directly into the main work.
