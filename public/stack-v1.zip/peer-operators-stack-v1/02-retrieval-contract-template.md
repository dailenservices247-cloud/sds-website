# Skill 02: Retrieval Contract Template

A short markdown file per active project that defines exactly what the agent needs to know, what triggers a pull, the token budget per turn, and which rediscovery patterns are banned.

## When to use

Use this before you pick the infrastructure for memory on a new project (vector DB, graph store, MCP server, file system). The contract precedes the infrastructure. If you cannot describe what the agent needs to know in a single page, no amount of pgvector tuning will rescue the workflow.

Concrete triggers:

- Starting a new project that will run for more than one session
- An existing project keeps making the agent rediscover the same facts each turn
- You are about to add a third memory layer to a project that already has two
- A session burned a noticeable fraction of its context window re-reading handoff files

## Step-by-step

1. Create `AI Hub/Retrieval Contracts/<project>.md` (one file per active project)
2. Fill the four sections (below) honestly. Empty fields are a bug; mark them "n/a: banked" rather than blanking
3. Run the contract for two weeks. Track each session for: token spend on retrieval, number of rediscovery cycles, number of "we already decided this" moments
4. Update the contract based on what you observed. Tighten the banned anti-patterns. Loosen the budgets where you starved the agent
5. Lock the contract once a project is stable. Re-open only when the project's nature changes

## Template

```
---
project: <name>
agent_purpose: <one sentence>
authored_by: <you>
date: YYYY-MM-DD
---

## What the agent needs to know

| Fact type | Shape | Refresh cadence |
|---|---|---|

## Retrieval triggers

| When | What gets pulled | How filtered |
|---|---|---|

## Token budget per turn

- Max context loaded: <e.g. 8000 tokens>
- Max retrieval calls: <e.g. 3 per turn>
- Fallback when over budget: <e.g. summary-only, prompt the user>

## Anti-patterns banned

- <e.g. re-reading the handoff every turn>
- <e.g. searching the vault when the answer lives in the current chat>

## Status
draft | piloted | locked | superseded
```

## Underlying philosophy

Banked from a Nate B Jones lift about memory infrastructure wars. The wars are noisy; the actual discipline is upstream. You pick infrastructure to serve a contract; you do not write a contract to serve the infrastructure you already bought. A contract per project also forces the question of whether the project deserves persistent memory at all. Some projects don't; the contract is "load nothing, work from the prompt." That is a valid answer and writing it down saves the cost of an unused vector index.

## Adaptation

If you only have one project, write one contract. If you have a dozen, write contracts only for the three that are active this quarter. A retrieval contract for a dormant project is a museum piece. Refresh contracts on the same cadence you refresh handoffs: usually monthly, sometimes per-sprint. Pair with Skill 01 (atomic nodes) so the "what gets pulled" column has clean IDs to reference.

## Before / after

Before: Agent on a new session reads `handoff.md`, `CLAUDE.md`, the last 5 session logs, and the top of `Lessons Learned.md`. That burned ~12k tokens to learn what was already true. The agent then asked a question that was answered in week 2's session log it skipped.

After: Agent on a new session reads `RETRIEVAL.md`, which says "load `handoffs/<project>.md`, load the last decision node for this project, load nothing else." Token spend dropped to ~3k. The agent asks the user one question when context is missing instead of trying to find it in old logs.
