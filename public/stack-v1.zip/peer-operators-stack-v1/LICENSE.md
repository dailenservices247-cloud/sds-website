# License: Peer Operator's Stack v1

Copyright (c) 2026 Dailen Huntley / Black Sheep 247 LLC

## Single-buyer license

The Peer Operator's Stack (the "Stack") is licensed to a single buyer for internal use, modification, and adaptation. Permission is granted to:

- Use the Stack inside the buyer's own business
- Modify, fork, and adapt the patterns to fit the buyer's workflow
- Use modified versions internally without restriction
- Reference the Stack in writing, conversation, or training as long as attribution is reasonable

## What you may not do

- Resell the Stack as-is or with cosmetic modifications as a productized library
- Redistribute the unmodified files publicly (e.g., posting the raw markdown to a public repo, sharing a Dropbox link in a community)
- Claim authorship of the original patterns

Adapted versions you've meaningfully reworked may be shared in your own writing or teaching as your own work, with reasonable attribution to the source.

## What "reasonable attribution" means

If you reference the Stack in a public artifact (post, video, podcast, course), a one-line acknowledgment is enough. Something like:

> "Pattern adapted from Dailen Huntley's Peer Operator's Stack"

is reasonable. You don't owe a link or a citation block; the goal is honest credit, not formal academic attribution.

## Internal forks

The Stack is designed to be forked internally. Your fork is yours. You don't owe an update path back to the source. If your fork has improvements you want to share, an email or pull-request-style proposal is welcome but not required.

## Warranty

The Stack is provided "as-is" without warranty of any kind. The patterns work for the author and for many of the operators who've adopted them, but no outcome is guaranteed. Your stack, your call, your responsibility.

## Limitation of liability

In no event shall the author be liable for any claim, damages, or other liability arising from the use of the Stack. Maximum exposure is the price paid for the Stack ($149 USD at v1 launch).

## Anti-piracy stance

The author's stance on enforcement is intentionally lax. Pursuing pirates of a $149 productized library is not a productive use of an operator's time, and the practical experience of comparable libraries (Ryan Doser's Claude Code Skill Stack, others) is that enforcement yields net-negative ROI.

The buyer's decision to honor the license terms is treated as a question of personal posture, not a question of legal enforcement. The author trusts most buyers to be operators-of-good-faith. If you're not, you'll find it easier to share the files; the author would rather spend that time writing the v2 than chasing v1 pirates.

That said: meaningful resale or large-scale redistribution will be pursued. The lax stance is for individual sharing among friends; it isn't a green light for repackaging the Stack as someone else's product.

---

For licensing questions, reply to the Stripe receipt email.
