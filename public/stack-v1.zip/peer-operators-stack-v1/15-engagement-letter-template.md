# Skill 15: Engagement Letter Template

A short, scoped engagement letter for a one-shot productized service (audit, review, strategy session, paid call). Caps liability at fees paid. Defines scope. Names what's out of scope. Sets the refund policy. Names the IP arrangement. Names the law and dispute path.

## When to use

Use this any time you take payment for a service larger than $200. Below $200, a clear receipt is usually enough. Above $200, the engagement letter exists to disambiguate what you owe and what you don't if the relationship ever turns adversarial. The cost of having it is ten minutes per engagement. The cost of not having it can be the entire fee plus the cost of the dispute.

Concrete triggers:

- Selling a paid audit, review, or strategy call ($200 to $5,000 range)
- Selling a productized deliverable (PDF report, custom plan, written analysis)
- Doing a paid pilot for a prospective ongoing client
- Any consulting work where outcomes depend on the buyer's actions, not yours

## The template

```markdown
# <Service Name> — Engagement Letter

**Service Provider:** <Your legal entity, DBA name if applicable>
**Client:** [Client legal name and entity]
**Engagement Date:** [Date of payment]
**Service:** <Productized service name>

---

## 1. Scope of Services

<Service Provider> will deliver:

- <Deliverable 1, specific>
- <Deliverable 2, specific>
- <Deliverable 3, specific>

**Out of scope (unless separately contracted):**

- Implementation work, code, or deployment
- Ongoing advisory or retainer
- Custom software, agents, or workflows
- Warranty of outcomes from following recommendations
- Legal, financial, tax, or regulatory compliance advice

## 2. Fees and Payment

Total fee: USD $<amount>, paid in full via <payment method> before <work begins / call begins>. <Service Provider> reserves the right to cancel any engagement for which payment has not cleared.

## 3. Refund Policy

- Full refund if requested in writing more than 24 hours before <work begins>
- Refunds inside 24 hours are at <Service Provider>'s discretion
- After <work has commenced>, no refunds, including if Client disagrees with the recommendations

## 4. Limitation of Liability

**<Service Provider>'s total cumulative liability arising from this engagement is capped at the fees paid by Client (maximum USD $<amount>).** This cap applies to all claims, whether in contract, tort, negligence, or any other theory, including consequential, incidental, special, or punitive damages.

Client acknowledges that <Service Provider> provides strategic recommendations only, not warranties or guarantees of outcomes. The decision to act on recommendations is solely Client's responsibility.

## 5. Confidentiality

Both parties agree to keep confidential any non-public business information shared. <Service Provider> will not share Client's information with third parties without written consent, except as required by law.

**Recording (if applicable):** Calls may be recorded for note-taking and report-generation purposes only. Recordings are deleted within 90 days of report delivery and will not be shared externally.

## 6. Intellectual Property

- Client owns the final written deliverable and may use it internally without restriction
- <Service Provider> retains ownership of the underlying methodology, frameworks, and templates used to produce the deliverable
- Neither party may publish, repost, or redistribute the deliverable without the other's written consent
- <Service Provider> may reference the engagement at a generic level (e.g., "an architecture review for a fintech founder") in marketing without identifying Client by name

## 7. Independent Contractor

<Service Provider> is an independent contractor. No employment, partnership, joint venture, or agency relationship is created. <Service Provider> is responsible for its own taxes, expenses, and tools.

## 8. Termination

Either party may terminate this engagement in writing before <work begins>. Post-termination, Section 3 applies.

## 9. Disputes

Disputes will first be attempted in good-faith negotiation. If unresolved within 30 days, disputes will be submitted to binding arbitration in <state>, under the American Arbitration Association's Commercial Arbitration Rules. Each party bears its own legal costs.

## 10. Governing Law

This engagement is governed by the laws of <state>, without regard to conflict-of-law principles.

## 11. Entire Agreement

This document is the entire agreement between the parties regarding the service. Amendments require written consent of both parties.

---

## Client Acknowledgment

By proceeding with payment via the payment link associated with this engagement, Client acknowledges they have read, understood, and agree to these terms.
```

## How to deliver

- Attach as PDF to the Stripe receipt email, OR
- Attach as PDF to the Calendly confirmation email, OR
- Paste into a Google Doc, share read-only with the client, request acknowledgment via reply (manual fallback)

Render the markdown to PDF with `pandoc -o engagement.pdf engagement.md` or any markdown-to-PDF tool.

## Underlying philosophy

This template treats the engagement letter as part of the product, not as paperwork. A clean letter signals: this person has done this enough times to know what to put in writing. That signal helps close. The letter also stops the most common dispute pattern, which is misaligned scope expectations.

The liability cap matters. Without it, you carry tail risk that scales with the buyer's downside, which can be many multiples of your fee. With it, your exposure is bounded at the fee.

## Adaptation

- Replace `<state>` with the state of your business formation. For most US solo operators that's Wyoming, Delaware, or the state of residence
- The 24-hour refund window can move to 48 or 72 if your service has a longer lead time
- Section 6 (IP) can stay as-is for most one-shot deliverables. For ongoing engagements, the IP arrangement gets more complex and you want a lawyer
- This is a template, not legal advice. Get an attorney in your state of formation to review before adoption. Basic contract review usually runs $200 to $500

## Before / after

Before: A client pays $1,500 for an audit. They disagree with one recommendation. They ask for a refund. You have no written scope, no liability cap, and no refund policy. The dispute eats a week of your time and you partial-refund to end it.

After: Same client, same disagreement. You point at Section 3 of the engagement letter they implicitly accepted at payment. The dispute resolves in one email. The cap in Section 4 limits worst-case exposure to the fee.
