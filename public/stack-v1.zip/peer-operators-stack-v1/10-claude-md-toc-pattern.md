# Skill 10: CLAUDE.md Table-of-Contents Pattern

A CLAUDE.md file kept under 200 lines that acts as a table of contents pointing the agent at the right specialized doc for the task at hand. Stops the CLAUDE.md sprawl that kills agent performance once the file gets past a few hundred lines.

## When to use

Use this when your CLAUDE.md has grown past 200 lines, when you're tempted to add another section to an already-long CLAUDE.md, or when you're starting a new project and want to set the discipline at the start before sprawl sets in.

Concrete triggers:

- Your CLAUDE.md is over 300 lines
- The agent keeps citing the wrong part of CLAUDE.md, suggesting it's lost in the file
- Adding a new instruction would push a section past where the agent reads in early turns
- You're starting a new repo and don't want to make the same mistake again

## The pattern

CLAUDE.md becomes a router, not a knowledge base. The structure:

```markdown
# CLAUDE.md — <project>

This file is the source of truth for Claude Code on this project.
Read this before writing any code.

## Where to look for things

| Topic | File |
|---|---|
| Architecture & stack | `docs/ARCHITECTURE.md` |
| Routing & navigation | `docs/ROUTING.md` |
| Data model & migrations | `docs/DATABASE.md` |
| Auth & permissions | `docs/AUTH.md` |
| Brand voice & copy | `docs/VOICE.md` |
| Active TODOs | `_handoff.md` |
| Banned actions | `_handoff.md` (see "DO NOT" section) |

## Mandatory workflow before any feature work

1. Read `_handoff.md`
2. Run gap analysis (see `docs/GAP-ANALYSIS.md`)
3. Get explicit go-ahead before writing code

## MUST DO
- <up to 10 universal rules>

## MUST NOT DO
- <up to 10 universal banned actions>

## Quick commands
| Command | What it does |
|---|---|
| `npm run dev` | local server |
| `./checkpoint.sh "msg"` | save working state |
```

Target: under 200 lines. Hard cap: 250. Past 250, factor more out into specialized docs.

## What goes in CLAUDE.md vs. specialized docs

**Stays in CLAUDE.md:**

- The pointer table to specialized docs
- The mandatory pre-work workflow (so the agent runs it every session)
- Universal MUST DO / MUST NOT DO that applies regardless of task
- Quick commands the agent needs every session

**Moves to specialized docs:**

- Architecture diagrams and stack descriptions
- API endpoints and routes
- Database schema and migration patterns
- Auth flow and role definitions
- Brand voice rules, banned-words list, voice examples
- Project history, completed phases, deprecated approaches

## Why under 200 lines

Agents read CLAUDE.md at session start. The longer the file, the more context budget you spend before any useful work begins. Past 200 lines, the agent starts to lose the early-section content by the time it gets to the late-section content. A focused table of contents loads quickly, points the agent at the relevant deeper doc, and keeps the rest of the context budget for actual work.

The other reason: a 200-line cap forces editorial discipline. If a new instruction can't fit, something has to either move out to a specialized doc or be cut. That pressure produces a sharper CLAUDE.md over time.

## Underlying philosophy

The original CLAUDE.md anti-pattern was treating it as a kitchen sink. Every "while we're here" instruction got appended. The file grew to 800 lines. The agent's behavior degraded because most of the file was no longer relevant to most tasks. The TOC pattern flips this: CLAUDE.md is a small, stable router; specialized docs carry the domain weight and are loaded only when relevant.

Pairs with retrieval contracts (Skill 02): the TOC is the in-repo version of a retrieval contract, telling the agent where to find what.

## Adaptation

- For tiny projects, you may not need CLAUDE.md at all. A `_handoff.md` and a `README.md` cover it
- For monorepos, each app folder can have its own CLAUDE.md that links to a shared `docs/` root
- The pointer table is the most-edited part. Re-export it quarterly to make sure dead doc references don't accumulate
- When a specialized doc becomes irrelevant, delete it and remove the pointer from CLAUDE.md. Don't archive into oblivion

## Before / after

Before: 760-line CLAUDE.md. Agent reads it, burns ~7k tokens, then asks a question that was answered on line 612. The user repeats the answer; the agent finds it; the work continues. This happens every session.

After: 140-line CLAUDE.md. Agent reads it in ~1.5k tokens, sees the topic table, loads only `docs/AUTH.md` (~600 lines) because the task is auth-related. Total: ~7k tokens, but now the agent has the auth content fully in working context instead of buried.
