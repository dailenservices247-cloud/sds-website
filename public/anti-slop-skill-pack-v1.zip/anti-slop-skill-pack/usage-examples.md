# Usage Examples — SDS Anti-Slop Skill Pack v1

10 before/after rewrites drawn from real production work — landing pages, LinkedIn posts, sales DMs, video scripts.

Each example shows what the skill flags + the cleaned version.

---

## Example 1 — Hype-tone landing page hero

**Before:**
> Supercharge your AI workflow with our revolutionary new platform. Transform the way you build, leverage cutting-edge models, and unlock 10x productivity. It's a game-changer.

**Flags:**
- `supercharge` (hype)
- `revolutionary` (hype)
- `transform` (hype)
- `leverage` (influencer verb)
- `cutting-edge` (hype)
- `unlock` (hype filler)
- `10x productivity` (hype + abstract)
- `game-changer` (hype)
- Zero specific claims. Fails Check 1.
- No honest acknowledgment of tradeoffs. Fails Check 2.
- Marketing-voice. Fails Check 3.

**After:**
> Build with AI agents that remember decisions across sessions. Twenty patterns Dailen Huntley uses inside Black Sheep 247 LLC to stop memory drift, voice drift, and hallucination from costing real hours. $149 once. Lifetime v1.x access.

---

## Example 2 — Filler-heavy LinkedIn post

**Before:**
> I just wanted to share something I'm really excited about. We're basically launching this new thing that's just absolutely going to change everything. It's literally the best thing I've ever built.

**Flags:**
- `just` × 2 (filler)
- `really` (filler)
- `basically` (filler)
- `just` (third instance, filler)
- `absolutely` (filler)
- `literally` (filler)
- `I'm so excited to share` pattern (influencer cold-open)
- `going to change everything` (hype, no specifics)
- `the best thing I've ever built` (superlative, no comparison)

**After:**
> Shipped Peer Operator's Stack v1 today. Twenty patterns I use inside my own AI builds to stop context drift, voice drift, and hallucination. $149. Built it because the patterns I use weekly weren't anywhere I could buy them — so I wrote them down.

---

## Example 3 — Grindset cold DM

**Before:**
> Hey Sarah! Hope you're crushing it this week 💪 Quick question — are you still grinding on that Q4 push? I know hustlers like us never sleep. Want to hop on a call to talk strategy?

**Flags:**
- `crushing it` (grindset)
- `grinding` (grindset)
- `hustlers like us` (grindset + audience-coding)
- `never sleep` (grindset)
- `hop on a call to talk strategy` (vague sales-coded ask)
- Emoji-first opener (banned)
- Generic outreach ("are you still grinding on...") signals copy-paste DM

**After:**
> Sarah, saw your post on the Q4 launch sequence. The retention number you cited (84% week-2) is unusual for a B2C SaaS at your tier. Was that with onboarding email v2 (Customer.io) or v3 (Klaviyo)? I'm running the same comparison for a client and getting different data. Open to trading numbers?

---

## Example 4 — Influencer-vocabulary video script

**Before:**
> Imagine if you could leverage the power of AI to level up your business in just minutes per day. Picture this: you, sipping coffee while your AI hustles for you. Today I'm going to show you how to make this dream a reality.

**Flags:**
- `imagine if you could` (influencer cold-open)
- `leverage` (verb form, banned)
- `level up` (grindset)
- `picture this` (influencer cold-open)
- `hustles for you` (grindset)
- `make this dream a reality` (motivational-coach)
- `I'm going to show you` (no specifics about what)

**After:**
> Claude can't generate images on its own. Today we fix that. Four minutes of setup. Free tier works. By the end you'll have Claude calling Higgsfield to make any image you describe, plus the save-as-skill pattern so you don't redo the setup every time.

---

## Example 5 — Exit-fetishism founder pitch

**Before:**
> We're building the next billion-dollar AI company. Our paradigm-shifting technology will disrupt the entire industry. Year 5 we hit a $100M exit easy. Investing now is the asymmetric bet of the decade.

**Flags:**
- `billion-dollar AI company` (exit-fetishism)
- `paradigm-shifting` (hype)
- `disrupt the entire industry` (hype + vague)
- `$100M exit easy` (exit-fetishism + overclaim)
- `asymmetric bet of the decade` (hype + scarcity)
- Zero specific traction or milestones

**After:**
> We're building a productized library for solo AI builders. Year 1 target: 100 paying customers at $149 each. Year 2 target: 500 customers, plus a tier-2 retainer offering ($3-5K/mo) for the ones who want more. Honest near-term: 4 sold in week 1 of soft launch. Honest far-term: we're banking that solo-AI-builder TAM is large enough; we'd take a $5M lifestyle business at year 5 over a $100M exit chase.

---

## Example 6 — Scarcity-FOMO sales page

**Before:**
> Don't miss out! Get it while the getting's good. The window is closing fast — only 5 spots left at this price. Your last chance to lock in lifetime access before we 10x the price.

**Flags:**
- `Don't miss out` (scarcity-FOMO)
- `get it while the getting's good` (scarcity)
- `the window is closing` (scarcity)
- `only 5 spots left` (artificial scarcity for digital product)
- `your last chance` (scarcity)
- `lock in` (grindset)
- `10x the price` (hype)

**After:**
> Stack v1 is $149 through 2026-06-30. After that, v1.x is still $149 if you've already bought (lifetime access). New buyers after 2026-06-30 will pay v1.1 pricing — likely $179, possibly $199 depending on the v1.1 scope decision. The honest reason: not artificial scarcity, just normal price-up after the launch window proves the offering.

---

## Example 7 — Em-dash overuse in body

**Before:**
> The Stack is for solo founders — the ones who actually ship — building with AI agents — Claude Code, Cursor, Codex — and have hit the wall — memory drift, voice drift, hallucination.

**Flags:**
- 5 em-dashes in body (banned; max = 1 em-dash, only in signoff)
- Sentence has lost rhythm under em-dash overload

**After:**
> The Stack is for solo founders who actually ship. Building with AI agents (Claude Code, Cursor, Codex). They've hit the wall: memory drift, voice drift, hallucination.

---

## Example 8 — Marketing-voice landing page

**Before:**
> We empower entrepreneurs to achieve more. Our world-class platform delivers state-of-the-art results that move the needle for your business. Join thousands of founders who've already transformed their workflows.

**Flags:**
- `empower` (marketing-voice)
- `entrepreneurs to achieve more` (vague)
- `world-class platform` (no specific metric)
- `state-of-the-art` (hype, no specific capability)
- `move the needle` (vague)
- `join thousands` (no actual number)
- `transformed` (hype, no specific change)

**After:**
> Twenty patterns from inside Black Sheep 247 LLC's actual workflow. Built by Dailen Huntley, used weekly by Dailen Huntley. Sold to other operators who recognized the patterns they'd been re-inventing every week. Four sales in the first 14 days. Honest 30-day target: 30 sales. Honest 90-day target: 100.

---

## Example 9 — Filler-heavy email reply

**Before:**
> Hey! So I just wanted to follow up — I'm basically really excited about this and I just think we should literally hop on a call ASAP. It would actually be super valuable for both of us.

**Flags:**
- `just` × 2 (filler)
- `basically` (filler)
- `really` (filler)
- `literally` (filler)
- `actually` (filler)
- `super valuable` (vague intensifier)
- Single em-dash in body (banned)

**After:**
> Following up on the Stack v1 discussion. Picking your brain on two specific things: (1) what landing-page copy resonated, (2) what didn't. Got 15 min Wednesday between 2 and 4 ET? If not, an email reply with your answers is fine — I'd rather have your real read in writing than a forced call.

---

## Example 10 — Combined slop (hard mode)

**Before:**
> 🚀 Exciting news! We're absolutely thrilled to announce our revolutionary new AI platform that's going to supercharge your workflow and 10x your productivity. Just imagine — leveraging cutting-edge models to literally transform the way you work. It's a real game-changer for hustlers ready to level up. Don't miss out on this paradigm shift!

**Flags:**
- Emoji-first opener (banned)
- `Exciting news` (influencer cold-open)
- `absolutely thrilled` (filler + corporate)
- `revolutionary` (hype)
- `supercharge` (hype)
- `10x your productivity` (hype + vague)
- `Just imagine` (influencer)
- `leveraging` (influencer verb)
- `cutting-edge` (hype)
- `literally` (filler)
- `transform` (hype)
- `game-changer` (hype)
- `hustlers` (grindset)
- `level up` (grindset)
- `Don't miss out` (scarcity)
- `paradigm shift` (hype)
- Em-dash in body (banned)

**Voice score: 0/10. Complete rewrite required.**

**After:**
> Shipped Peer Operator's Stack v1 today. Twenty patterns I run inside Black Sheep 247 LLC to stop AI agents from drifting across sessions. Atomic-node memory format. Retrieval contracts. Brand-voice linter. $149 once, lifetime v1.x access, 14-day refund. If those patterns sound like ones you've also been re-inventing weekly: synapsedynamics.io/stack. If not, no worries.

---

**End of usage examples. The skill in `SKILL.md` automatically applies the same flagging + replacement logic across any draft you give it.**
