# Changelog — SDS Anti-Slop Skill Pack

## v1.0.0 — 2026-05-20

Initial public release. $49 one-time, lifetime v1.x access.

### Shipped

- `SKILL.md` — main skill (paste into Claude.ai Custom Instructions OR save at `~/.claude/skills/anti-slop/SKILL.md` for Claude Code)
- `banned-words-list.md` — six-category blocklist with replacement suggestions (hype / filler / influencer / grindset / exit / scarcity)
- `voice-fingerprint-scan.md` — 4-check pre-publish pass (Specific / Honest / Peer / Banned-phrase)
- `usage-examples.md` — 10 before/after rewrites from real production work
- `README.md` — overview + what's inside + how to use
- `INSTALL.md` — three install modes (Claude.ai / Claude Code / Project knowledge)
- `LICENSE.md` — MIT
- `CHANGELOG.md` — this file

### Authored from

Production brand-voice-linter inside Black Sheep 247 LLC (parent of Synapse Dynamics Segmented). Specifically: the brand voice docs for Day One AI (`dayoneai-voice.md`), Allday 24seven (`allday24seven-voice.md`), and NeoHood (`neohood-voice.md`).

### Known limitations

- Default blocklist is opinionated (reflects SDS / anti-hype / anti-influencer-bro voice). Forking encouraged.
- "Domain term vs hype" disambiguation requires context — the skill flags borderline cases rather than auto-rewriting them.
- No automatic linter binary; this is a Claude skill, not a CLI tool. Use Claude's normal interface.

### Planned for v1.1 (banked, no fixed date)

- Brand-voice-doc cross-check pass (auto-detect which brand's voice doc applies to the draft)
- "Severity tier" scoring (light slop vs heavy slop)
- Additional category: corporate-press-release voice (separate from AI-influencer voice)
- More usage examples (~25 total)

### v1.x lifetime access

Anyone who bought v1.0 gets every v1.x release free. Email `dailen@synapsedynamics.io` if you don't receive a notification when v1.1 ships.
