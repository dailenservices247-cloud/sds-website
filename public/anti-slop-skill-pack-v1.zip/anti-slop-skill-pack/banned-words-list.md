# Banned Words List — SDS Anti-Slop Skill Pack v1

The canonical blocklist used by `SKILL.md`. Six categories. Each entry includes a replacement suggestion.

Fork this file for your brand. Add, remove, or adjust freely.

---

## Category 1 — Hype / AI-marketing-speak

| Banned phrase | Replacement suggestion |
|---|---|
| supercharge / supercharged | "speed up" / "shorten" / "compress" / drop entirely |
| unlock (as verb / filler) | "open" / "enable" / drop |
| transform / transformative / transformation | name the specific change ("cuts X by Y%") |
| 10x / 10x'd / 10x'ing | name the actual multiplier or drop |
| revolutionize / revolutionary | "change" / "shift" / drop |
| game-changer / game-changing | "useful" / specific benefit |
| paradigm shift | name the actual structural change |
| disruptive | name what's being disrupted, specifically |
| next-level | "better at X" or specific metric |
| cutting-edge / bleeding-edge | "current" / "new" / drop |
| state-of-the-art | name the specific capability |
| world-class | name the specific quality metric |
| best-in-class | name the comparison and the metric |
| breakthrough | name the specific result |
| game-changing | see "game-changer" |

## Category 2 — Filler intensifiers

| Banned phrase | Replacement suggestion |
|---|---|
| just (as filler — "just want to" / "just trying to") | delete |
| really (intensifier — "really like" / "really good") | delete or replace with specific descriptor |
| basically | delete |
| actually | delete in most uses |
| simply | delete or restructure |
| literally | delete |
| absolutely | delete or replace with "yes" / specific |
| totally | delete |
| obviously | delete (assumes the reader's understanding) |
| clearly (as filler) | delete (same reason) |
| very (as intensifier on adjective) | use stronger adjective instead |
| super (as filler — "super useful") | delete or use specific descriptor |

**NOTE:** These words have valid uses in specific contexts. "Actually" can correct a misconception. "Literally" is fine when used literally. The skill should flag, not auto-delete.

## Category 3 — AI-influencer vocabulary

| Banned phrase | Replacement suggestion |
|---|---|
| leverage (as verb — "leverage AI") | "use" / "apply" / specific action verb |
| level up / leveling up | "improve at X" / "build X skill" |
| ecosystem (when really meaning "set of tools") | "set of tools" / "stack" |
| synergy / synergize | name the actual interaction |
| imagine if you could | lead with the actual outcome |
| think about what it would mean for | lead with the actual benefit |
| picture this | drop; describe directly |
| I'm so excited to share | drop; open with the substance |
| drum roll please | drop entirely |
| real quick I'm going to show you | drop; just show |
| spoiler alert | drop or restructure |
| here's the thing | drop or replace with specific |
| at the end of the day | drop |
| moving forward | "going forward" / drop / specific |
| circle back | "follow up" / specific |
| double down | "commit to X more" / specific |
| pivot (overused) | "change direction" / specific change |
| bandwidth (as filler) | "time" / "capacity" |
| reach out (overused) | "email" / "message" / specific |
| ping (verb form) | "message" / "text" / "email" — specific channel |

## Category 4 — Motivational-grindset / influencer-bro

| Banned phrase | Replacement suggestion |
|---|---|
| hustle / hustling / hustler | "work" / "shipping" / specific action |
| grind / grinding | "work" / specific action |
| passionate / passion (over-used as flag) | name what the speaker actually cares about specifically |
| lock in / locked in | "focused" / "committed" |
| side hustle | "side project" / "second income stream" |
| crush it / crushing it | name the specific result |
| killing it | name the specific result |
| no excuses | drop entirely (gatekeeping signal) |
| get up early grind hard | drop entirely |
| no days off | drop |
| sleep when you're dead | drop |
| if you don't X you're Y | gatekeeping framing — restructure to be inclusive |
| believe in yourself | drop (motivational-coach signal) |

## Category 5 — Exit-fetishism / unicorn framing

| Banned phrase | Replacement suggestion |
|---|---|
| $100M exit / $1B exit | drop or name the actual revenue / margin you're targeting |
| billion-dollar business | drop or name actual revenue target |
| unicorn (in startup sense) | drop |
| 10-figure | drop |
| become the next [BigCo] | drop or specific differentiation |
| disrupt [BigCo] | name the specific gap, not the abstract verb |
| build to flip / flip-and-build | reveal honestly: are you actually building to sell? |
| acquisition (assumed inevitable) | don't assume the exit; describe the next-step |

## Category 6 — Scarcity-FOMO / urgency-FOMO

| Banned phrase | Replacement suggestion |
|---|---|
| get it while the getting's good | name the specific timing reason (e.g., "before the next price tier") |
| the window is closing | name the actual window |
| limited time only | name the specific date / count |
| don't miss out | drop |
| your last chance | name the actual deadline |
| while supplies last | use only if literally true (digital products: rarely true) |
| spots are filling fast | use only if true; cite count |
| only N seats left | use only if true; cite the actual N |
| the asymmetric bet of [time period] | drop |
| the deal of the century | drop |

---

## Replacement principles

When in doubt, replace with:

1. **A specific number, date, or example.** "Took 8 minutes" beats "fast." "$17.40/mo" beats "affordable."
2. **The named outcome instead of the meta-verb.** "Cuts onboarding from 3 days to 30 min" beats "transforms onboarding."
3. **The honest acknowledgment.** "We tried X, it broke in production after 2 weeks" beats "We pivoted from X."
4. **The mechanical step.** "Click 'Settings' top-right" beats "navigate to the configuration interface."
5. **Nothing.** Often the right replacement for a banned phrase is to delete it entirely. The sentence reads better.

---

## Brand-specific extensions

Different brands ban different things. SDS / Black Sheep 247's specific extensions:

**Synapse Dynamics Segmented:**
- No em-dashes in body (signoff em-dash exempt)
- No "Inter" / "Arial" as default body font references in content
- Use "operator" or "builder," NOT "engineer" / "developer" for ICP

**Day One AI:**
- See `dayoneai-voice.md` §6 banned phrases
- Plus: no gatekeeping ("if you don't know X you're behind")
- Plus: no anti-positioning against other tutorial creators

**Allday 24seven:**
- See `allday24seven-voice.md` §6 banned phrases
- Plus: name actual tool costs ($17.40/mo Higgsfield Pro, not "affordable")
- Plus: founder fingerprint phrases (max 1-2 per post)

**NeoHood:**
- See `neohood-voice.md` §6 banned phrases
- Plus: no Web3-Twitter slang (wagmi / gm / lfg / wen)
- Plus: canon vocabulary LITERAL (AI Black / Sovereign Engine / Neural Bar, never paraphrased)
- Plus: no anime-cosplay sincerity-mockery

Fork the blocklist as needed. Brand-specific bans go in `banned-words-<brand>.md` next to this file.

---

**End of blocklist. The skill in `SKILL.md` reads this file (or whatever fork you point it at).**
