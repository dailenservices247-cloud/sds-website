# Install — SDS Anti-Slop Skill Pack v1

Three install modes. Pick the one that fits how you use Claude.

---

## Mode 1 — Claude.ai (web / mobile)

Best for: occasional voice-checking on the go, no local install required.

### Setup (one-time, ~2 min)

1. Go to claude.ai → Settings (top-right profile icon) → Custom Instructions (or "Profile" in older UI)
2. Open `SKILL.md` from this pack
3. Copy the ENTIRE contents of `SKILL.md`
4. Paste into Claude's Custom Instructions field
5. Save

### Use

1. Open a new conversation on claude.ai
2. Paste the draft you want voice-checked
3. Say: "run anti-slop on this"
4. Claude returns the flagged + cleaned version per the skill's pipeline

### Limitation

Custom Instructions has a character cap (~8000 in current Claude.ai). If you exceed it (e.g., layering multiple skills), use Mode 2 instead.

---

## Mode 2 — Claude Code (local CLI / Desktop)

Best for: integrating into your daily build workflow. Recommended if you use Claude Code daily.

### Setup (one-time, ~3 min)

1. Open terminal
2. Create the skill directory: `mkdir -p ~/.claude/skills/anti-slop`
3. Copy `SKILL.md` into `~/.claude/skills/anti-slop/SKILL.md`:
   ```bash
   cp /path/to/this-pack/SKILL.md ~/.claude/skills/anti-slop/SKILL.md
   ```
4. Also copy the supporting files so the skill can reference them:
   ```bash
   cp /path/to/this-pack/banned-words-list.md ~/.claude/skills/anti-slop/
   cp /path/to/this-pack/voice-fingerprint-scan.md ~/.claude/skills/anti-slop/
   ```
5. Verify by listing: `ls ~/.claude/skills/anti-slop/`
   You should see: `SKILL.md`, `banned-words-list.md`, `voice-fingerprint-scan.md`

### Use

In any Claude Code session:

```
> Run anti-slop on this draft:
> [paste your draft]
```

Claude Code auto-discovers the skill from `~/.claude/skills/anti-slop/SKILL.md` and applies the pipeline.

---

## Mode 3 — Claude.ai Project knowledge

Best for: brand-specific use case where you want to layer the skill with your brand voice doc.

### Setup (one-time, ~4 min)

1. Create a new Claude.ai Project (or use existing brand-voice Project)
2. Project Settings → Custom Instructions → paste `SKILL.md`
3. Project Knowledge → upload these files:
   - `banned-words-list.md`
   - `voice-fingerprint-scan.md`
   - `usage-examples.md`
   - YOUR brand voice doc (e.g., `dayoneai-voice.md`)
4. Save

### Use

Open a conversation in the Project. The skill + your brand voice doc are both in context. Paste any draft. Claude applies the default blocklist + your brand-specific layer simultaneously.

---

## Verifying the install

Whichever mode you used, sanity-check by pasting this test draft:

```
We're really excited to share our supercharged new platform that's going to leverage AI to 10x your productivity. Just imagine the possibilities!
```

Claude should return:
- A flag list with at least 6 hits (`really`, `supercharged`, `leverage`, `10x`, `Just`, `imagine`)
- A cleaned version that drops the hype + filler
- A voice score around 1-2/10

If you get back something different (or no flag list), the skill isn't loaded. Re-check Mode 1/2/3 install steps.

---

## Updating to v1.1+ (when ships)

This pack ships as v1.0. Future updates (v1.1, v1.2 etc.):

- **Mode 1 users:** re-paste the new SKILL.md into Custom Instructions
- **Mode 2 users:** `cp` the new files over the existing ones in `~/.claude/skills/anti-slop/`
- **Mode 3 users:** re-upload the new files to Project Knowledge

Changelog at `CHANGELOG.md` will document what changed each version.

---

## Forking for your brand

Standard recommendation: don't run the default blocklist alone. Fork it.

1. Copy `banned-words-list.md` to `banned-words-<your-brand>.md`
2. Remove banned phrases your brand actually WANTS
3. Add brand-specific phrases (industry jargon, internal slang, etc.)
4. Adjust replacement suggestions to your brand's preferred phrasing
5. Save your fork next to `banned-words-list.md`
6. In Claude, tell the skill: "use banned-words-myBrand.md as the blocklist instead of the default"

The skill's value isn't the default list. It's the discipline of having a list at all + running every draft through it.

---

**Install troubleshooting:** if anything is unclear, email `dailen@synapsedynamics.io` with the install mode you're using and what's not working. Refund window is 14 days from purchase.
