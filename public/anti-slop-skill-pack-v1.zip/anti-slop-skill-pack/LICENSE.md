# MIT License — SDS Anti-Slop Skill Pack v1

Copyright (c) 2026 Dailen Huntley / Black Sheep 247 LLC

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Skill Pack"), to deal in the Skill Pack without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Skill Pack, and to permit persons to whom the Skill Pack is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Skill Pack.

THE SKILL PACK IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SKILL PACK OR THE USE OR OTHER DEALINGS IN THE SKILL PACK.

---

## Plain English

You bought it. You own your copy. Use it, fork it, adapt it. Attribution appreciated, not required. No warranty implied. If it breaks something, you pay for it, not me. Standard MIT.

If you ship a derivative work commercially, a one-line credit ("based on the SDS Anti-Slop Skill Pack by Dailen Huntley") in your readme is nice but not legally required.
