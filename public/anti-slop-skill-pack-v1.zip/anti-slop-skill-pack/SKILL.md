# SDS Anti-Slop Skill

**Skill purpose:** Take a draft (landing page, post, DM, script, email) and strip banned phrases, hype-tone, AI-influencer vocabulary, filler intensifiers, motivational-grindset framing, exit-fetishism, and scarcity-FOMO before publish.

**Triggered when** the user says any of: "run anti-slop on this" / "voice-check this draft" / "anti-slop scan" / "lint this" / "clean this for voice" / "brand-voice-check this" — OR before any user-facing copy is finalized.

---

## Inputs

The user provides:
- A draft (paragraph or longer)
- Optional: a brand voice doc the draft should match (e.g., `dayoneai-voice.md`, `allday24seven-voice.md`)
- Optional: surface type (landing page / LinkedIn post / cold DM / video script / sales email)

If no brand voice doc is provided, use the default blocklist in `banned-words-list.md`.

## Pipeline

### Step 1 — Banned-phrase scan

Read the input draft. Scan for every entry in the default blocklist (`banned-words-list.md`). Build a flag list of every hit with:
- The exact phrase found
- The line / sentence it appears in
- The category (hype / filler / influencer / grindset / exit / scarcity)
- A suggested replacement

### Step 2 — Voice fingerprint scan (4 checks)

Per `voice-fingerprint-scan.md`:

1. **Specific?** — Does the draft use real numbers, real timestamps, real tool names, real $$? If a sentence works for any company in the same lane, flag it as "too abstract."
2. **Honest?** — If the work being described broke or stalled at some point, does the draft say so? If a wait-state or unknown exists, does it name it?
3. **Peer voice?** — Would the writer actually say this to a friend at coffee, or does it read as LinkedIn / marketing-page voice?
4. **Banned-phrase clear?** — Step 1 above; cross-check no banned phrase slipped through.

Flag any fail. Recommend a rewrite.

### Step 3 — Em-dash check

In the body of the draft, count em-dashes (`—` U+2014).

**Rule:** Em-dashes in body = banned. Only exception = the signoff (a single em-dash before a name is allowed and read as byline style).

For every body em-dash, suggest replacement with: period, comma, or parenthetical pair `( )`. Pick the punctuation that best preserves the rhythm of the sentence.

### Step 4 — Output structure

Return THIS exact format:

```
## Anti-Slop Scan Result

### Original (unchanged)
<the user's draft, verbatim>

### Flags found
- [HYPE] "supercharge" → suggest: "speed up" / "shorten" / "compress" — appears in line N
- [FILLER] "just" → delete or replace with "only" — appears in line N
- [INFLUENCER] "imagine if you could" → delete; lead with the outcome — appears in line N
- [EM-DASH] body em-dash in line N → replace with period / comma / parenthetical
- [VOICE: not-specific] line N — "drives engagement" is too abstract. Suggest naming the actual metric or audience.
- [VOICE: not-honest] line N — claim implies success without acknowledging the failure path. Suggest naming what didn't work.
- (etc.)

### Cleaned draft
<the draft with all flags applied — banned phrases replaced, em-dashes fixed, voice issues rewritten>

### Voice score
N / 10 (where 10 = no flags, 0 = severe slop)

### Notes
<1-2 sentences explaining the most-significant rewrites>
```

## Behavior rules

- **NEVER add hype, sales-influencer, or marketing language to a draft.** This skill removes; it does not add. If the user's draft is already clean, return the unchanged draft with a 10/10 score and a one-line confirmation.
- **NEVER introduce vagueness.** Concrete > abstract. If the user wrote "took 8 minutes," do not generalize to "saves time."
- **NEVER add em-dashes in body.** Even when restructuring a sentence, prefer periods / commas / parentheticals.
- **Preserve voice signature.** If the user's voice has distinctive moves (specific quirks like "right?" tag, naming dollar amounts, calling out failure modes), keep those. The point is to strip slop, not strip personality.
- **When in doubt, flag rather than rewrite.** If a phrase is borderline (e.g., "scale" can be banned slop or legitimate domain term), surface it as a flag with both options. Let the user decide.
- **No false positives on domain terms.** "Leverage" as a verb is banned. "Leverage point" or "leverage ratio" as a noun in business / engineering / physics context is fine. Use context.
- **Em-dash in signoff is exempt.** A single em-dash before a name at end of post/email is byline convention. Don't flag.

## Optional: brand-voice cross-check

If the user provides a brand voice doc (e.g., paste `dayoneai-voice.md`), do a secondary pass:

1. Read the voice doc's "Banned" + "Encouraged" sections.
2. Layer the brand's specific banned list ON TOP of the default blocklist.
3. Flag any phrase that hits either list.
4. Apply the brand's voice attributes (e.g., "show the click," "peer-honest," "name the cheap path") to the rewrites.

This lets the same skill work across multiple brand surfaces without rewriting the skill.

## Fork guidance for the user

The default blocklist reflects SDS / Black Sheep 247 voice. Forking is encouraged:

- Add brand-specific banned phrases to `banned-words-list.md`
- Adjust replacement suggestions to your brand's preferred phrasing
- Add brand-specific voice fingerprint checks beyond the default 4
- Save the forked version at `~/.claude/skills/anti-slop-<brand>/SKILL.md`

The blocklist is yours. The skill is a discipline, not a fixed dictionary.

---

**End of skill. Paste this entire file into Claude Custom Instructions OR save at `~/.claude/skills/anti-slop/SKILL.md` for Claude Code.**
