# Voice Fingerprint Scan — SDS Anti-Slop Skill Pack v1

The 4-check pre-publish pass. Run on every piece of public-facing copy before it ships. Triggered automatically by the skill in `SKILL.md`, or runnable standalone.

---

## The 4 checks

### Check 1 — Specific?

**Question:** Does this copy use real numbers, real timestamps, real tool names, real dollar amounts, real audience names, real failure modes?

**If a sentence in your draft works for ANY company in your lane without modification, it's too abstract.** Rewrite to make it work ONLY for your specific case.

**Examples of pass:**
- "Cuts onboarding from 3 days to 30 min" ✅
- "$17.40/mo Higgsfield Pro line item" ✅
- "Took 8 minutes longer than I estimated because the Resend domain wasn't verified yet" ✅
- "Christopher Lynch replied within 6 hours of the LinkedIn DM" ✅

**Examples of fail:**
- "Increases efficiency" ❌ (too abstract)
- "Saves money" ❌ (no specific amount)
- "Industry-leading results" ❌ (no specific metric or comparison)
- "Many users find" ❌ (no specific number of users)

### Check 2 — Honest?

**Question:** If the work being described broke, stalled, or failed somewhere along the way, does the draft say so? If a wait-state, unknown, or pending dependency exists, does the draft name it?

**Anti-overclaim is the trust-builder for working-builder audiences.** Hiding failure modes loses trust faster than acknowledging them.

**Examples of pass:**
- "Lost 2 hours today because I forgot to clear the .next cache after deleting a file" ✅
- "If your Lovable build won't deploy and you don't know why, here's the fix that worked for me" ✅
- "I tried Cursor for 30 days, dropped it, came back to Claude Code" ✅
- "Status: shipped, but the Tally intake form still needs the 6-component questions extended — that's a Dailen-Dashboard action pending" ✅

**Examples of fail:**
- "Seamless integration" ❌ (when reality was 4 hours of debugging)
- "Out of the box" ❌ (when setup required 5 manual steps)
- "Works perfectly" ❌ (when there's a known edge case)
- "Just plug it in" ❌ (when the plug requires specific configuration)

### Check 3 — Peer voice?

**Question:** Would you actually say this to a friend at coffee, or does it read as LinkedIn-marketing voice?

**The peer test.** If you wouldn't say it out loud to a peer in casual conversation, why is it in your public writing?

**Examples of pass:**
- "I'm honestly not sure if this is going to land — testing it this week" ✅
- "Foundation Subscription is $19/mo. Whether you should subscribe depends on whether you find this kind of content useful" ✅
- "Most operators give up before they hit context-drift pain. The Stack is for the ones who already did" ✅

**Examples of fail:**
- "We're thrilled to announce our latest innovation" ❌ (corporate-press-release voice)
- "Step into the future of AI" ❌ (LinkedIn-thought-leader voice)
- "Empower your team to achieve more" ❌ (HR-marketing voice)
- "Join the movement" ❌ (cult-marketing voice)

### Check 4 — Banned-phrase clear?

**Question:** Run `banned-words-list.md` over the draft. Any hits?

Six categories to scan:
1. Hype / AI-marketing-speak (supercharge, unlock, transform, 10x, revolutionize)
2. Filler intensifiers (just, really, basically, actually, simply)
3. AI-influencer vocabulary (leverage, level up, game-changer, imagine if you could)
4. Motivational-grindset (hustle, grind, lock in, side hustle)
5. Exit-fetishism (billion-dollar, $100M exit, unicorn)
6. Scarcity-FOMO (get it while the getting's good, the window is closing, limited time)

Any hit = rewrite before publish.

---

## How to run the scan

Four-yeses = ship-ready. Anything else = rewrite.

```
☐ Check 1: Specific? — [pass / fail with note]
☐ Check 2: Honest? — [pass / fail with note]
☐ Check 3: Peer voice? — [pass / fail with note]
☐ Check 4: Banned-phrase clear? — [pass / fail with note]

Status: [ALL PASS — ship] / [N fails — rewrite required]
```

---

## When to skip checks (rare exceptions)

**Direct quote from a third party** — quotes are exempt from the blocklist; preserve the speaker's voice even if it violates Check 4. Cite the quote.

**Technical documentation in a domain that uses banned terms as proper nouns** — e.g., "leverage point" in business strategy is a domain term, not the influencer-verb "leverage." Cross-check context before flagging.

**Established product names** — if a tool or product literally has "Supercharger" in its name, you have to use the product name. Cite it as a product name, not as a hype claim about your own work.

**Direct user request to keep a term** — if the user explicitly says "keep this phrase, it's intentional," respect the override. Note in the scan output that the override was applied.

---

## Why these 4 checks (not 10, not 20)

The 4-check pass is the minimum that catches 90% of common slop without being overengineered.

- More checks = users skip the scan entirely (too tedious)
- Fewer checks = misses the patterns that compound across drafts

Four is the load-bearing number. Banked from the production brand-voice-linter inside Black Sheep 247 LLC.

---

**End of voice fingerprint scan. Used by `SKILL.md` automatically + runnable standalone via the 4-yes checklist above.**
