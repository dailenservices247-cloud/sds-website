# SDS Anti-Slop Skill Pack v1

A Claude skill that strips banned phrases, hype-tone, AI-influencer vocabulary, and filler intensifiers from your writing before you ship.

Built from the production brand-voice linter Dailen Huntley uses inside Black Sheep 247 LLC (parent of Synapse Dynamics Segmented, NeoHood, and the rest of the portfolio mesh).

Authored by Dailen Huntley.

## What you get

| File | What it does |
|---|---|
| `SKILL.md` | The Claude skill itself. Paste into Custom Instructions or invoke as a skill in Claude Code / Claude.ai. |
| `banned-words-list.md` | The canonical blocklist: hype words, filler intensifiers, AI-influencer vocabulary, motivational-grindset phrases, exit-fetishism, scarcity-FOMO framing. Includes replacement guidance. |
| `voice-fingerprint-scan.md` | The 4-check pre-publish pass: Specific / Honest / Peer / Banned-phrase. Run before every ship. |
| `usage-examples.md` | 10 before/after rewrites drawn from real production work — landing pages, LinkedIn posts, sales DMs, video scripts. |
| `INSTALL.md` | Where to paste this in Claude.ai / Claude Code / standalone usage. |
| `LICENSE.md` | MIT licensed. Use the patterns anywhere. Attribution appreciated, not required. |
| `CHANGELOG.md` | v1.0 ship notes. |

## Who this is for

Solo founders, AI builders, and content operators who:

- Write public-facing copy (landing pages, posts, videos, sales)
- Recognize that AI-marketing-speak is the new SEO-spam — and want their work to read like a human shipped it
- Have hit the wall where every draft accidentally drifts into "supercharge your transformative AI workflow" before they catch it
- Want a working linter, not a course about voice

## What it solves

Five problems, named:

1. **Hype drift** — AI tools default to "supercharge," "unlock," "transform," "10x," "revolutionize." Your draft slides into that register without you noticing.
2. **Filler intensifiers** — "just," "really," "basically," "actually," "simply" pile up. Each one weakens the sentence.
3. **AI-influencer vocabulary** — "leverage," "level up," "game-changer," "imagine if you could," "I'm so excited to share." Reads as someone copying influencers, not as your voice.
4. **Motivational-grindset** — "hustle," "grind," "passionate," "side hustle," "lock in." Audience-coding signals you may not actually want to signal.
5. **Exit-fetishism + scarcity-FOMO** — "$100M exit," "build a billion-dollar business," "get it while the getting's good," "the window is closing." Bad signal for serious operators.

## How to use it

Three modes:

### Mode 1 — Standalone Claude.ai / Claude Code skill

1. Open Claude (Claude.ai or Claude Code).
2. Paste the contents of `SKILL.md` into Custom Instructions (Claude.ai) OR save as a skill (Claude Code at `~/.claude/skills/anti-slop/SKILL.md`).
3. Paste your draft into a new conversation. Say "run anti-slop on this." Claude returns the scrubbed version + a flag list of what changed.

### Mode 2 — Pre-publish check on existing copy

Before you ship a landing page / post / DM / script:
1. Paste your draft into Claude with the skill loaded.
2. Run the 4-check voice-fingerprint scan from `voice-fingerprint-scan.md`.
3. Fix anything flagged. Ship.

### Mode 3 — Fork and adapt

The blocklist is yours. Fork `banned-words-list.md` to your brand. Add your own banned phrases. Add replacements. The skill reads whatever list you give it.

## Forking guidance

The default blocklist is opinionated. It reflects the SDS / Black Sheep 247 voice (Hormozi specificity + Nate B Jones measured tempo + anti-hype anti-influencer-bro posture).

Your brand voice may differ. Fork:
- Remove blocked phrases your brand WANTS
- Add new phrases that don't belong in your brand
- Adjust replacement suggestions to your brand's preferred phrasing

The skill's value isn't the specific list. It's the discipline of having a list at all + running every draft through it before shipping.

## License

MIT. Use the patterns anywhere. Attribution appreciated, not required. See `LICENSE.md`.

## Authored by

Dailen Huntley — founder, Black Sheep 247 LLC. Operating brand: Synapse Dynamics Segmented (`synapsedynamics.io`). Stack v1 ($149) is the sibling productized library this skill pack belongs to.
