# Relay Protocol

A chronological activity feed across every Claude session you run. The relay is what end-of-day consolidation reads to update atomic nodes, handoffs, and the Active Work Log.

## Where it lives

```
~/.claude/relay.md
```

User-global, NOT vault-local. Every Claude session you run (CLI, persistent Project, voice Co-pilot, dispatched agent) writes to the same file. That single shared feed is what makes cross-Project consolidation possible — without it, each session only knows what it did.

## When to append

At session end, OR when a unit of work completes mid-session (a feature ships, a decision locks, a test concludes).

Append-only. Never overwrite. Never edit prior entries.

## Entry format

```
## [YYYY-MM-DD HH:MM] — [Session Type] — [Project]
- **What:** one-line summary
- **Files changed:** key paths only, not every touched file
- **Decisions:** any new decision nodes written this session
- **Lessons:** anything that broke or surprised you
- **Status:** what's done, what's still pending
---
```

Session types: `CLI`, `Project-Discovery`, `Project-Build`, `Project-Sales`, `Project-Content`, `Project-Personal`, `Code-standalone`, `Code-dispatch`, `Cowork`.

Pick the type that matches the surface you ran the session from. If you're using a custom persistent Project not in this list, use `Project-<name>` and stay consistent.

## Rules

1. **Append, never overwrite.** Each entry goes at the bottom of relay.md.
2. **Write before the session ends.** Don't rely on the next session to log what this one did.
3. **3-5 bullets max.** Details go in `AI Hub/Sessions/YYYY-MM-DD-<topic>.md`.
4. **Relay supplements handoff, doesn't replace it.** The per-project handoff (see `Handoff-Pattern.md`) is the detailed state. Relay is the activity feed.
5. **Still write the session log.** Rich session logs land in `AI Hub/Sessions/`. Relay is the quick summary for the consolidation pass.
6. **Decisions reference filenames, not bodies.** If you wrote `decision-2026-MM-DD-pricing-tier-lock.md`, the relay entry says exactly that — not the decision's content. Consolidation walks the link.

## What the consolidation pass does with the relay

At end of day (or whenever you trigger consolidation), the relay gets read top-to-bottom for the day's entries. The consolidation then:

1. Updates `AI Hub/Active-Work-Log.md` rows for any project that had activity
2. Updates per-project handoff docs for any project mentioned
3. Cross-checks that every "Decisions:" line points to a real atomic node file
4. Archives the day's relay entries to `AI Hub/Sessions/relay-archive-YYYY-MM.md`
5. Empties relay.md (or leaves the last 3 days, your call)

If the relay's empty or you skipped entries, consolidation can't fill the gap — there's no source. Discipline at the write side matters more than discipline at the consolidation side.

## Common failure modes

- **Skipping the write because "nothing important happened."** If nothing important happened, log that. Empty days are themselves a signal.
- **Multiple sessions writing simultaneously.** Markdown append is not atomic across processes. If you regularly run 2+ Claude sessions in parallel, add `set -o noclobber` + `flock` to your write wrapper, or accept the occasional collision and clean up on consolidation.
- **Drift between relay claims and reality.** If you say in relay "decision X locked" but no atomic node exists, consolidation flags it. Discipline check: every "Decisions:" line must point to a file.

## Why this exists

A single Claude session's working memory ends when the session ends. The relay is the bridge between sessions. Without it, every new session starts cold. With it, every new session can read the last 3-5 entries and orient in under a minute.
