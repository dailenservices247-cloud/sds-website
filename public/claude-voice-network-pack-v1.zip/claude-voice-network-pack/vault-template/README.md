# Vault Structure Template

This is the starter vault that ships with the Claude Voice Network Pack. Drop the `AI Hub/` folder into your Obsidian vault root, point Obsidian at it, and you have the same memory substrate the pack methodology assumes.

The point is not "another second-brain template." The point is a memory substrate that survives across sessions and across persistent Claude Projects so the per-Project specialists you build (Discovery, Build, Sales, Content, Personal-Memory) all read from and write to the same ground truth without stepping on each other.

## What's in here

```
AI Hub/
  Active-Work-Log.md          # cross-project canonical state, one row per project
  Decisions/                  # atomic decision nodes (one .md per decision)
  Inferences/                 # atomic inference nodes (claims you derived, not facts)
  Contexts/                   # atomic context nodes (situational state, expires)
  Tests/                      # atomic test nodes (validate-or-kill experiments)
  Sessions/                   # rich per-session logs, dated YYYY-MM-DD-<topic>.md
  Discovery Sessions/         # voice-driven Discovery Co-pilot conversation logs
  Handoffs/                   # archived handoff snapshots (historical)
  Templates/
    atomic-node-template.md   # fill-in skeleton for new atomic nodes

Atomic-Node-Spec.md           # frontmatter schemas for decision/inference/context/test
Relay-Protocol.md             # chronological activity-feed rules
Handoff-Pattern.md            # per-project handoff doc format
```

The four sibling docs at the root (this README + the three protocol files) are reference material. Move or copy them anywhere you want once you've read them. The `AI Hub/` folder is what your agents actually point at day to day.

## Why this structure works

Most personal-knowledge templates optimize for human reading. This one optimizes for agent retrieval under a token budget. Specifically:

**1. One fact per file.** A decision is its own `.md`. An inference is its own `.md`. When a Claude Project asks "what did we decide about pricing on the foundation tier" the agent retrieves one ~400-token node, not a 6,000-token rolling log. Atomic nodes also survive partial corruption: if a single decision gets edited wrong, the rest of the vault doesn't break.

**2. Typed frontmatter, not free-form tags.** Every atomic node has `type: decision | inference | context | test` plus status and date in YAML frontmatter. Agents filter on type before they read body content. See `Atomic-Node-Spec.md` for the per-type schema.

**3. Active-Work-Log as the single canonical state.** One file lists every active, in-flight, blocked, and banked project with status / current stage / next action / blockers / owner session / last updated. This is what sessions read FIRST. Per-project handoffs are detail; the work log is the bird's-eye that prevents two sessions from claiming the same lane.

**4. Relay as the chronological feed.** Sessions append a 3-5 line entry to `relay.md` (not in this folder — it lives at `~/.claude/relay.md` because it's user-global, not vault-local). The relay is what the dream / consolidation cycle reads to update the vault at end-of-day. See `Relay-Protocol.md`.

**5. Discovery Sessions are first-class.** If you're using voice mode via the bundled MCP bridge, voice-driven exploration conversations land in `Discovery Sessions/` (separate from regular `Sessions/` so they're retrievable by intent: "what did I figure out the last time I was thinking out loud about X").

## Install steps

1. **Choose your vault location.** New users: create a folder like `~/Documents/My-Vault/`. Existing Obsidian users: pick an existing vault root OR a subfolder.
2. **Copy `AI Hub/` into that location.** The four root-level reference docs (this README, `Atomic-Node-Spec.md`, `Relay-Protocol.md`, `Handoff-Pattern.md`) can sit alongside `AI Hub/` or move into `AI Hub/Templates/` — your call.
3. **Open the folder in Obsidian.** If you don't have Obsidian, grab it free at obsidian.md. The vault works without Obsidian (it's just markdown files), but Obsidian's graph view + backlinks pay for themselves on day three.
4. **Install the Obsidian Local REST API community plugin.** Settings → Community plugins → browse → search "Local REST API" → install + enable. This is what the bundled MCP bridge connects to. Note the API key it generates; you'll paste it into the bridge config.
5. **Open `AI Hub/Active-Work-Log.md` and add your first project row.** Even if you only have one project right now. The log is the discipline anchor — once the row exists, every session that touches that project updates the row.
6. **Wire your Claude Projects.** Each persistent Project (Discovery, Build, Sales, Content, Personal-Memory) gets the bundled MCP connector pointed at the same vault. See the Project Design Playbook (separate doc in the pack) for per-Project system instructions.
7. **Start writing atomic nodes.** First decision you make this week → `AI Hub/Decisions/decision-YYYY-MM-DD-<slug>.md`. Use the skeleton at `AI Hub/Templates/atomic-node-template.md`. The vault compounds from there.

## What this template is NOT

- Not a methodology lecture. The pack's Project Design Playbook covers the how-to-think part. This template is the substrate the playbook writes into.
- Not opinionated about your Obsidian theme, plugins beyond the REST API, or hotkeys.
- Not a sync solution. Use iCloud / Obsidian Sync / git / Syncthing — whatever you already trust. The bridge connects to the local copy.
- Not coupled to any single Claude model version. Everything here is plain markdown with YAML frontmatter; future Claude models read it the same way.

## When to extend

You'll outgrow the starter structure once you cross ~50 atomic nodes per type or once you start running 4+ persistent Projects in parallel. At that point, add:

- A `PRDs/` folder for spec docs longer than one atomic node
- A `Research/` folder for video extracts, paper notes, and source dossiers
- A per-project `Brand Voice/` folder if you're writing copy at scale
- A `Retrieval Contracts/` folder once you have enough projects to need per-project retrieval rules

These are extensions, not requirements. The starter ships intentionally lean.

## License + reuse

Pack content is licensed for your personal use across your own Projects. The vault structure itself is plain markdown — once it's on your disk, it's yours. Sanitize before sharing.
