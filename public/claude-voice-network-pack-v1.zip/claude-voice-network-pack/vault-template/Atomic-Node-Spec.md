# Atomic Node Spec

Every fact in the vault is its own file. Four types: **decision**, **inference**, **context**, **test**. Each gets typed YAML frontmatter, a single `# H1` matching intent, and a short body. One node = one retrievable unit.

## Why atomic

A single 6,000-word "decisions log" forces an agent to read everything to answer anything. One `.md` per decision forces the agent to retrieve only what's relevant, which keeps the per-turn token budget honest. Atomic nodes also survive bad edits: corrupt one file, the rest of the vault still works.

## Filename convention

```
decision-YYYY-MM-DD-<slug>.md       # locked choices with a rationale
inference-YYYY-MM-DD-<slug>.md      # claims you derived (not directly observed)
context-YYYY-MM-DD-<slug>.md        # situational state, has an expiry
test-YYYY-MM-DD-<slug>.md           # validate-or-kill experiments
```

Slug rules: lowercase, hyphenated, 3-7 words, specific. `decision-2026-MM-DD-pricing-tier-lock.md` not `decision-2026-MM-DD-pricing.md`.

## Frontmatter schemas

### Decision

```yaml
---
type: decision
date: YYYY-MM-DD
lane: <product | infrastructure | content | sales | personal | research>
status: <PROPOSED | LOCKED | SHIPPED | SUPERSEDED>
supersedes: <filename-without-extension or empty>
related:
  - <related-node-filename>
---
```

Body sections:
- `# Decision — <one-line decision statement>`
- `**Decision:**` 1-2 sentence plain restatement
- `## Why now` — triggering conditions
- `## Scope` — what's in, what's out
- `## Open thread` — unresolved sub-questions (optional)

### Inference

```yaml
---
type: inference
date: YYYY-MM-DD
lane: <same set as decision>
confidence: <low | medium | high>
basis: <observation | pattern | external-source>
expires: <YYYY-MM-DD or "stable">
related:
  - <related-node-filename>
---
```

Body sections:
- `# Inference — <one-line claim>`
- `**Claim:**` 1-2 sentences
- `## Evidence` — bulleted observations supporting the claim
- `## What would falsify this` — explicit kill condition

### Context

```yaml
---
type: context
date: YYYY-MM-DD
lane: <same set>
expires: <YYYY-MM-DD>
related:
  - <related-node-filename>
---
```

Body sections:
- `# Context — <one-line situational summary>`
- `**State:**` what is currently true
- `## Why it matters now` — load-bearing reason this is in the vault
- `## When to remove` — the condition that ends the context's relevance

### Test

```yaml
---
type: test
date: YYYY-MM-DD
lane: <same set>
status: <PROPOSED | RUNNING | PASSED | FAILED | KILLED>
success_signal: <one-line measurable outcome>
kill_ceiling: <one-line abort condition>
deadline: <YYYY-MM-DD>
related:
  - <related-node-filename>
---
```

Body sections:
- `# Test — <hypothesis>`
- `**Hypothesis:**` 1-2 sentences
- `## Method` — bulleted steps
- `## Results` — fill in after the deadline; otherwise empty

## Type rules

- **Decision is a lock.** If you change your mind, write a new decision node and set `supersedes:` on the new one to point at the old one. Do not edit the old node's body.
- **Inference can be revised** when new evidence lands. Bump `date` and append to `## Evidence`. If falsified, change `status:` to... actually, inferences don't have status; rewrite as a new inference node and `supersedes:` the old one.
- **Context expires.** Every context node has an `expires:` date. Sessions ignore expired contexts on retrieval. Sweep expired contexts weekly into an archive or delete.
- **Test has two outcomes.** Either you hit the success signal by the deadline (status: PASSED), or you hit the kill ceiling first (status: KILLED). FAILED means the test ran cleanly and the hypothesis was wrong; KILLED means the test got abandoned mid-run. Both are valid endings.

## Related-links

The `related:` list is for nodes that share lane + topic. Don't dump every adjacent node. 2-4 links max per node. Obsidian's backlinks fill in the rest at the graph level.

## Example filenames (sanitized)

```
decision-2026-MM-DD-pricing-tier-lock.md
inference-2026-MM-DD-warm-list-conversion-rate.md
context-2026-MM-DD-vendor-outage-active.md
test-2026-MM-DD-cold-email-subject-variant-b.md
```

## What atomic nodes are not

- Not journal entries (those go in `Sessions/`)
- Not project plans (those go in `PRDs/` once you add that folder)
- Not raw research (those go in `Research/` once you add that folder)
- Not anything longer than ~600 words; if the body grows past that, split into multiple nodes
