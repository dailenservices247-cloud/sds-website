# Handoff Pattern

Per-project state docs that describe what's in flight, what's blocked, what just shipped, and what the next session should pick up. One handoff per active project.

## Where handoffs live

Two valid locations, depending on your setup:

```
~/.claude/handoffs/<project>.md             # user-global, authoritative
<repo>/_handoff.md                          # git-tracked mirror inside a code repo
```

If both exist, the user-global one wins (it's the canonical source; the repo mirror is for keeping the code commit and the handoff state synced).

For projects without a code repo (research, content, sales pipelines), only the user-global location applies.

## When to write or update

- At end of any session that materially changed project state
- Before context switches between projects (so the next session reads a fresh handoff)
- Whenever a blocker resolves or a new blocker appears

Update in place. Don't append. The handoff is current-state, not history. History lives in `AI Hub/Sessions/` and in the relay archive.

## Handoff format

```markdown
---
project: <project-name>
last_updated: YYYY-MM-DD HH:MM
status: <LIVE | IN FLIGHT | PLANNED | BLOCKED | BANKED | HELD>
owner_session: <which session/Project owns the next move>
---

# Handoff — <project-name>

## Current state
One paragraph. What is true right now. What just shipped or just broke.

## Active work
- Bullet list of in-progress items
- Each item is a concrete unit (a file being edited, a feature being built, a decision pending)
- If a Claude session is mid-build, name the session

## Blockers
- Named unblock condition per blocker (no vague "waiting on X")
- If blocked on user action, name the action and estimated effort

## Next action
The single next move when work resumes. One sentence. If multiple parallel next-moves are possible, pick the highest-leverage one and bank the others under "Banked next-moves".

## Banked next-moves
- Bulleted list of work parked with a trigger
- Each one names the unblock condition

## Key paths
- Repo root, deploy URL, related atomic nodes, related PRDs
- Anything a fresh session needs to orient

## Recent decisions
- Links to atomic decision nodes from the last 2-3 sessions
- Format: `decision-YYYY-MM-DD-<slug>.md` (filename only, Obsidian resolves)

## Open questions for me
Questions for the human, not for the next agent. If empty, omit the section.
```

## Status field values

- **LIVE** — shipped to production, generating value or in validation
- **IN FLIGHT** — active build, not yet shipped
- **PLANNED** — spec locked, build not yet started
- **BLOCKED** — explicit unblock condition named in the handoff; waiting on it
- **BANKED** — parked with a trigger condition for a future sprint
- **HELD** — paused mid-build with explicit reason

Status mirrors the Active Work Log status legend. If a handoff disagrees with the work log, the work log wins; reconcile by updating the handoff.

## What a good handoff is not

- Not a session log. Session logs go in `AI Hub/Sessions/`.
- Not a decision rationale. Rationales go in atomic decision nodes.
- Not a roadmap. Roadmaps go in PRDs.
- Not an exhaustive file diff. Code commits are the source of truth for file changes.

The handoff is the answer to "if I came back to this project tomorrow with zero memory, what's the minimum I'd need to read to start working in 5 minutes." Keep it that lean.

## Multi-Project handoff coordination

If you run multiple persistent Claude Projects (Discovery, Build, Sales, Content, Personal-Memory), each Project's `owner_session` field on the handoff prevents two Projects from racing on the same lane. Discovery owns research handoffs. Build owns code handoffs. Sales owns CRM + outreach handoffs. Content owns publishing handoffs. Personal-Memory owns retrospective + tacit-knowledge handoffs.

When work crosses Project boundaries (a Discovery conversation surfaces a decision that needs Build to ship), the originating Project writes the handoff update, and the receiving Project is named in the next-action line. Example: "Build session picks up — wire pricing tier into Stripe webhook."

## Worked example (sanitized skeleton)

```markdown
---
project: <your-project>
last_updated: 2026-MM-DD 21:30
status: IN FLIGHT
owner_session: Project-Build
---

# Handoff — <your-project>

## Current state
First three feature surfaces shipped to staging. Auth + dashboard + settings.
No production traffic yet. Vendor integration partial.

## Active work
- Webhook endpoint for vendor callbacks (Build session, mid-implementation)
- Pricing tier copy locked yesterday, awaiting paste into landing page

## Blockers
- Vendor sandbox credentials not received (emailed support 2026-MM-DD; SLA 2 business days)

## Next action
Paste locked pricing copy into landing page hero + CTA block.

## Banked next-moves
- Stripe webhook signature validation (unblocks when vendor creds land)
- Analytics events on dashboard load (unblocks when traffic exists)

## Key paths
- Repo: ~/Desktop/<your-project>
- Staging: <your-project>-staging.vercel.app
- Active decision nodes: decision-2026-MM-DD-pricing-tier-lock.md

## Recent decisions
- decision-2026-MM-DD-pricing-tier-lock.md
- decision-2026-MM-DD-vendor-vs-build-choice.md
```

The handoff above is ~150 words. That's the right size. If yours runs past 400 words, you're putting history or rationale in the wrong document.
