Voice-driven Discovery Co-pilot conversation logs. Filename: `YYYY-MM-DD-<topic>.md`. See ../Atomic-Node-Spec.md.
