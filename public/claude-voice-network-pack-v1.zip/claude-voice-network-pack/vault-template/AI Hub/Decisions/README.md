Atomic decision nodes. Filename: `decision-YYYY-MM-DD-<slug>.md`. See ../Atomic-Node-Spec.md.
