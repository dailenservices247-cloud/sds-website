Atomic inference nodes. Filename: `inference-YYYY-MM-DD-<slug>.md`. See ../Atomic-Node-Spec.md.
