Rich per-session logs. Filename: `YYYY-MM-DD-<topic>.md`. See ../Atomic-Node-Spec.md.
