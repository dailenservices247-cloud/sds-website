---
type: active-work-log
maintainer: <your-name or "Dispatch Master session">
date_initialized: YYYY-MM-DD
last_full_refresh: YYYY-MM-DD
canonical_vault_path: <absolute path to this vault>
---

# Active Work Log

**Single source of truth for all active, in-flight, blocked, and banked work across every parallel Claude session.** Every session reads this first. When priorities shift, update this log with authority. Other sessions adjust on next read.

**Status tier legend:**
- **LIVE** — shipped to production, generating value (or in validation)
- **IN FLIGHT** — active build this sprint, not yet shipped
- **PLANNED** — PRD locked, build not yet started
- **BLOCKED** — explicit unblock condition named; waiting on it
- **BANKED** — parked-with-condition for future sprint
- **HELD** — paused mid-build with explicit reason

---

## ACTIVE NOW — Sprint <YYYY-MM-DD> to <YYYY-MM-DD>

| PROJECT | Status | Current Stage | Next Action | Blockers | Owner Session | Last Updated |
|---|---|---|---|---|---|---|
| <your-project> | IN FLIGHT | <one-line stage> | <single next move> | <named unblock condition or "none"> | <session name> | YYYY-MM-DD |
| <your-project-2> | PLANNED | <stage> | <next move> | <blocker> | <session name> | YYYY-MM-DD |
| <your-project-3> | BLOCKED | <stage> | <next move when unblocked> | <named unblock condition> | <session name> | YYYY-MM-DD |

---

## BANKED (next-sprint or condition-gated)

| PROJECT | Status | Trigger to Activate | Owner Session | Last Updated |
|---|---|---|---|---|
| <banked-project> | BANKED | <named trigger condition> | TBD | YYYY-MM-DD |
| <banked-project-2> | BANKED | <named trigger> | TBD | YYYY-MM-DD |

---

## OPEN RESEARCH / ADMIN TASKS

1. <one-line task, named owner>
2. <one-line task, named owner>

---

## ACTIVE OPEN QUESTIONS

1. <question that needs an answer before a project can advance, named owner>

---

## SESSIONS THAT READ THIS LOG

Add yourself when you read + execute against this log so cross-Project coordination can track who's in which lane.

| Date | Session Type | Project Lane | Action Taken | Status After |
|---|---|---|---|---|
| YYYY-MM-DD | <session-type> | <project> | <one-line action> | <resulting status> |

---

**Read this first. Update before exiting.**
