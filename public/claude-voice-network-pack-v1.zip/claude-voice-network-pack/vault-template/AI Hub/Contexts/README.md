Atomic context nodes. Filename: `context-YYYY-MM-DD-<slug>.md`. See ../Atomic-Node-Spec.md.
