Atomic test nodes. Filename: `test-YYYY-MM-DD-<slug>.md`. See ../Atomic-Node-Spec.md.
