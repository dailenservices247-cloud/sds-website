Archived handoff snapshots (historical reference). Live handoffs live at `~/.claude/handoffs/<project>.md`. See ../Atomic-Node-Spec.md.
