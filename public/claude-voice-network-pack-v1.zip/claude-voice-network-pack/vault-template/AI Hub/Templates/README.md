Fill-in skeletons for new atomic nodes and handoffs. See ../Atomic-Node-Spec.md.
