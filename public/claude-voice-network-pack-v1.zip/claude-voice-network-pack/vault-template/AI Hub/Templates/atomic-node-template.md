---
type: <decision | inference | context | test>
date: YYYY-MM-DD
lane: <product | infrastructure | content | sales | personal | research>
status: <PROPOSED | LOCKED | SHIPPED | SUPERSEDED>     # decisions only
confidence: <low | medium | high>                       # inferences only
basis: <observation | pattern | external-source>        # inferences only
expires: <YYYY-MM-DD or "stable">                       # context + inference
success_signal: <one-line measurable outcome>           # tests only
kill_ceiling: <one-line abort condition>                # tests only
deadline: <YYYY-MM-DD>                                  # tests only
supersedes: <filename-without-extension or empty>
related:
  - <related-node-filename>
---

# <Decision | Inference | Context | Test> — <one-line summary>

**<Decision | Claim | State | Hypothesis>:** 1-2 sentences restating the node's core in plain language.

## Why now / Evidence / Why it matters now / Method

<For decisions: triggering conditions. For inferences: bulleted supporting observations. For context: load-bearing reason this is in the vault. For tests: bulleted method steps.>

## Scope / What would falsify this / When to remove / Results

<For decisions: what's in and what's out. For inferences: explicit kill condition. For context: the condition that ends relevance. For tests: filled in after deadline; otherwise empty.>

## Open thread

<Optional. Unresolved sub-questions. Omit if none.>
