# License

Copyright (c) 2026 Black Sheep 247 LLC / Synapse Dynamics Segmented

This pack is licensed for personal and internal commercial use by the purchaser. Resale, sublicense, or redistribution of the pack itself or its source files is prohibited. Code excerpts (wrapper script, launchd plist templates, smoke-test script) may be adapted into the purchaser's own workflows without restriction.

Components used by this pack retain their own licenses:

- `mcp-proxy` (Sparfenyuk) — MIT
- `cloudflared` (Cloudflare) — Apache 2.0
- `uv` / `uvx` (Astral) — MIT / Apache 2.0
- `obsidian-mcp-server` (cyanheads) — Apache 2.0
- Obsidian Local REST API plugin (Adam Coddington) — MIT

No warranty. No support obligation beyond the issue tracker linked in your purchase email.
