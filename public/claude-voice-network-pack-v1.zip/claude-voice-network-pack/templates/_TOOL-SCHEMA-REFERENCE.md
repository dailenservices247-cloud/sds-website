# Obsidian MCP Tool Schema Reference (shared across all templates)

The cyanheads `obsidian-mcp-server` (v3.2.1+) uses a **structured `target` object** for all read/write operations. This applies to every starter Project in this pack.

## Critical pattern

**ALWAYS:**
```
{
  "target": {"type": "path", "path": "AI Hub/<your-folder>/<filename>.md"},
  "content": "<markdown body>",
  "overwrite": true
}
```

**NEVER:**
```
{
  "filepath": "AI Hub/...",  // ❌ Will fail: "Invalid input: expected object, received undefined"
  "content": "..."
}
```

The legacy `filepath` string is from an older MCP server package and is NOT supported by cyanheads obsidian-mcp-server. Every system-instructions file in this pack should use the structured `target` schema.

## Tool inventory (current cyanheads server, 12 tools)

| Tool | Purpose |
|---|---|
| `obsidian_get_note` | Read a note by path |
| `obsidian_list_notes` | List files in a folder (recursive, depth-controllable) |
| `obsidian_search_notes` | Full-text or BM25 search across vault |
| `obsidian_list_tags` | List all vault tags with usage counts |
| `obsidian_write_note` | Create or overwrite a note (full file or section) |
| `obsidian_append_to_note` | Append content to existing note |
| `obsidian_patch_note` | Surgical edit (heading / block / frontmatter) |
| `obsidian_replace_in_note` | Find + replace in a single note |
| `obsidian_manage_frontmatter` | Get / set / delete frontmatter keys |
| `obsidian_manage_tags` | Add / remove / list tags on a note |
| `obsidian_delete_note` | Delete a note (elicits user confirmation when supported) |
| `obsidian_open_in_ui` | Open a file in Obsidian.app |

## `target` object variants

All tools accept these target shapes:

### By path (most common)
```
"target": {"type": "path", "path": "AI Hub/<folder>/<file>.md"}
```
Path is vault-relative, includes extension.

### Active note (whatever the user has open right now)
```
"target": {"type": "active"}
```

### Periodic note (daily / weekly / monthly / etc)
```
"target": {"type": "periodic", "period": "daily", "date": "2026-05-23"}
```
`date` is optional — omit for current period.

## Common error responses

| Error message | Cause | Fix |
|---|---|---|
| `Invalid input: expected object, received undefined` | Used `filepath` instead of `target` | Use structured target object |
| `Error: fetch failed` | Obsidian app on user's Mac is closed | Tell user to open Obsidian; don't retry until confirmed |
| `file_exists` | Target path already exists + `overwrite: false` | Set `overwrite: true` |
| `MCP error -32602: Input validation error` | Tool args don't match schema | Re-check the tool's input schema via `tools/list` |
| Connector returns nothing / times out | Bridge or tunnel down | Render in chat, ask user to check daemon state |

## Path conventions per starter Project

| Project | Default write paths |
|---|---|
| 01-discovery | `AI Hub/Discovery Sessions/YYYY-MM-DD-<slug>.md` |
| 02-build | `AI Hub/Build Sessions/YYYY-MM-DD-<slug>.md` |
| 03-sales | `AI Hub/Sales Sessions/YYYY-MM-DD-<slug>.md` |
| 04-content | `AI Hub/Content Sessions/YYYY-MM-DD-<slug>.md` |
| 05-personal-memory | `AI Hub/Memory Sessions/YYYY-MM-DD-<slug>.md` (read-side specialist; writes rarely) |

Cross-Project lore + decision atomic nodes go to `AI Hub/Decisions/decision-YYYY-MM-DD-<slug>.md` regardless of which Project triggered.

Task queue dispatches go to `AI Hub/Task Queue/pending/YYYY-MM-DD-HH-MM-<slug>.md` — see the Vault Template's Task Queue README for the canonical task file format.

## Version notes

This reference matches cyanheads obsidian-mcp-server v3.2.1 and later. If the server version on your machine differs and tools fail with unexpected validation errors:

1. Pull the actual tool schema via `tools/list` JSON-RPC call
2. Compare against this reference
3. Update your Project Instructions to match what the server actually expects
4. File an issue at the pack's GitHub repo so the next pack revision can include the schema update
