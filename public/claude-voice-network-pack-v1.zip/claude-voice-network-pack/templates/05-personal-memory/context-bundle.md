# Context Bundle — Personal-Memory Specialist

**Purpose:** Upload to Claude.ai Project Knowledge so the Personal-Memory Specialist knows your vault structure, where things live, and how you name files. Refresh every 4-8 weeks as structure drifts.

**Version:** v1 (date you fill this in).

---

## Who you are

- **Your name:** [fill in]
- **Vault tool:** [Obsidian | Logseq | other]
- **Vault root path (for reference):** [fill in if relevant]
- **Connector status:** [Obsidian Vault MCP connected | not yet | other]

## Vault structure — where things live

List the folders the Personal-Memory Specialist should know about. Examples below; replace with your actual structure.

- `AI Hub/Decisions/` — atomic-node decision files, format `decision-YYYY-MM-DD-<your-topic-slug>.md`
- `AI Hub/Sessions/` — rich session logs by date and topic
- `AI Hub/Discovery Sessions/` — discovery specialist output (if you use it)
- `AI Hub/Build Sessions/` — build specialist output (if you use it)
- `AI Hub/Sales Sessions/` — sales specialist output (if you use it)
- `AI Hub/Content Sessions/` — content specialist output (if you use it)
- `AI Hub/Memory Sessions/` — this specialist's rare write destination
- `AI Hub/Lessons Learned.md` — known pitfalls and gotchas
- `AI Hub/Decisions Log.md` — rolling index of locked decisions
- `AI Hub/Active-Work-Log.md` — current cross-portfolio state
- `AI Hub/PRDs/` — product requirement docs
- `AI Hub/Brand Voice/` — per-channel voice docs

## Naming conventions you use

- **Atomic-node decisions:** `decision-YYYY-MM-DD-<your-topic-slug>.md`
- **Atomic-node inferences:** `inference-YYYY-MM-DD-<your-topic-slug>.md`
- **Session logs:** `YYYY-MM-DD-<your-topic-slug>.md`
- **Daily notes (if you keep them):** `YYYY-MM-DD.md` under `AI Hub/Daily Notes/`
- **Voice docs:** `<your-channel>-voice.md` under `AI Hub/Brand Voice/`

## Topics you commonly query

List the topics you most often want to look up. This isn't load-bearing for search — it's a hint to the specialist about what your memory queries usually look like.

- [topic / area]
- [topic / area]
- [topic / area]

## Names that show up across your vault

Names of people, products, or projects that appear repeatedly. Helps with who-said-what attribution.

- [name + one-line role description]
- [name + one-line role description]

## Banked patterns about your memory

- "[your pattern, e.g., I keep re-asking the same question about X because I never banked the answer]"
- "[your pattern]"

## What's NOT in this bundle (Personal-Memory targets)

- [thing you'd want surfaced through Memory specialist sessions]
- [thing you'd want surfaced through Memory specialist sessions]
