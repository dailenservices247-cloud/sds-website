# Questions Bank — Personal-Memory Specialist

**Purpose:** Conversation spine for Personal-Memory Specialist sessions. Claude pulls from here when a memory query is too vague to search and needs a clarifying question first. Not a script — a starting menu. Add questions as patterns surface across queries.

**Structure:** 4 domains (Query disambiguation / Decision archaeology / Pattern surfacing / Stale-context audit). Add domains as your memory motion matures.

---

## Domain 1 — Query disambiguation

Questions to narrow a vague query before searching.

### Example entry

- "What were you doing when you last thought about this? Driving, at desk, mid-conversation? Even rough context helps narrow the search window."

---

## Domain 2 — Decision archaeology

Questions to surface surrounding context after finding a decision.

### Example entry

- "Do you want just the locked decision, or do you want the context of what else was on the table that day?"

---

## Domain 3 — Pattern surfacing

Add your own questions as patterns surface (e.g. you keep asking the same memory query because the answer never lands the second time).

---

## Domain 4 — Stale-context audit

Add your own questions as you build a habit of auditing banked decisions for staleness on a cadence.
