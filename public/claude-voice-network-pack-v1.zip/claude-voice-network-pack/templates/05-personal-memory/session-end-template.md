# Session-End Template — Personal-Memory Specialist

**Use:** at the end of the rare Personal-Memory Specialist session that warrants a written summary, Claude generates one using this exact format and writes it to the vault via the Obsidian Vault MCP connector (or falls back to chat-render + manual paste).

Output path: `AI Hub/Memory Sessions/YYYY-MM-DD-<your-topic-slug>.md`

Most memory queries are one-shot (question in, citations out) and DON'T need a session summary. Write one only when:
- You explicitly ask for a summary
- The session surfaced a forgotten context worth recording as a "rediscovered" note
- The session surfaced a contradiction worth flagging to main Claude on Desktop
- The session was a stale-context audit producing actionable items

---

## Template (Claude renders this at session-end, only when warranted)

```
---
type: memory-session
date: <YYYY-MM-DD>
domain: <Query | Decision-archaeology | Pattern-surfacing | Stale-audit | Mixed>
length: <approximate minutes>
session_score: <N>/5
banked_items: <count>
flags_for_main_claude: <count>
citations_returned: <count of files surfaced this session>
---

# Memory Session — <short topic phrase>

## What we covered

<2-3 sentence arc of the conversation. Name the query type and what was searched.>

## Things worth banking

<3-7 items. Each gets a short label, the verbatim or paraphrased line, category tag, and one sentence of why-this-matters.>

1. **<short label>** — "<verbatim or paraphrased>" [DECISION CANDIDATE | INFERENCE CANDIDATE | CONTEXT UPDATE | OPEN THREAD | REDISCOVERED]
   <one-sentence why-this-matters>

2. ...

## Patterns / contradictions noticed

<1-2 observations:
 - "Pattern: ..." for recurring memory queries (you keep re-asking the same thing because it never lands)
 - "Possible contradiction: ..." for two banked decisions or claims that don't square
 - "Confirmed prior assumption: ..." for evidence supporting a banked claim
 - "Stale: ..." for a banked decision whose revisit trigger has fired without being addressed>

## Things to flag for main Claude on Desktop

### Atomic-node candidates

- [DECISION] `decision-YYYY-MM-DD-<slug>.md` — <e.g., reconcile contradiction between two banked decisions>
- [INFERENCE] `inference-YYYY-MM-DD-<slug>.md` — <e.g., bank the rediscovered framing as a load-bearing claim>

(If none, write "None this session.")

### Context-bundle updates (for next refresh)

- <vault structure changes, naming convention drift, new folders added>

(If none, write "None this session.")

### Questions-bank additions

- <Domain X>: <new question phrasing>

(If none, write "None this session.")

### Contradictions to reconcile

- <decision A> at <file A> contradicts <decision B> at <file B>. Reconciliation candidate: <one-line proposal>.

(If none, write "None this session.")

### Stale decisions to revisit

- <decision file> — <age> — revisit trigger fired on <date>, not yet addressed.

(If none, write "None this session.")

### Coordination flags

- <anything main Claude should act on: a forgotten context worth re-surfacing in a bundle, a contradiction worth surfacing in a future session>

## Open question to sit with between sessions

<One sentence. Often a "why did past <your name> commit to X when present <your name> would not" — the kind of question only memory archaeology surfaces.>

## Follow-up questions for next session

- <question 1>
- <question 2>
- <question 3>

## End-of-session score

Score: <N>/5
Why: <one sentence on whether the session surfaced something useful or whether the query was too vague to land>
```

---

## Tag legend

| Tag | When to use |
|---|---|
| `[DECISION CANDIDATE]` | A new decision needed to reconcile a surfaced contradiction. |
| `[INFERENCE CANDIDATE]` | A rediscovered framing worth banking as a load-bearing claim. |
| `[CONTEXT UPDATE]` | Vault structure change or banked context that needs refresh. |
| `[OPEN THREAD]` | A query that keeps re-appearing because the answer doesn't stick. |
| `[REDISCOVERED]` | A forgotten context surfaced this session that deserves explicit re-banking. |
