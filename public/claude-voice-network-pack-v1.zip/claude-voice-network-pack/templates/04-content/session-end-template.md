# Session-End Template — Content Specialist

**Use:** at the end of each Content Specialist session, Claude generates a summary using this exact format and writes it to the vault via the Obsidian Vault MCP connector (or falls back to chat-render + manual paste).

Output path: `AI Hub/Content Sessions/YYYY-MM-DD-<your-topic-slug>.md`

---

## Template (Claude renders this at session-end)

```
---
type: content-session
date: <YYYY-MM-DD>
domain: <Outline | Repurpose | Voice-check | Fanout | Mixed>
channels: <list of channels touched this session>
length: <approximate minutes>
session_score: <N>/5
banked_items: <count>
flags_for_main_claude: <count>
drafts_shipped: <count of outlines/posts/scripts drafted>
drafts_blocked: <count of drafts that failed voice check>
---

# Content Session — <short topic phrase>

## What we covered

<2-3 sentence arc of the conversation. Name the channel(s) and the type of work (outline, repurpose, fanout, voice check).>

## Things worth banking

<3-7 items. Each gets a short label, verbatim or paraphrased line, category tag, and one sentence of why-this-matters.>

1. **<short label>** — "<verbatim or paraphrased>" [DECISION CANDIDATE | INFERENCE CANDIDATE | CONTEXT UPDATE | TEST IN FLIGHT | OPEN THREAD | VOICE SAMPLE]
   <one-sentence why-this-matters>

2. ...

## Patterns / contradictions noticed

<1-2 observations:
 - "Pattern: ..." for recurring voice drift, format failure, or audience response patterns
 - "Possible contradiction: ..." for tension between two channel voice docs or with a banked decision
 - "Confirmed prior assumption: ..." for evidence supporting a banked claim about audience
 - "Open thread: ..." for repeated content gap (topic circled but not shipped)>

## Things to flag for main Claude on Desktop

### Atomic-node candidates

- [DECISION] `decision-YYYY-MM-DD-<slug>.md` — <e.g., kill <channel>, switch <channel> format from X to Y, update voice doc>
- [INFERENCE] `inference-YYYY-MM-DD-<slug>.md` — <e.g., <channel> audience drops at <timestamp> because <reason>>

(If none, write "None this session.")

### Context-bundle updates (for next refresh)

- Channel state changes: <active / paused / sunsetting>
- Cadence changes: <if cadence target shifted>
- Canon vocabulary additions or removals: <if a channel's vocabulary list changed>
- Voice doc revisions needed: <which voice doc + what to update>

(If none, write "None this session.")

### Questions-bank additions

- <Domain X>: <new question phrasing>

(If none, write "None this session.")

### Tests in flight

- <test name>: <measurement criteria> by <revisit date>

(If none, write "None this session.")

### Coordination flags

- <anything main Claude should act on: a voice-doc update to land, a script to fanout next, a channel decision to lock>

## Open question to sit with between sessions

<One sentence. Often a "why does this channel keep underperforming despite voice being right" or "what's the source-event cadence that actually sustains this fanout pattern".>

## Follow-up questions for next session

- <question 1>
- <question 2>
- <question 3>

## End-of-session score

Score: <N>/5
Why: <one sentence on whether the session shipped outlines/drafts that passed voice checks, or just talked around content>
```

---

## Tag legend

| Tag | When to use |
|---|---|
| `[DECISION CANDIDATE]` | A content choice that locks future behavior. Triggers atomic-node creation. |
| `[INFERENCE CANDIDATE]` | A claim about audience / channel / format behavior. |
| `[CONTEXT UPDATE]` | Factual state change. Lands in next context-bundle refresh. |
| `[TEST IN FLIGHT]` | A content experiment with explicit measurement criteria + revisit date. |
| `[OPEN THREAD]` | Repeated content gap or unresolved audience tension. Pattern across sessions = signal. |
| `[VOICE SAMPLE]` | A phrase or framing worth banking as voice-corpus material for the channel's voice doc. |
