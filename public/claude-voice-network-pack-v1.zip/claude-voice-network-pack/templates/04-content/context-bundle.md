# Context Bundle — Content Specialist

**Purpose:** Upload to Claude.ai Project Knowledge so the Content Specialist has read-side context about your active channels, their distinct voices, your cadence per channel, and your source-content rhythm. Refresh every 2-4 weeks as state drifts.

**Version:** v1 (date you fill this in).

---

## Who you are + what you publish

- **Your name:** [fill in]
- **Your brand(s):** [list every brand under which you publish content]
- **Channels you actively publish on:** [list]
- **Cadence target per channel:** [e.g., "<channel A>: 2x/week", "<channel B>: 1x/week"]

## Active channels — one block per channel

Repeat this block for each active channel.

### Channel: [name]

- **Platform:** [YouTube long-form | YouTube Shorts | TikTok | X | LinkedIn | Skool | newsletter | other]
- **Voice doc path:** `AI Hub/Brand Voice/<your-channel>-voice.md`
- **Tone register (one phrase):** [e.g., "build-in-public peer-honest" or "tutorial-honest cheap-default" or "lore-measured world-aware"]
- **Audience persona (one sentence):** [fill in]
- **Format defaults:** [target length, opener pattern, close pattern]
- **Canon vocabulary (if any):** [literal terms used in this channel, terms banned in this channel]
- **Current state:** [active | paused | sunsetting | scaffolded but not launched]
- **Last 3 pieces shipped:** [titles or hooks]

### Channel: [name]

[repeat]

### Channel: [name]

[repeat]

## Source content rhythm

What kind of source events you fan out from. Examples: a long-form video, a launch, a Q&A recap, a build-moment summary.

- **Primary source channel:** [the channel you publish original work to first]
- **Typical fanout pattern:** [which channels typically receive a fanout from a source event]

## Banked decisions about content

- **YYYY-MM-DD** — [decision]. Revisit trigger: [named condition].
- **YYYY-MM-DD** — [...]

## Banked patterns about your content

- "[your pattern]"
- "[your pattern]"

## What's NOT in this bundle (Content Specialist targets)

- [thing you'd want surfaced through Content Specialist sessions]
- [thing you'd want surfaced through Content Specialist sessions]
