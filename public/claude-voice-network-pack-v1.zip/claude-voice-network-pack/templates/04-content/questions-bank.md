# Questions Bank — Content Specialist

**Purpose:** Conversation spine for Content Specialist sessions. Claude pulls from here when shaping a new outline, triaging a repurposing call, or running voice checks. Not a script — a starting menu. Add questions as patterns surface across drafts.

**Structure:** 4 domains (Outline shaping / Repurposing / Voice fingerprint / Fanout). Add domains as your content motion matures.

---

## Domain 1 — Outline shaping

Questions to anchor a long-form outline before drafting.

### Example entry

- "What's the one claim this video makes that nobody on <your channel>'s feed has made this month? If you can't name it, the video isn't ready to outline yet."

---

## Domain 2 — Repurposing

Questions to triage a repurposing call before flattening source content into target voice.

### Example entry

- "What's the load-bearing beat in the source content that has to survive translation? If you can't name it, the repurpose will read as filler."

---

## Domain 3 — Voice fingerprint

Add your own questions as voice drift patterns surface across channels.

---

## Domain 4 — Fanout

Add your own questions as fanout failure patterns surface (e.g. one channel's draft consistently feels off because the source event doesn't translate to that audience).
