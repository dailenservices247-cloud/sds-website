# Questions Bank — Sales Specialist

**Purpose:** Conversation spine for Sales Specialist sessions. Claude pulls from here when triaging replies or shaping outbound. Not a script — a starting menu. Add questions as patterns surface across threads.

**Structure:** 4 domains (Cold-DM shaping / Reply triage / Voice fingerprint / Pattern detection). Add domains as your sales motion matures.

---

## Domain 1 — Cold-DM shaping

Questions to anchor a cold DM in something real before drafting.

### Example entry

- "What's the most specific thing in <your prospect>'s recent activity (post, repo, project, quote) you can name in the opener?"

---

## Domain 2 — Reply triage

Questions to classify a reply before drafting the next message.

### Example entry

- "Did the prospect engage with substance, ack politely, or ask a clarifying question? If you can't tell in 5 seconds, default to bank the thread for 7 days."

---

## Domain 3 — Voice fingerprint

Add your own questions as voice drift patterns surface across drafts.

---

## Domain 4 — Pattern detection

Add your own questions as objection / silence / opener patterns surface across 3+ threads.
