# Context Bundle — Sales Specialist

**Purpose:** Upload to Claude.ai Project Knowledge so the Sales Specialist has read-side context about your offer, your ICP, the do-not-send list, and your active outbound channels. Refresh every 2-4 weeks as state drifts.

**Version:** v1 (date you fill this in).

---

## Who you are + what you sell

- **Your name:** [fill in]
- **Your business / operating brand:** [fill in]
- **What you sell (one sentence):** [fill in]
- **Price points:** [list every offer with price]
- **Primary channel(s) for outbound:** [LinkedIn DMs | cold email | X DMs | warm intros | other]

## The offer — what's actually on the table right now

Pull the offer copy you'd send a prospect today. The Sales Specialist anchors to this.

- **Headline offer:** [one sentence]
- **What it is:** [2-3 sentence description]
- **Who it's for:** [ICP in one sentence]
- **Who it's NOT for:** [explicit anti-ICP if you have one]
- **Named proof points:** [customer names, case studies, screenshots, metrics]
- **Price + delivery:** [$N, X-day turnaround or subscription cadence]
- **One-line CTA you'd use in a DM:** [fill in]

## ICP — the locked persona

- **Title / role:** [fill in]
- **Stage of company / build:** [fill in]
- **Pain you address:** [one sentence]
- **Where they hang out online:** [platforms, communities, repos]
- **Signal that they're ready to buy:** [what they post / say / do]
- **Anti-signal (do NOT engage):** [what disqualifies a prospect]

## Do-not-send list

Prospects you've explicitly chosen not to message (declined, bad fit, prior burned bridge, asked to be left alone). Update as the list grows.

- [name] — [reason]
- [name] — [reason]

## Active outbound state

- **Cold DMs sent this week:** [count + channel breakdown]
- **Warm list size:** [count]
- **Replies awaiting triage:** [list with prospect names]
- **Sequences currently running (if any):** [list with current step]

## Banked decisions about sales

- **YYYY-MM-DD** — [decision in one sentence]. Revisit trigger: [named condition].
- **YYYY-MM-DD** — [...]

## Banked patterns about your sales motion

- "[your pattern]"
- "[your pattern]"

## What's NOT in this bundle (Sales Specialist targets)

- [thing you'd want surfaced through Sales Specialist sessions]
- [thing you'd want surfaced through Sales Specialist sessions]
