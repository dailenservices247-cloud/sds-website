# Session-End Template — Sales Specialist

**Use:** at the end of each Sales Specialist session, Claude generates a summary using this exact format and writes it to the vault via the Obsidian Vault MCP connector (or falls back to chat-render + manual paste).

Output path: `AI Hub/Sales Sessions/YYYY-MM-DD-<your-topic-slug>.md`

---

## Template (Claude renders this at session-end)

```
---
type: sales-session
date: <YYYY-MM-DD>
domain: <Cold-DM | Reply-triage | Voice-fingerprint | Pattern-detection | Mixed>
length: <approximate minutes>
session_score: <N>/5
banked_items: <count>
flags_for_main_claude: <count>
drafts_shipped: <count of messages drafted this session>
drafts_blocked: <count of drafts that failed voice or do-not-send check>
---

# Sales Session — <short topic phrase>

## What we covered

<2-3 sentence arc of the conversation. Name the prospects discussed (or "N anonymous cold targets") and the type of work done.>

## Things worth banking

<3-7 items. Each gets a short label, verbatim or paraphrased line, category tag, and one sentence of why-this-matters.>

1. **<short label>** — "<verbatim or paraphrased>" [DECISION CANDIDATE | INFERENCE CANDIDATE | CONTEXT UPDATE | TEST IN FLIGHT | OPEN THREAD]
   <one-sentence why-this-matters>

2. ...

## Patterns / contradictions noticed

<1-2 observations across threads:
 - "Pattern: ..." for objection/silence/opener patterns across 3+ threads
 - "Possible contradiction: ..." for tension with a banked sales decision
 - "Confirmed prior assumption: ..." for evidence supporting a banked ICP claim
 - "Open thread: ..." for unresolved prospect tension>

## Things to flag for main Claude on Desktop

### Atomic-node candidates

- [DECISION] `decision-YYYY-MM-DD-<slug>.md` — <e.g., add <prospect> to do-not-send list, kill <opener template>, switch ICP framing>
- [INFERENCE] `inference-YYYY-MM-DD-<slug>.md` — <e.g., warm-list converts 4x cold because of <reason>>

(If none, write "None this session.")

### Context-bundle updates (for next refresh)

- Do-not-send list additions: <prospects + reasons>
- Active outbound state changes: <counts, sequence steps, etc.>
- Offer copy adjustments: <if the offer copy in the bundle needs to change>

(If none, write "None this session.")

### Questions-bank additions

- <Domain X>: <new question phrasing>

(If none, write "None this session.")

### Tests in flight

- <test name>: <measurement criteria> by <revisit date>

(If none, write "None this session.")

### Coordination flags

- <anything main Claude should act on within hours: a hot reply, a sequence to ship, a thread to bank>

## Open question to sit with between sessions

<One sentence. Often a "why did this prospect go silent at step 2" or "what's the real objection behind <pattern>".>

## Follow-up questions for next session

- <question 1>
- <question 2>
- <question 3>

## End-of-session score

Score: <N>/5
Why: <one sentence on whether the session shipped drafts that passed voice + do-not-send checks, or just talked around outbound>
```

---

## Tag legend

| Tag | When to use |
|---|---|
| `[DECISION CANDIDATE]` | A sales choice that locks future behavior. Triggers atomic-node creation. |
| `[INFERENCE CANDIDATE]` | A claim about how the sales motion / ICP / objection space works. |
| `[CONTEXT UPDATE]` | Factual state change. Lands in next context-bundle refresh. |
| `[TEST IN FLIGHT]` | A sales experiment with explicit measurement criteria + revisit date. |
| `[OPEN THREAD]` | Unresolved prospect tension. Don't force resolution. Pattern across sessions = signal. |
