# Starter Project Templates

Five ready-to-upload Claude.ai Project bundles. Each subdirectory contains four files following the canonical 4-file pattern documented in `playbook/Project-Design-Playbook.md`:

| File | Purpose |
|---|---|
| `system-instructions.md` | The Project's personality + behavioral rules + tool-use policy |
| `context-bundle.md` | Operator-specific facts the Project should know (PII-light, replace placeholders) |
| `questions-bank.md` | Running list of questions already asked + answered |
| `session-end-template.md` | The structure each session's vault writeback uses |

## How to install one

1. Open Claude.ai web → Projects → New Project
2. Name it (e.g. "Discovery Co-pilot")
3. Upload all four files from the chosen template subdirectory to the Project knowledge area
4. Edit `context-bundle.md` directly in Claude.ai to replace placeholders with your specifics
5. Open from your phone, switch to voice mode, start a session

## The five starter Projects

| # | Slug | Specialist role | Best for |
|---|---|---|---|
| 01 | `discovery` | Voice-driven discovery + ideation | Brainstorming on commutes, capturing live thinking, surfacing blind spots |
| 02 | `build` | Build-mode operator | Sprint planning, scope-defending, build-decision capture |
| 03 | `sales` | Outreach + reply triage | Cold-DM drafting, warm-list management, reply pattern recognition |
| 04 | `content` | Long-form + social fanout | Video script outlines, repurposing, voice-fingerprint enforcement |
| 05 | `personal-memory` | Personal-knowledge mirror | "Did I say X already", who-said-what, decision archaeology |

v1.0 ships stub-level files in each directory. **v1.1 (by 2026-05-28) ships fully authored templates** following the same 4-file pattern as the canonical Discovery example in `playbook/`.

## Customizing a template

Templates are starters, not endpoints. Common edits:

- **Voice register** — replace the voice-doctrine snippets in `system-instructions.md` with your own banned-phrase list + tone rules
- **Vault paths** — the templates reference `AI Hub/...` paths matching the `vault-template/` structure. If you use a different layout, edit the paths
- **Domain-specific tools** — Discovery uses `obsidian_search_notes` heavily; Sales might want a hypothetical CRM MCP added. Add tool-use rules in `system-instructions.md`

## Running multiple Projects against the same vault

This is the whole point. All five Projects can share the same Obsidian vault MCP connector. Each Project writes session summaries to its own folder (`AI Hub/Discovery Sessions/`, `AI Hub/Build Sessions/`, etc.). Cross-Project context flows through the shared atomic-node decision graph + the relay feed.

Anti-pattern: don't have two Projects try to be the same specialist. If they overlap, merge them or sharpen the scope of each.
