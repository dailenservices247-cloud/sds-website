# Questions Bank — Build Specialist

**Purpose:** Conversation spine for Build Specialist sessions. Claude pulls from here when a build call is ambiguous and needs more inputs. Not a script — a starting menu. Add questions as patterns surface across sessions.

**Structure:** 4 domains (Scope / Ship-Bank-Drop / Refactor-vs-Rewrite / Cross-build prioritization). Add domains as your build motion matures.

---

## Domain 1 — Scope-defending

Questions to push back on scope creep before code gets written.

### Example entry

- "What's the outcome this feature delivers in one sentence, and what gets cut if you ship in 1 working session vs 3?"

---

## Domain 2 — Ship vs Bank vs Drop

Questions to force the bucket call before more time is spent.

### Example entry

- "If you didn't ship this feature in the next 90 days, what's the actual cost? Lost revenue, lost trust, lost momentum, or just lost optionality?"

---

## Domain 3 — Refactor vs Rewrite

Add your own questions as the pattern surfaces across builds.

---

## Domain 4 — Cross-build prioritization

Add your own questions as the pattern surfaces across builds.
