# Context Bundle — Build Specialist

**Purpose:** Upload to Claude.ai Project Knowledge so the Build Specialist has read-side context about your business, stack, active builds, and banked decisions. Refresh every 2-4 weeks as state drifts.

**Version:** v1 (date you fill this in). Replace with v2 when banked decisions or stack constraints change enough to merit a refresh.

---

## Who you are

- **Your name:** [fill in]
- **Your business / operating brand:** [fill in]
- **Location + timezone:** [fill in]
- **Solo or team:** [fill in — if team, list roles + headcount]
- **What you ship:** [one-sentence description of the product, service, or portfolio]

## Active builds (status as of this bundle)

List every active build with: name, current state (in flight / blocked / shipped this sprint), and the next blocker.

- **[Product / feature name]** — [in flight | blocked | shipped] — [next blocker or next step]
- **[Product / feature name]** — [...]
- **[Product / feature name]** — [...]

## Banked builds (deferred until condition)

List every build you've explicitly deferred with the named trigger to revisit.

- **[Feature name]** — DEFERRED until [named condition]
- **[Feature name]** — DEFERRED until [named condition]

## Stack constraints

What you build on. What you will NOT swap out without explicit reason.

- **Frontend:** [fill in]
- **Backend:** [fill in]
- **DB:** [fill in]
- **Hosting:** [fill in]
- **CI/CD:** [fill in]
- **Anything you've explicitly chosen NOT to use and why:** [fill in]

## Banked decisions worth knowing

Pull the 5-10 most load-bearing build decisions from your vault. Format: date + one-sentence decision + named trigger to revisit.

- **YYYY-MM-DD** — [decision in one sentence]. Revisit trigger: [named condition].
- **YYYY-MM-DD** — [...]

## Banked patterns about how you build

What you've named about your own build behavior. Examples:
- "Default to minimum viable. Speculative features need explicit named justification."
- "Refactor unless the existing code is unreadable AND coverage is thin AND outcome justifies multi-day rebuild."
- "[your pattern]"
- "[your pattern]"

## What's NOT in this bundle (Build Specialist targets)

- [thing you'd want surfaced through Build Specialist sessions]
- [thing you'd want surfaced through Build Specialist sessions]
