# Session-End Template — Build Specialist

**Use:** at the end of each Build Specialist session, Claude generates a summary using this exact format and writes it to the vault via the Obsidian Vault MCP connector (or falls back to chat-render + manual paste).

Output path: `AI Hub/Build Sessions/YYYY-MM-DD-<your-topic-slug>.md`

---

## Template (Claude renders this at session-end)

```
---
type: build-session
date: <YYYY-MM-DD>
domain: <Scope | Ship-Bank-Drop | Refactor-vs-Rewrite | Cross-build prioritization | Mixed>
length: <approximate minutes>
session_score: <N>/5
banked_items: <count>
flags_for_main_claude: <count>
---

# Build Session — <short topic phrase>

## What we covered

<2-3 sentence arc of the conversation>

## Things worth banking

<3-7 items. Each gets a short label, verbatim or paraphrased line, category tag, and one sentence of why-this-matters.>

1. **<short label>** — "<verbatim or paraphrased>" [DECISION CANDIDATE | INFERENCE CANDIDATE | CONTEXT UPDATE | TEST IN FLIGHT | OPEN THREAD]
   <one-sentence why-this-matters>

2. ...

## Patterns / contradictions noticed

<1-2 observations:
 - "Pattern: ..." for recurring framing
 - "Possible contradiction: ..." for tension with a banked decision
 - "Confirmed prior assumption: ..." for evidence supporting a banked claim
 - "Open thread: ..." for unresolved scope tension>

## Things to flag for main Claude on Desktop

### Atomic-node candidates

- [DECISION] `decision-YYYY-MM-DD-<slug>.md` — <one-line description of what locks>
- [INFERENCE] `inference-YYYY-MM-DD-<slug>.md` — <one-line claim to lock>

(If none, write "None this session.")

### Context-bundle updates (for next refresh)

- <fact or status update for next bundle version>

(If none, write "None this session.")

### Questions-bank additions

- <Domain X>: <new question phrasing>

(If none, write "None this session.")

### Tests in flight

- <test name>: <measurement criteria> by <revisit date>

(If none, write "None this session.")

### Coordination flags

- <anything main Claude should act on within hours>

## Open question to sit with between sessions

<One sentence. Ideally one you surfaced but didn't fully answer. Not homework — a thread to let pull on its own.>

## Follow-up questions for next session

- <question 1>
- <question 2>
- <question 3>

## End-of-session score

Score: <N>/5
Why: <one sentence on whether the session locked a real call or just talked around it>
```

---

## Tag legend

| Tag | When to use |
|---|---|
| `[DECISION CANDIDATE]` | A choice that locks future build behavior. Triggers atomic-node creation. |
| `[INFERENCE CANDIDATE]` | A claim about how the build / stack / customer behaves that anchors future decisions. |
| `[CONTEXT UPDATE]` | Factual state change. Lands in next context-bundle refresh. |
| `[TEST IN FLIGHT]` | An experiment with explicit measurement criteria + revisit date. |
| `[OPEN THREAD]` | Unresolved scope tension. Don't force resolution. Pattern across sessions = signal. |
