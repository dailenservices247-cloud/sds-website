# <you> Discovery Co-pilot — Claude.ai Project Setup

**Purpose:** During work / downtime, run an ongoing voice conversation with Claude that asks you questions about your life, business, thoughts, history — and accumulates context Claude (this CLI side) can read across sessions. Built for phone use via Claude.ai mobile app voice mode.

**Built on:** Claude.ai Projects (not Claude Code CLI). Voice mode is mobile-only.

---

## Files in this folder

1. **`PROJECT-SETUP.md`** (this file) — meta + setup steps
2. **`system-instructions.md`** — paste into the Claude.ai Project's Custom Instructions field
3. **`context-bundle.md`** — upload to Project Knowledge (bio + business + voice profile, single file)
4. **`questions-bank.md`** — upload to Project Knowledge (the question structure Claude pulls from)
5. **`session-end-template.md`** — shows the format Claude will use for end-of-session summaries

---

## Setup (one-time, ~10 min)

### Step 1: Create the Project

1. Open Claude.ai on your phone (or web → easier for setup)
2. Click **Projects** in left sidebar
3. Click **+ Create Project**
4. Name: **"<you> Discovery Co-pilot"**
5. Description: "Voice-friendly continuous-discovery project. Asks questions during downtime, accumulates context."

### Step 2: Set Custom Instructions

1. In the new Project, find **"Custom instructions"** field (sometimes labeled "Instructions" or "System prompt")
2. Open `system-instructions.md` in this folder
3. Copy the ENTIRE contents of that file
4. Paste into the Custom Instructions field on Claude.ai
5. Save

### Step 3: Upload Knowledge Files

1. In the Project, click **"+ Add to project knowledge"** (or similar — exact button label varies)
2. Upload these 3 files from this folder:
   - `context-bundle.md`
   - `questions-bank.md`
   - `session-end-template.md`
3. Confirm all 3 show in the Project Knowledge panel

### Step 4: Test it works

1. Start a new conversation in the Project
2. Type: "Voice mode test — pick a question from the questions bank and ask me one."
3. Claude should ask you a single question about your bio / business / voice / etc.
4. If yes: setup complete.
5. If no: the system instructions didn't load — verify in Step 2.

### Step 5: Add to phone home screen (optional)

For fastest voice-mode access:
1. On iPhone: Open Claude.ai in Safari → Share → Add to Home Screen → name it "Claude Discovery"
2. Tap that icon, immediately open the Discovery project, tap the microphone icon → voice mode starts in the project's context

---

## Daily use (voice mode at work)

1. Open Claude Discovery (home screen icon → app)
2. Open the **<you> Discovery Co-pilot** project
3. Tap **microphone** icon (voice mode) → conversation starts within project context
4. Claude asks 1-2 questions; you voice-reply; back and forth
5. When you're ready to wrap (lunch break ending / leaving work / mental shift):
   - Say: **"Wrap up the session. Write the session-end summary using the template."**
   - Claude generates a structured summary in chat
6. Copy that summary text
7. Open phone Obsidian → vault folder `AI Hub/Discovery Sessions/`
8. Create new note named `YYYY-MM-DD-<topic>.md` and paste

Tomorrow's Claude CLI session on the Desktop side will read those notes and incorporate the new context.

---

## Why this is set up this way

- **Voice on phone, structured on desktop.** Voice mode is the only way to talk while at work / driving / walking. Structured note-taking is for after.
- **Knowledge bundle is read-side.** Claude on phone reads what's about you, your business, your voice. So it doesn't ask "who are you?" — it asks substantive questions.
- **Question bank is the conversation spine.** Claude pulls from it, but isn't a script. The bank surfaces topics; the voice flow lets the conversation breathe.
- **Session-end template is the write-side bridge.** Claude generates a structured note in chat; you copy + sync. No magic auto-write needed.
- **One conversation per session.** Each work-session = one Claude conversation. End-of-session summary captures the substance. Next session starts fresh (Project context persists, just not the prior conversation's chatter).

---

## What gets banked into the vault over time

`AI Hub/Discovery Sessions/<date>-<topic>.md` files — one per voice session. Topics will cluster as you go:

- Personal: childhood, family, formative experiences, what you actually want
- Business: <your-business-portfolio>: <your-product-1> / other product theses, customer hypotheses, ICP nuances
- Voice: how you actually talk vs how you write, things you say in conversation that should be in your brand voice
- Future: what's banked vs what's parked vs what's not even imagined yet
- Patterns: what you keep saying / thinking / circling

After ~20 sessions, the patterns are strong enough that I can write a much richer `<your-name>-bio.md` / `voice-profile.md` / `business-overview.md` than the current versions. The bundle in this folder gets updated every ~2 weeks with the new context.

---

## Refresh cadence

- **Weekly:** <you> reviews the prior week's Discovery Sessions notes on Desktop (Sunday-night habit)
- **Bi-weekly:** <you> or a Claude CLI session refreshes `context-bundle.md` with new context, re-uploads to the Project
- **Monthly:** review which questions in the bank have been answered exhaustively + retire them; surface new questions that emerged from sessions

---

## Limits to acknowledge

- Claude.ai voice mode is mobile-only currently
- Project Knowledge files don't auto-update — you'll periodically re-upload the bundle when context grows
- Voice transcription quality varies in noisy environments (warehouse, driving) — the session-end summary is the source of truth, not the raw transcript
- Claude.ai Projects cannot directly access the Desktop vault — the bridge is YOU copying summaries into phone Obsidian
- 200K context window per conversation — voice sessions over ~3 hours may exceed; wrap and start a new conversation if you're going that long
