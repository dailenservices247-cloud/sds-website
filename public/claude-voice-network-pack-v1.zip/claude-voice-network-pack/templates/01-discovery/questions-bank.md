# Questions Bank — <you> Discovery Co-pilot

**Purpose:** Conversation spine for voice-mode Discovery sessions. Claude pulls from here. Not a script — a starting menu. Follow the thread <you> surfaces rather than forcing the next bank question.

**Structure:** 5 domains, ~12-20 questions each. Mix of factual ("when," "who," "how much") and reflective ("what would you tell yourself," "what's actually going on"). Reflective questions are higher-leverage but require more energy from <you>.

---

## Domain 1 — Personal: bio, history, formative things

### Childhood + family

- Where did you grow up before Toledo (if anywhere)? When did Toledo become home?
- What did your parents do for work when you were a kid? Did either of them have an entrepreneurial streak?
- Tell me about Lori (mom) beyond the Ally co-signer fact. What's her work history, what's she into, how often do you talk?
- Any siblings? If yes, how would you describe each one in a sentence?
- Was there a moment as a kid when you first realized you wanted to build something / run your own thing?

### Education + early work

- What did your education path look like? Any formal degrees, certifications, self-taught threads?
- What was your first real job? What did you learn from it that still applies?
- When did you first start charging for technical work? What was the gig?
- The <you>'s Services LLC era — what did that business actually do, who paid you, why did it wind down?
- Was there a specific moment where the electronics-repair work stopped feeling right and AI-architecture started feeling right?

### Identity, beliefs, posture

- How would you describe yourself in 3 sentences to someone who's about to meet you for the first time?
- What's something most people assume about you that's wrong?
- What's a belief you hold that you suspect is uncommon?
- When was the last time you felt genuinely confident? What were you doing?
- When was the last time you felt deeply uncertain? What were you doing?

### Partner + relationships

- Tell me about Alison Nause beyond the Chime transfer line. How'd you two meet? What's the relationship like in the day-to-day?
- Who are the 3-5 people in your life who'd notice if you stopped showing up for a week?
- Do you have any business mentors / sounding boards? If yes, who?
- Is there a friend / peer you'd trust enough to send your real ECDI loan letter for a read?

---

## Domain 2 — Business: what's real, what's hypothesis, what's broken

### Current state

- Walk me through your 9-5 actual work routine on a normal weekday. What time do you start, what do you do first, when do you eat, when does the workday end?
- Of the 12+ products in the portfolio mesh, which 3 do you actually think about every day?
- Which product has the cleanest revenue path in the next 90 days, in your gut (not the spreadsheet)?
- The Peer Operator's Stack just launched at $149. What's your honest gut feel on first-30-day sales — 1, 5, 20, 50? Why that number?

### Customers + ICP

- Who's the ONE specific person you're imagining when you write Stack content? Name, headline, what they're frustrated about. If there's nobody specific, what does that mean?
- Have you actually talked to 3+ people who might buy the Stack in the last 30 days? If yes, what did they say? If no, why not?
- The "Peer Operator" ICP — solo founder, builds with AI, $50-250K/yr. How did you arrive at that exact profile? Is it gut or evidence?
- Christopher Lynch is the LinkedIn DM #1. What would you ACTUALLY want to learn from him if he replied?

### Pricing + offers

- $149 for the Stack — what's the next-higher-bucket offer above that? Is it the $1,500 O1, the $3-5K retainer, both, neither?
- The Calendly→Stripe redirect pattern in Skill 16 brought your no-show rate from 40% to 5%. Was that on YOUR business or somebody else's? If yours, what was the actual flow that hit 40% no-show?
- The $5K/mo Headless Architect Retainer — what's your honest take on whether one buyer at that price exists in your network today?

### Operations + portfolio

- The 12 products in the mesh — list them out loud right now from memory. Which ones you forget probably aren't being thought about enough.
- AWA (Autonomous Web Agency) — is this still alive in your mind, or has it drifted into the parked-for-now folder?
- <your-platform> with the August 2026 EU AI Act deadline — what's your honest read on whether that ship date is real?
- BookStack — what's the actual scope you'd build if you started tomorrow?

### Money + runway

- What's your current personal burn (rent + utilities + food + transport + minimums)?
- What's your business burn (Stripe + Vercel + Supabase + Claude + Skool + tools)?
- If ECDI's loan lands at $20K, what does month 1 / month 3 / month 6 spending actually look like?
- What's the cash floor where you'd take a contract job to refill the runway?

---

## Domain 3 — Voice: how you actually talk vs how you write

### Speech patterns

- Pick a phrase you say in conversation that you've NEVER written down. What is it?
- Pick a phrase you've written that doesn't sound right when said out loud. What is it?
- When you're nervous in a professional setting, what's a verbal tic that slips in?
- When you're explaining something complicated to a friend, how do you simplify it?

### Banked + banned words

- The brand-voice linter bans "supercharge / leverage / unlock / transform / just / really / basically." Which of these slips into your speech when you're not paying attention?
- What's a word YOU find irritating in business writing that's not in the banned list?
- What's a word you love that you don't use enough?

### Audience awareness

- Who do you imagine reading your LinkedIn posts? Like, name and face if possible.
- Who do you imagine listening when you're recording a Loom / voice memo?
- Do you ever notice your voice changes between LinkedIn and Skool? If yes, in what way?
- <your-channel-1> on X — what tone is appropriate for that account that wouldn't work on LinkedIn?

### Honest critique

- If you read your last 5 LinkedIn posts in order — what's the through-line voice signature? Or is it inconsistent?
- Where's your writing currently weakest? (You're going to be honest with me here.)

---

## Domain 4 — Future: what's banked, parked, never-imagined

### Banked but not started

- Of the products in the "Banked future" list — <your-product-1>, <your-platform>, BookStack, AWA, Vet Pack, C1 Course — which one excites you most right now? Which one excites you least?
- If you had to drop ONE banked product permanently to gain 20 hours/week, which would you drop?
- The R1 Headless Architect Retainer — if it lands one client, you're at $3-5K/mo MRR. What's actually stopping you from pitching it today?

### Long-horizon

- 12 months from now, what do you want to be true about <your LLC>?
- 5 years from now, what do you want to be doing professionally?
- 10 years from now, where are you living, who are you with, what's life like?
- What would "I've made it" actually mean for you? Concrete, not abstract.

### Unexplored territory

- Is there a venture you've thought about for years but never named publicly?
- Is there a role you'd take in 18 months that isn't the founder of any current product?
- If you woke up tomorrow with a $200K windfall, what changes in the next 30 days?
- If you woke up tomorrow with $0 in any account, what's the first move?

### Risk + fear

- What's the worst-case scenario for the next 90 days you don't want to say out loud?
- What's a decision you've been putting off?
- What would a really good friend point out about your current setup that you'd resist?

---

## Domain 5 — Patterns: what you keep doing, saying, circling

### Repeating behaviors

- Are there decisions you keep re-making because you didn't bank them the first time?
- What's a workflow you've built and re-built three times now?
- What's a tool you keep buying / subscribing to / dropping?

### Cognitive patterns

- When you're stuck on a problem, what's your default move? (Phone? Walk? Sleep? More research?)
- When you're excited about an idea, what's your time-to-action vs time-to-overthink?
- What's a strength you have that you've never named?
- What's a weakness you have that you've named too many times (and the naming itself isn't progress)?

### Cross-product themes

- If you compare Stack v1 to Atomic Note Pack to O1 Architecture Review — what's the SAME pattern across all three?
- The "thinking-aloud rhythm" voice profile — where did it come from? Was that pure Hormozi-rejection or did it predate that?
- The "anti-overclaim" stance — what triggered it for you?

### Meta-questions

- What's a question you wish I'd asked but I haven't?
- What's a domain (work, life, relationships, money) you'd want me to push harder on?
- Is there context I should have that I clearly don't?

---

## Conversation flow — how to pick a question

At session start, Claude asks: "Where are you and how much time do you have?"

Then picks a domain based on <you>'s energy:

| Energy state | Recommended domain |
|---|---|
| Driving / walking, tired | Personal (biographical, low-stakes) |
| At desk, focused, 30+ min | Business (specific, actionable) |
| Driving / walking, philosophical | Future or Patterns |
| Mid-day break, 10-15 min | Voice (short, fast questions) |
| Late evening, reflective | Personal or Patterns |

Within a domain, prefer questions that:
1. Haven't been asked before in any prior Discovery session
2. Aren't already answered by context-bundle.md
3. Connect to something <you> mentioned in the last 5 minutes of conversation

Avoid asking 3 questions in the same sub-section in a row — vary the depth and topic across the session.

---

## After a session

If <you> consistently dodges a question across 2-3 sessions, note it in the session-end summary. Don't badger. The fact that it's avoided is itself signal — bank it, return to it after a long gap.

If <you> consistently gives short answers to a domain, that domain may not be useful right now. Try a different one next session.

If <you> surfaces a topic NOT in this bank, add it to the bank at the end of the session-end summary so the next session can pull from the updated bank.
