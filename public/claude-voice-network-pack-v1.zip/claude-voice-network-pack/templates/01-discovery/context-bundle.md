# Discovery Co-pilot — Context Bundle (template)

**You fill this in.** This is what Claude knows about you/your business when a Discovery session starts. Refresh every ~2 weeks as your state changes.

The Co-pilot is told to read this bundle first, then engage. Keep it under ~3000 words so it fits the Project knowledge budget cleanly.

---

## Who I am

- **Name:** <your name>
- **Working under:** <your business / LLC name>
- **Role:** <solo founder / operator / agency principal / etc.>
- **Time zone:** <your TZ>
- **Public bio one-liner:** <one sentence the Co-pilot can repeat back if someone asks who you are>

---

## What I'm building (live and in-flight)

List each product / project the Co-pilot might reference. Include status, URL if live, last-updated date. Keep this short — the Co-pilot doesn't need everything, just the load-bearing five.

- **<Product 1>** — <status: live / in-flight / banked>. <one-line description>. <URL if public>.
- **<Product 2>** — <status>. <one-line description>.
- **<Product 3>** — <status>. <one-line description>.
- **<Service offering 1>** — <pricing>. <one-line ICP description>.
- **<Service offering 2>** — <pricing>. <one-line ICP description>.

---

## Public-facing surfaces

The Co-pilot might reference these in conversation. List them in priority order.

- Primary site: `<yourdomain.com>`
- Blog / writing: `<your blog URL>` or "none yet"
- Community: `<Skool / Discord / etc. URL>` or "none yet"
- Newsletter: `<list provider + URL>` or "none yet"
- Social — primary: `<channel + handle>`
- Social — secondary: `<channel + handle>`

---

## ICP (ideal customer profile)

The Co-pilot uses this when you ask "is X the right move" or "is Y aligned with my ICP."

- **Industry / role:** <e.g. "solo AI builders who run their own MCPs">
- **Pain we solve:** <one specific named pain>
- **Maturity signal we look for:** <e.g. "ships at least weekly, runs Claude Code locally">
- **Anti-ICP:** <one specific kind of buyer we DON'T want — name it explicitly>

---

## Voice register (locked across all public output)

The Co-pilot reads your channel-specific voice docs at `AI Hub/Brand Voice/<channel>-voice.md` for fine-grained scoring. This is the global summary.

- **Tone family:** <e.g. "peer-tech, operator-grade, direct without loud">
- **Banned phrases (global blocklist):** <e.g. "supercharge / leverage / unlock / transform / 10x / game-changer / love this / thanks for sharing">
- **Specific verbal tics to avoid:** <anything personal — over-use of "basically," etc.>
- **Em-dash policy:** <e.g. "no body em-dashes, signoff only" OR "freely used">
- **Signoff convention:** <e.g. "— <your name>, <your business>">

---

## Current strategic frame

This is the highest-leverage section. The Co-pilot reads this and aligns its surfacing priorities with the ladder.

- **Highest-priority work right now (top 3):**
  1. <what you're pushing this week>
  2. <what's blocked on what>
  3. <what's banked but coming up>

- **Things explicitly NOT to surface right now (banked):**
  - <work intentionally on hold — name it so the Co-pilot doesn't keep dragging it up>
  - <work being killed — same>

- **Active validation experiments:** <if any are running, name them + the kill criterion>

---

## Decision ladder (where the Co-pilot writes back to)

The Co-pilot writes session output as atomic-node decisions into your vault at `AI Hub/Discovery Sessions/`. It cross-references prior decisions at `AI Hub/Decisions/` before locking new ones.

- **Atomic node format:** see `vault-template/Atomic-Node-Spec.md` from the pack
- **Filename pattern:** `decision-YYYY-MM-DD-<short-slug>.md`
- **Frontmatter fields the Co-pilot writes:** `type`, `date`, `lane`, `status`, `related`

---

## Cadence

Tell the Co-pilot how often you'll talk to it so it tunes the depth of each session.

- **Discovery session frequency:** <e.g. "1-3x per week, evening, voice mode while walking">
- **Average session length:** <e.g. "15-30 min">
- **Vault refresh cadence:** <how often you update this context-bundle — e.g. "every 2 weeks">

---

## Personal context the Co-pilot should know

Optional. Include only what you want the Co-pilot to factor into how it talks to you.

- **Communication style preferences:** <e.g. "blunt-honest > diplomatic, fragments OK, no preamble">
- **Things to never ask twice:** <e.g. "don't ask about market size for a product I've shipped 3 times">
- **Energy / mode shifts:** <e.g. "late-night sessions = looser exploration mode, morning sessions = decision-locking mode">

---

## How to fill this in

Don't try to fill everything in one sitting. Drop in the obvious values now, then add depth over your first 3-5 Discovery sessions as the Co-pilot surfaces what it needs.

After ~20 sessions, you'll know exactly which sections matter most for your workflow and can refactor accordingly.
