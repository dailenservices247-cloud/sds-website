# Session-End Template — <you> Discovery Co-pilot

**Use:** at the end of each voice-mode Discovery session, Claude generates a summary using this exact format and writes it to the vault via the Obsidian Vault MCP connector (or falls back to chat-render + manual paste if connector unavailable).

The summary lands at: `AI Hub/Discovery Sessions/YYYY-MM-DD-<topic-slug>.md`

---

## Template (Claude renders this at session-end)

```
---
type: discovery-session
date: <YYYY-MM-DD>
domain: <Personal | Business | Voice | Future | Patterns | Quick-fire>
length: <approximate minutes>
context: <where <you> was during the session, e.g. "driving home from warehouse" or "lunch break at desk">
session_score: <N>/5
banked_items: <count of items in "Things <you> said worth banking">
flags_for_main_claude: <count of items in "Things to flag for main Claude on Desktop">
---

# Discovery Session — <short topic phrase>

## What we covered

<2-3 sentence summary of the conversation arc>

## Things <you> said worth banking

<List 3-7 items. Each item gets:
 - A short label (2-5 words)
 - The verbatim quote (or paraphrase marked as such)
 - A category tag: [DECISION CANDIDATE] / [INFERENCE CANDIDATE] / [CONTEXT UPDATE] / [TEST IN FLIGHT] / [OPEN THREAD]
 - One sentence of why-this-matters context>

1. **<short label>** — "<verbatim quote or paraphrased line>" [TAG]
   <one-sentence why-this-matters>

2. **<short label>** — "..." [TAG]
   <why>

3. ...

## Patterns / contradictions I noticed

<1-2 observations marked as such:
 - "Pattern: ..." for recurring behavior or framing
 - "Possible contradiction: ..." for tension between what was said and what's known
 - "Confirmed prior assumption: ..." for evidence supporting a banked claim
 - "Open thread: ..." for an unresolved tension that's worth noting>

## Things to flag for main Claude on Desktop

<Explicit action items routed to the main coordination session. This is the LOAD-BEARING handoff section.>

### Atomic-node candidates (propose new files in vault)

- [DECISION] `decision-YYYY-MM-DD-<slug>.md` — <one-line description of the decision to lock>
- [INFERENCE] `inference-YYYY-MM-DD-<slug>.md` — <one-line description of the claim to lock>

(If none, write "None this session.")

### Context-bundle updates (for bi-weekly refresh)

- <fact or status update that should land in context-bundle v3>
- <another fact>

(If none, write "None this session.")

### Questions-bank additions (new question angles to bank)

- <Domain X>: <new question phrasing>
- <Domain Y>: <new question>

(If none, write "None this session.")

### Tests in flight (open experiments with measurement criteria)

- <test name>: <measurement criteria> by <revisit date>

(If none, write "None this session.")

### Coordination flags

- <Anything else main Claude should know: a pivot, a contradiction with a locked decision, a follow-up <you> wants surfaced when he's back at desk, etc.>

## Open question <you> should sit with between sessions

<One sentence question, ideally one <you> ALSO surfaced but didn't fully answer. Not homework — a thread to let pull on its own.>

## Follow-up questions for next session

<2-3 questions for the next session in this domain or a related domain. These get added to the questions bank if they're new angles.>

- <question 1>
- <question 2>
- <question 3>

## End-of-session score

<Claude's read on the session, 1-5 scale, with one sentence of why. NOT a judgment of <you> — a quality check on whether the session got somewhere or surfaced something useful.>

Score: <N>/5
Why: <one sentence>
```

---

## Tag legend (use exactly these in [TAG] field)

| Tag | When to use |
|---|---|
| `[DECISION CANDIDATE]` | <you> named a choice that locks future behavior. Triggers atomic-node creation by main Claude. |
| `[INFERENCE CANDIDATE]` | <you> made a load-bearing claim about how the world works (his world or general). Worth locking as inference atomic-node. |
| `[CONTEXT UPDATE]` | <you> surfaced a factual state change. Lands in next context-bundle refresh. |
| `[TEST IN FLIGHT]` | <you> named something he's measuring with explicit signal. Bank measurement criteria + revisit date. |
| `[OPEN THREAD]` | Unresolved tension <you> circled but didn't resolve. Pattern across sessions = signal. Don't force resolution. |
| `[VOICE SAMPLE]` | A phrase or framing worth banking as voice-corpus material for brand-voice linter training or content reuse. |

---

## Example (rendered at session-end; this template block is reference)

```
---
type: discovery-session
date: 2026-05-20
domain: Business
length: 35 minutes
context: lunch break at desk
session_score: 4/5
banked_items: 5
flags_for_main_claude: 4
---

# Discovery Session — Stack v1 first-buyer prediction + Christopher reply read

## What we covered

Dug into how <you> reads Christopher Lynch's reply (same-day ICP signal vs. politeness). Surfaced <you>'s gut prediction for first-30-day Stack sales. Compared the locked ICP framing to what <you> actually expects.

## Things <you> said worth banking

1. **Christopher reply = real signal, not politeness** — "He showed me what he's building. That's a peer-recognition move, not a courtesy reply." [INFERENCE CANDIDATE]
   Anchors ICP validation; first concrete evidence the locked persona converts.

2. **First 30-day Stack sales gut prediction** — "Honest gut is 3 to 5 sales by day 30. If it's 8+ that's a pleasant surprise. Zero would tell me ICP is still off." [TEST IN FLIGHT]
   Sets measurement criteria + revisit date 2026-06-19. Bank as test.

3. **Anti-Slop Skill Pack timing** — "I want to ship it within 14 days of finishing today's sprint." [DECISION CANDIDATE]
   Triggers atomic-node decision-2026-05-20-anti-slop-pack-14-day-ship.

4. **Christopher's social media network = potential overlap with Synergy thesis** — (paraphrased) <you> noted Christopher's project is in adjacent territory to <your-product-1>/<your-platform> Super App. [OPEN THREAD]
   Worth circling back: is Christopher a potential collaborator on the long-horizon platform vision?

5. **Voice tic spotted** — <you> said "I want to make sure I'm not just" mid-sentence and self-corrected to "I want to make sure I'm framing this concretely." [VOICE SAMPLE]
   The self-correction in real time = brand voice working at the speech level.

## Patterns / contradictions I noticed

Pattern: <you> is more decisive about Anti-Slop timing than O1 tier launch — suggests new-product enthusiasm > existing-product expansion energy. Worth noting for prioritization.

Possible contradiction: Locked Stack v1 ICP is "solo AI builder with context-drift pain" but <you> still defaulted to talking about "people LIKE Christopher" rather than the abstract persona. Implies the proof-point pull is stronger than the locked ICP doc. Consider rewriting ICP doc using Christopher-as-canonical-example phrasing.

## Things to flag for main Claude on Desktop

### Atomic-node candidates

- [DECISION] `decision-2026-05-20-anti-slop-pack-14-day-ship.md` — Anti-Slop Skill Pack ships within 14 days of 2026-05-20 sprint close.
- [INFERENCE] `inference-2026-05-20-icp-by-proof-point.md` — ICP documents pull more weight when anchored to a canonical-example human than to an abstract persona.

### Context-bundle updates

- Add: Christopher Lynch reply = first canonical ICP proof point, treat as recurring example anchor in future Stack copy.
- Add: First-30-day Stack sales gut prediction = 3-5 (banked as test for 2026-06-19 check).

### Questions-bank additions

- Business: "If first 30-day Stack sales come in at 0, what's your read — ICP off, copy off, or distribution off?"
- Patterns: "When you make a gut prediction, how often does it land within 1 standard deviation of actual?"

### Tests in flight

- First-30-day Stack sales prediction: target 3-5 sales by 2026-06-19 (D+30 from launch).

### Coordination flags

- Stack copy rewrite candidate: <you>'s pull toward Christopher-as-example suggests rewriting ICP language to be more concrete-example-led. Worth a follow-up Code session.

## Open question <you> should sit with between sessions

If Christopher is the canonical proof point, what does the SECOND proof point look like — and is it being engaged on Spotter Tier A yet?

## Follow-up questions for next session

- Walk me through your read on the OTHER 3 LinkedIn DMs (Rachel, Jared, Cynthia). Are you expecting silence or just hadn't checked?
- What's the test you're running that you DON'T have an explicit measurement criteria for yet?
- Of the 12 banked decisions from this week, which one are you LEAST sure about?

## End-of-session score

Score: 4/5
Why: real signal-extraction on Christopher reply + first concrete sales prediction banked. Didn't quite close the Anti-Slop scoping question.
```

---

## After the summary lands

If using Obsidian Vault MCP connector to write: confirm to <you> with the vault path written + sync timing.

If falling back to chat-render: tell <you> exactly which folder + filename + ask "Anything to add or fix before you paste?"

The last "anything to add" prompt gives <you> one edit pass before saving. Voice transcription can drift; let him correct in real time.

---

## Edge cases

- **Session under 5 minutes (Quick-fire mode):** Skip the full template. Use compressed summary: 1 banked thing + 1 follow-up question + 1 flag for main Claude. Tiny but real. Mark frontmatter `domain: Quick-fire`.
- **Session that went off-rails (rant / vent / unrelated topic):** Write a hybrid summary. Don't pretend the rant didn't happen. List the banked items from the off-topic thread separately under a header like "## Off-topic banked" and note the original domain went unaddressed.
- **Multiple domains in one session:** Single summary, list both domains in frontmatter, segment "what we covered" by domain.
- **<you> says something sensitive (health, finances, relationship):** Default behavior — summarize with same factual neutrality. If <you> says "don't bank that" anywhere in session, EXCLUDE that thread from the summary entirely. Note in the summary: "1 topic excluded per <you>'s request."
- **Connector write fails:** Render summary in chat with the exact filename + folder path. <you> pastes manually.
- **<you> mentions a NEW topic not in questions-bank:** Pick up the thread. At session end, add the question angle to the "Questions-bank additions" flag section so main Claude can update questions-bank.md.
