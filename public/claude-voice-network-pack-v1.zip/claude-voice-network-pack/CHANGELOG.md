# Changelog

## v1.0.2 — 2026-05-23

- **CRITICAL — Middleware upgraded to OAuth 2.1 gateway** at `bridge/bearer-auth/middleware.py`. Claude.ai Custom Connectors now authenticate automatically via Dynamic Client Registration + authorization_code flow on Connect. No manual token paste needed. Bearer-token fallback preserved for curl / direct-use clients. Access token TTL defaults to 30 days (was 1 hour). Validated end-to-end with claude.ai Custom Connector against dogfood install.
- **CRITICAL — Tool schema fixed for `obsidian_write_note`** across all 5 starter templates and INSTALL docs. The cyanheads `obsidian-mcp-server` v3.2.1+ uses a structured `target` object, NOT a `filepath` string. Old templates would fail with `Invalid input: expected object, received undefined`. New shared reference at `templates/_TOOL-SCHEMA-REFERENCE.md` documents all 12 tool schemas + common errors.
- **Bearer-auth README rewritten** to explain OAuth + bearer dual-mode architecture.
- **INSTALL.md hardening section** updated to reflect automatic OAuth flow.
- **Error-handling docs added** for common failure modes (Obsidian app closed / file exists / connector unavailable).

## v1.0.1 — 2026-05-21 (evening)

- **Bearer-auth middleware shipped** at `bridge/bearer-auth/` — full hardening layer ready out-of-box. Was banked for v1.1 but landed same-day as v1.0.
- All 5 Project templates fully authored (Discovery / Build / Sales / Content / Personal-Memory). Was banked for v1.1.

## v1.0.0 — 2026-05-21

Initial release.

- Bridge: wrapper template + worked Obsidian wrapper + dual launchd plists + 5-layer smoke test + 7-failure-mode troubleshooting library + named-tunnel migration guide
- Playbook: full Project Design methodology
- Vault Template: starter scaffold (8 folders + 4 spec docs + Active Work Log + atomic-node template)
- Templates: stubs for Discovery / Build / Sales / Content / Personal-Memory (full templates land in v1.1)

## Planned v1.1 — by 2026-05-28

- Multi-bridge ingress example (5 servers, 1 named tunnel, 5 subdomains)
- Cloudflare Access policy walkthrough (multi-user / production use case)
- Worked examples for non-Obsidian wrappers (Stripe MCP, Supabase MCP, GitHub MCP)

## Planned v2 — TBD

- Cowork orchestration extension (cross-Project agent coordination)
- Windows port (PowerShell + scheduled tasks instead of launchd)
- Linux port (systemd unit files)
