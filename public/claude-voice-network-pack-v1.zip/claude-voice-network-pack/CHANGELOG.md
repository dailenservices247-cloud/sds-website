# Changelog

## v1.0.0 — 2026-05-21

Initial release.

- Bridge: wrapper template + worked Obsidian wrapper + dual launchd plists + 5-layer smoke test + 7-failure-mode troubleshooting library + named-tunnel migration guide
- Playbook: full Project Design methodology
- Vault Template: starter scaffold (8 folders + 4 spec docs + Active Work Log + atomic-node template)
- Templates: stubs for Discovery / Build / Sales / Content / Personal-Memory (full templates land in v1.1)

## Planned v1.1 — by 2026-05-28

- All 5 Project templates fully authored (system-instructions + context-bundle + questions-bank + session-end-template each)
- Bearer-auth middleware for the bridge
- Multi-bridge ingress example (5 servers, 1 named tunnel, 5 subdomains)

## Planned v2 — TBD

- Cowork orchestration extension (cross-Project agent coordination)
- Windows port (PowerShell + scheduled tasks instead of launchd)
- Linux port (systemd unit files)
