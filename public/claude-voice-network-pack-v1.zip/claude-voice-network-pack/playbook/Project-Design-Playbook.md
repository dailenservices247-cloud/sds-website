# Project Design Playbook

A Claude.ai Project is a long-lived context container with custom instructions and a knowledge bundle. Voice mode reads from that container. This is the operator's spec for designing one that compounds across sessions instead of starting cold every time.

## What this is and what it isn't

A build spec for a single-purpose Project that survives multiple voice sessions and feeds a desktop vault. Canonical example: a Discovery Co-pilot. Voice-mode conversations during downtime that bank structured notes into Obsidian for the desktop side to act on.

Not a guide to general Claude prompting, not a Claude Code CLI playbook, not a Project-as-chatbot pattern. Projects-as-chatbot fails because there's no write-side. The pattern that works: voice in, structured handoff out, vault consumes, next session reads richer context.

Mental model: the Project is the read-side surface, your vault is the write-side surface, the session-end summary is the bridge. Get those three correct and the loop compounds.

## The 4-file pattern (the canonical Project structure)

Exactly four files. More and you're paying for context you won't use. Fewer and you have a gap.

1. **System instructions.** Pasted into Custom Instructions. Defines posture, voice, what to ask, what to bank, what to refuse. Lives in Project config, not Knowledge.
2. **Context bundle.** Uploaded to Project Knowledge. Static read-side payload: identity, what's in flight, voice profile, banned words, banked patterns. Refreshed bi-weekly minimum.
3. **Question bank or task catalog.** Uploaded to Project Knowledge. The conversation spine. Not a script. A starting menu Claude pulls from when the user doesn't direct the session.
4. **Session-end template.** Uploaded to Project Knowledge. Exact format of the structured output: frontmatter, banked-items, action-item flags routed downstream, follow-up questions.

A setup file (`PROJECT-SETUP.md`) is a fifth helper for the human, not for Claude. Documents how to wire the four files together.

## When to spin up a new Project vs extend an existing one

A new Project costs nothing to create but compounds maintenance. Rule of thumb: different posture or meaningfully different bundle, new Project. Same posture, new questions, extend the bank inside the existing Project.

Signals to split:
- Voice register changes (discovery vs. content review)
- Output schema changes (session-end summary vs. weekly synthesis)
- User identity in the bundle changes (personal vs. client)
- MCP tools differ (Obsidian-only vs. Stripe + Slack + Calendar)

Signals to keep one Project:
- Same user, same posture, new question domains
- Same output format, new topic clusters
- Bundle refresh, not rewrite

Default to fewer Projects. One per persona is cleaner than one per topic.

## Designing system instructions (with anti-patterns and examples)

System instructions get pasted into Custom Instructions. Claude reads them every session before any Knowledge file. Budget: 800-2000 words. Past that, you're crowding context before the conversation starts.

Four required sections:

1. **Read order.** Which Knowledge file is primary, which secondary, when to use MCP for live reads. Without this, Claude pulls randomly.
2. **Posture and voice register.** Banned words, encouraged patterns, voice anchors. The blocklist matters more than the encouragement list because LLMs default to filler.
3. **Extraction priorities.** What signals to listen for and how to tag them. In Discovery: Decisions, Inferences, Contexts, Tests, Open Threads. Each tag triggers a specific downstream action.
4. **Output protocol.** When and how to render the session-end summary, which MCP tool writes it, what to do if the connector fails.

Anti-patterns:

- *"You are an expert at X."* Role identity prompting is weaker than behavioral description. Replace with "When the user says Y, you do Z."
- *Three asks per turn.* Voice tolerates one substantive question. Bake the rule in explicitly.
- *Implicit blocklist.* If you don't list banned words, the model uses them. Be literal.
- *No fallback protocol.* Every MCP call can fail. Spec the fallback so Claude doesn't freeze.
- *Forgetting to spec silence.* Without an explicit rule, Claude fills silence with filler narration.

Working pattern: one-screen user summary, read order, posture, tagged extraction protocol, output spec, connector path. Close with a starting prompt so Claude doesn't open cold.

## Building a context bundle (what to load, what NOT to load)

The bundle is the static read-side payload. It answers "who is this user, what are they doing right now, what do they sound like, what's banked." Target: 1500-3000 words. Past 3000, you're burning tokens on stale facts.

What belongs:
- Identity facts that don't change weekly (name, location, role, business structure)
- Current operational state (what's live, in flight, deferred and why)
- Voice profile (banned words, encouraged patterns, voice influences, how the user talks vs. writes)
- Banked patterns the user has named about themselves
- Connected platforms and where context lives (vault paths, MCP connectors, key URLs)
- An explicit "what's NOT in this bundle" section that doubles as a discovery target list

What does NOT belong:
- Yesterday's session transcript. That's a vault read.
- Decisions under deliberation. Wait until locked.
- Volatile metrics that drift weekly. Live MCP read instead.
- Generic business advice. Claude doesn't need a primer on lean startup.
- Anything secret (API keys, financial details, dispute correspondence).

Refresh cadence: bi-weekly floor, weekly ceiling for active builds. Stale signal: Claude asks about something you've already banked. Twice in a session, refresh. Tag versions `v1`, `v2`, `v3` and date them.

## Maintaining a questions bank (the "asked already" list)

Five to seven domains, twelve to twenty questions per domain. Claude treats it as a starting menu and follows the thread the user surfaces.

Three rules:
1. **Specific over abstract.** "Walk me through your 9-5 routine on a normal weekday" beats "How's work going."
2. **One question per entry.** Compound questions confuse voice mode.
3. **Mix factual and reflective.** Factual ("when did you form the LLC") is low-energy. Reflective ("what would a good friend point out about your current setup that you'd resist") gets more out of the user but costs more energy.

Maintenance: every session-end summary surfaces new question angles that came up organically. Append them to the bank. Monthly, retire questions answered exhaustively. The bank grows and prunes.

If the user dodges a question across two or three sessions, that's signal. Bank the dodge in the session-end summary. Don't badger.

## Writing a session-end template (the load-bearing handoff)

The highest-payoff file. The bridge from voice context to vault context. Get it wrong and the loop doesn't compound.

Required sections:

1. **YAML frontmatter.** Type, date, domain, length, context, session score, banked-item count, flag count. Machine-readable by downstream agents.
2. **What we covered.** 2-3 sentence arc. Shape of the conversation, not a transcript.
3. **Banked items.** 3-7 items, each with a short label, verbatim quote where possible, and a category tag.
4. **Patterns and contradictions.** Claude's observations, marked Pattern / Possible contradiction / Confirmed prior assumption / Open thread.
5. **Action items routed downstream.** Load-bearing. Atomic-node candidates, context-bundle updates, questions-bank additions, tests with measurement criteria, coordination flags. Desktop session reads this and acts within hours.
6. **Open question for the user to sit with.** One sentence, ideally one the user surfaced but didn't fully answer.
7. **Follow-up questions for the next session.** 2-3 items, added to the bank if new.
8. **Session score.** 1-5 with one-sentence why.

Tags must be literal and exact. Discovery uses `[DECISION CANDIDATE]`, `[INFERENCE CANDIDATE]`, `[CONTEXT UPDATE]`, `[TEST IN FLIGHT]`, `[OPEN THREAD]`, `[VOICE SAMPLE]`. Each triggers a specific downstream action. Without exact tags, downstream agents guess.

Spec edge cases: quick-fire mode for sub-5-min sessions, off-rails sessions where the user vented, multi-domain sessions, sensitive content the user asks to exclude. Otherwise Claude improvises.

## The session-compounding loop (how vault feeds back in)

Four legs:

1. **Voice session in Project.** Claude reads the bundle and questions bank, asks substantive questions, listens.
2. **Session-end summary written.** Chat-rendered for manual paste, or written via Obsidian MCP connector directly into the vault.
3. **Vault accumulates.** Session notes, atomic-node decisions, inferences, context updates pile up under `AI Hub/Discovery Sessions/` and feed downstream agents.
4. **Bundle refresh.** Bi-weekly, desktop side reads new sessions and rewrites the bundle. New version uploaded.

Compounding lives in leg 4. Without refresh, the Project knows the same things forever. With refresh, every two weeks the Project knows you better. After ten cycles, it's a meaningfully better thinking partner than at v1.

The MCP connector is load-bearing. Without it, the user copy-pastes every summary by hand. That friction kills loops. Wire the connector before you ship.

## Multi-Project orchestration patterns (when 2+ Projects share a vault)

If you run multiple Projects against one vault (Discovery + Content Review + Client Strategy), coordinate:

- **Each Project writes to its own subfolder.** Discovery to `AI Hub/Discovery Sessions/`. Content Review to `AI Hub/Content Reviews/`. No cross-contamination.
- **Shared read paths are fine.** All Projects can read `AI Hub/Decisions/` and `AI Hub/Active-Work-Log.md`. Decision atomic nodes are the shared substrate.
- **Voice registers differ across Projects.** Discovery is curious. Content Review is critical. Keep the system-instructions distinct.
- **A coordination file in the vault names which Project owns which domain.** Without it, two Projects bank redundant context.

Pattern: one Project per posture, all feed the same vault, desktop side coordinates via a master log.

## Voice mode considerations (what changes when input is spoken)

Voice is not text mode with a microphone. The medium shapes the design:

- **One question per turn.** Spoken input is single-threaded. Three stacked questions guarantee only one gets answered.
- **30-second Claude turn ceiling.** Past that, the user disengages. Long answers break across exchanges.
- **No markdown in spoken output.** Asterisks and brackets read aloud awkwardly. Write speech-first.
- **Silence is fine.** Don't fill it. User thinking is the work.
- **Echo and extend.** Reflect what you heard in one sentence, then ask the follow-up. Builds rapport, confirms transcription.
- **Transcription drift in noisy environments.** Accept it. The summary is the source of truth, not the raw transcript.
- **Wrap triggers vary.** "Wrap up," "let's wrap," "I'm heading out," "write the summary." Bake all of them into instructions.

200K window per conversation is a soft ceiling. Most sessions stay under 30 minutes. Past 2-3 hours, end and start a new conversation in the same Project. Project knowledge persists; in-conversation chatter does not.

## Common pitfalls (with fixes)

1. **No write-side.** The Project gathers context but never banks it. *Fix:* wire the session-end template and MCP connector before launch. Bake the wrap protocol into instructions.

2. **Context bundle too long.** 5000+ words crowds working context. *Fix:* target 1500-3000 words. Move detail to vault notes Claude reads on-demand via MCP.

3. **Questions bank treated as a script.** Claude reads top-to-bottom and the conversation feels mechanical. *Fix:* tell Claude the bank is a menu, not a script. Follow the user's thread.

4. **No literal blocklist.** Instructions say "don't be salesy" but the model still writes "supercharge your workflow." *Fix:* list banned words verbatim.

5. **No fallback when MCP fails.** Connector errors and Claude freezes. *Fix:* spec the fallback. Render in chat with exact filename and folder path.

6. **Bundle never refreshes.** Project knows you at v1 forever. *Fix:* calendar a bi-weekly refresh. Read new session notes, update the bundle, re-upload.

7. **Output schema drifts.** Each summary is shaped slightly differently. Downstream agents can't parse it. *Fix:* the template is a contract. If Claude deviates, tighten the "use this exact format" clause.

## Worked example: Discovery Co-pilot (the canonical case)

A voice-mode Project used during work breaks, driving, and walking. The four files:

- **System instructions.** Curious-not-interrogative posture, 12+ banned words listed verbatim, 5-tag extraction protocol (Decision / Inference / Context / Test / Open Thread), Obsidian MCP connector named as the write target.
- **Context bundle v2.** 2200 words: identity, operational state, voice profile with literal banned-word list, banked patterns, connected platforms.
- **Questions bank.** 5 domains (Personal / Business / Voice / Future / Patterns), ~80 questions total, with a "pick based on energy state" table.
- **Session-end template.** YAML frontmatter, 7-section structure, 6 literal category tags, edge-case handling for quick-fire and off-rails sessions.

The loop runs daily. Each session writes to `AI Hub/Discovery Sessions/YYYY-MM-DD-topic.md`. Desktop side reads new sessions weekly, creates atomic-node decisions for `[DECISION CANDIDATE]` flags, refreshes the bundle bi-weekly. After 20 sessions, the bundle is meaningfully richer than v1 and the questions bank has been pruned and extended with angles the user surfaced organically.

## What to do next (build your first Project)

1. **Pick one posture.** Don't try to build Discovery, Content Review, and Strategy at once. Pick the one that compounds fastest. Discovery is usually it.
2. **Write the context bundle first.** Forces you to answer "what does Claude need to know about me to be useful." 1500-3000 words. Voice profile mandatory.
3. **Spec the session-end template before the instructions.** The template is the contract. Instructions are enforcement. Reverse the order and instructions drift.
4. **Build the questions bank from your real questions.** Don't generate it cold from Claude. Write 20-40 questions you've actually wondered about. Cluster into domains. Extend from there.
5. **Wire the MCP connector before launch.** If you can't write to your vault, the loop doesn't close. Test before your first real session.
6. **Run 5 sessions before judging the Project.** First session feels rough. By session 5 the patterns clarify.
7. **Refresh the bundle at week 2.** The load-bearing habit. Without it, the loop stalls.

The Project is not the value. The compounding vault is the value. The Project is just the surface that lets you talk to it without typing.
