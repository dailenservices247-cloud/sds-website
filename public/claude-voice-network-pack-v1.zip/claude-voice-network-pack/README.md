# Claude Voice Network Pack

**Build a team of persistent AI specialists that travel with you. Each one knows you. Each one writes back to your vault. All accessible via voice from your phone.**

This pack ships the full stack: the bridge that exposes any local stdio MCP server to Claude.ai mobile, the methodology for designing Projects that compound across sessions, the vault structure that makes session compounding possible, and ready-to-upload Project templates for five common operator roles.

---

## What's in this pack

```
claude-voice-network-pack/
├── bridge/                        — expose local MCPs to your phone
│   ├── INSTALL.md                  5-step Mac install (~20 min)
│   ├── wrapper-template.sh         generic wrapper for any stdio MCP
│   ├── mcp-obsidian-wrapper.example.sh   worked Obsidian example
│   ├── plists/                     two launchd plists (proxy + tunnel)
│   ├── smoke-test.sh               5-layer health check (auto-detects URL)
│   ├── troubleshooting.md          7 silent-failure modes + fixes
│   └── named-tunnel-setup.md       permanent URL via your own subdomain
│
├── playbook/                      — methodology
│   └── Project-Design-Playbook.md  how to scope persistent Claude.ai Projects
│
├── vault-template/                — drop into your Obsidian vault root
│   ├── README.md                   why this structure works
│   ├── Atomic-Node-Spec.md         decision/inference/context/test nodes
│   ├── Relay-Protocol.md           session activity feed rules
│   ├── Handoff-Pattern.md          per-project handoff doc format
│   └── AI Hub/                     starter folders + canonical files
│
└── templates/                     — 5 ready-to-upload Project bundles
    ├── 01-discovery/               voice-driven discovery + ideation
    ├── 02-build/                   build-mode operator
    ├── 03-sales/                   outreach + reply triage
    ├── 04-content/                 long-form + social fanout
    └── 05-personal-memory/         personal-knowledge mirror
```

(Templates ship in v1.1 — install path is identical: upload all 4 files in the folder into a new Claude.ai Project.)

---

## Why this exists

Anthropic shipped MCP Tunnels for Managed Agents enterprise customers in May 2026. It's the right idea but it doesn't reach consumer claude.ai, doesn't ship Project methodology, doesn't structure your vault, and doesn't define the session-end discipline that makes context compound.

The bundle is the missing layer between "I have local MCPs running" and "I run a network of specialized AI assistants that know me and follow me everywhere."

---

## The 60-second tour

1. **Install the bridge** (`bridge/INSTALL.md`). Twenty minutes. End state: your local Obsidian vault is reachable from claude.ai mobile via voice mode.
2. **Drop the vault template** (`vault-template/`) into your Obsidian vault root. Five new folders, three policy docs.
3. **Open Claude.ai → create a new Project** named after a domain (e.g. "Discovery Co-pilot"). Upload the four files from one of the `templates/*` directories.
4. **Use it via voice from your phone.** Each session, the Project writes a structured summary back to your vault as an atomic node. Next session, that summary is already in the context bundle.
5. **Repeat for as many Projects as you need.** Discovery, Build, Sales, Content, Personal-Memory. They share the same vault but stay focused on their own domain.

---

## Hard prerequisites

- **macOS** (Monterey or later). launchd is Mac-specific. Linux/Windows port not in v1.
- **Obsidian** with the **Local REST API** community plugin. The worked example assumes Obsidian — any other stdio MCP works with a different wrapper but Obsidian is where the methodology shines.
- **uv / uvx** — `curl -LsSf https://astral.sh/uv/install.sh | sh`
- **cloudflared** — [Cloudflare binary download](https://developers.cloudflare.com/cloudflared/install/)
- **Claude.ai account** (free tier works for Projects + Custom Connectors)

---

## What you do NOT need

- A paid Cloudflare plan. Quick tunnels are free. Named tunnels are free on the free tier (DNS only).
- A paid Anthropic API plan. Custom Connectors work on Claude.ai free tier.
- A server. Everything runs on your Mac.
- Docker. None used.
- Homebrew. None required.

---

## Operating cost

| Component | Monthly cost |
|---|---|
| Bridge (local-only) | $0 |
| Cloudflare tunnel | $0 (free tier) |
| Claude.ai | whatever you already pay |
| Obsidian | whatever you already pay (free tier supported) |

The pack adds zero recurring cost.

---

## Support + updates

This pack is a one-time purchase. Updates ship as new versions; you'll get a download link in your purchase email. Open a GitHub issue at the included repo URL for bugs or improvements.

Voice register, vault structure, and atomic-node format follow the SDS doctrine (Synapse Dynamics Segmented operator methodology). The pack is a productized slice of that doctrine.

---

## Critical timing note

Anthropic announced "MCP Tunnels" for Managed Agents on 2026-05-19. That feature will likely extend to consumer claude.ai in 6-12 months and obsolete the local-tunneling portion of this pack. The methodology + vault structure + Project design remain valuable regardless. If you want the bridge piece, install it now. If Anthropic's hosted version ships and you migrate, the bridge sunsets cleanly — just point your Claude.ai connector at the hosted endpoint instead of your tunnel URL.

The methodology is the durable asset.
