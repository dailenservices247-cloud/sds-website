#!/bin/bash
# Generic wrapper template for the Claude Voice Network Pack bridge.
#
# Purpose: launch a stdio-based MCP server with secrets loaded from macOS
# Keychain instead of hardcoded values. mcp-proxy spawns this script;
# this script then exec's the actual MCP server binary with the right env.
#
# Per stdio MCP server you want to expose:
#   1. Copy this file to ~/.local/bin/mcp-<servername>-wrapper
#   2. Fill in <PLACEHOLDERS> below
#   3. Add the matching Keychain entry:
#        security add-generic-password \
#          -a "$USER" \
#          -s "<SERVICE_NAME>" \
#          -w "<actual-secret-value>"
#   4. Make executable: chmod +x ~/.local/bin/mcp-<servername>-wrapper
#   5. Reference this script in the mcp-proxy launchd plist (see plists/).
#
# Why a wrapper? launchd-spawned children can't read your shell rc files.
# They start with a near-empty environment. This wrapper bridges the gap:
# Keychain lookup -> env vars -> exec'd MCP server inherits them.

# ---------------------------------------------------------------------------
# REQUIRED EDITS — fill these in per server
# ---------------------------------------------------------------------------

# Keychain service name (the -s value used in `security add-generic-password`).
# Example: "obsidian-rest-api-key", "github-pat-readonly", "stripe-restricted-key"
KEYCHAIN_SERVICE="<SERVICE_NAME>"

# Name of the env var the MCP server expects to find the secret in.
# Check the MCP server's README — common names: API_KEY, GITHUB_TOKEN, etc.
SECRET_ENV_VAR="<SECRET_ENV_VAR_NAME>"

# Absolute path to the MCP server binary to launch.
# Example: /Users/you/.npm-cache/.../obsidian-mcp-server/dist/index.js
# Use ABSOLUTE PATHS — launchd ignores PATH.
MCP_SERVER_BINARY="<ABSOLUTE_PATH_TO_MCP_SERVER>"

# ---------------------------------------------------------------------------
# OPTIONAL EDITS — adjust per server
# ---------------------------------------------------------------------------

# Extra env vars the MCP server wants. Add as many as needed.
# Example for Obsidian Local REST API plugin:
#   export OBSIDIAN_BASE_URL="https://127.0.0.1:27124"
#   export OBSIDIAN_VERIFY_SSL=false
#   export NODE_TLS_REJECT_UNAUTHORIZED=0
# Uncomment + edit as needed:
# export EXTRA_VAR_1="<value>"
# export EXTRA_VAR_2="<value>"

# ---------------------------------------------------------------------------
# DO NOT EDIT BELOW THIS LINE
# ---------------------------------------------------------------------------

SECRET_VALUE=$(security find-generic-password -a "$USER" -s "$KEYCHAIN_SERVICE" -w 2>/dev/null)

if [ -z "$SECRET_VALUE" ]; then
  echo "mcp-wrapper: failed to load '$KEYCHAIN_SERVICE' from Keychain for user '$USER'" >&2
  echo "Fix: security add-generic-password -a \"\$USER\" -s \"$KEYCHAIN_SERVICE\" -w \"<your-secret>\"" >&2
  exit 1
fi

export $SECRET_ENV_VAR="$SECRET_VALUE"

# Exec the MCP server. Replace the wrapper process so mcp-proxy talks
# directly to the server's stdio.
exec "$MCP_SERVER_BINARY" "$@"
