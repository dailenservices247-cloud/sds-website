# Named tunnel setup — permanent URL via your domain

Replace the rotating `trycloudflare.com` URL with a permanent one like `mcp.yourdomain.com` (or `vault.yourdomain.com`, etc.). One-time setup. Survives reboots, never rotates.

**Prerequisites:**
- A domain you own
- DNS managed via Cloudflare (free tier is fine — just transfer DNS nameservers to Cloudflare if not already)
- Working bridge per `INSTALL.md`

**Time:** ~10-15 min including the browser OAuth step.

---

## Step 1 — Cloudflare account login

```bash
~/.local/bin/cloudflared tunnel login
```

This opens a browser. Pick the **zone** for your domain (e.g. `yourdomain.com`). Click Authorize. Cloudflare writes a cert to `~/.cloudflared/cert.pem`. You will not need to do this again on this machine.

---

## Step 2 — create a named tunnel

```bash
~/.local/bin/cloudflared tunnel create mcp-bridge
```

Output:

```
Tunnel credentials written to /Users/<you>/.cloudflared/<uuid>.json
Created tunnel mcp-bridge with id <UUID>
```

Note the UUID. You won't need it directly but the credentials JSON is at `~/.cloudflared/<UUID>.json`.

---

## Step 3 — route DNS

Pick a subdomain. Suggestions:

| Use case | Subdomain |
|---|---|
| One vault | `mcp.yourdomain.com` |
| Multiple servers | `vault.yourdomain.com`, `stripe.yourdomain.com`, `gh.yourdomain.com` |
| Hidden behind a wildcard | `mcp-2026-05.yourdomain.com` (rotate manually for opsec) |

Run:

```bash
~/.local/bin/cloudflared tunnel route dns mcp-bridge mcp.yourdomain.com
```

Cloudflare adds a `CNAME` record automatically. Verify in Cloudflare dashboard → DNS.

---

## Step 4 — config file

Create `~/.cloudflared/config.yml`:

```yaml
tunnel: mcp-bridge
credentials-file: /Users/<you>/.cloudflared/<UUID>.json

ingress:
  # Match the path scheme mcp-proxy uses
  - hostname: mcp.yourdomain.com
    service: http://127.0.0.1:8765
  # Default — required
  - service: http_status:404
```

(Replace `<you>` and `<UUID>` with actual values.)

If you run multiple bridges on different ports (e.g. Stripe on 8766), add more ingress rules:

```yaml
ingress:
  - hostname: vault.yourdomain.com
    service: http://127.0.0.1:8765
  - hostname: stripe.yourdomain.com
    service: http://127.0.0.1:8766
  - hostname: gh.yourdomain.com
    service: http://127.0.0.1:8767
  - service: http_status:404
```

---

## Step 5 — update the cloudflared launchd plist

Edit `~/Library/LaunchAgents/com.<your>.cloudflared-mcp.plist`. Replace the `ProgramArguments` array:

```xml
<key>ProgramArguments</key>
<array>
    <string>/Users/YOURUSER/.local/bin/cloudflared</string>
    <string>tunnel</string>
    <string>--no-autoupdate</string>
    <string>--config</string>
    <string>/Users/YOURUSER/.cloudflared/config.yml</string>
    <string>run</string>
    <string>mcp-bridge</string>
</array>
```

This switches from quick-tunnel mode to named-tunnel mode.

---

## Step 6 — reboot the agent + test

```bash
launchctl bootout gui/$(id -u)/com.<your>.cloudflared-mcp
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.<your>.cloudflared-mcp.plist
sleep 5

# Test
curl -sS -X POST \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","method":"initialize","id":1,"params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"named","version":"0.1"}}}' \
  https://mcp.yourdomain.com/mcp
```

Should return MCP `initialize` response with your server info.

---

## Step 7 — update claude.ai

claude.ai → Settings → Connectors → your connector → edit URL → `https://mcp.yourdomain.com/mcp` → save.

Done. Permanent URL. Never rotates. Survives all the conditions that broke the quick tunnel.

---

## Adding bearer-token auth (next step)

A named subdomain alone has the same authentication gap as a quick tunnel — anyone with the URL can read/write. For production use, add bearer-token auth:

1. Generate a token: `openssl rand -hex 32`
2. Store in Keychain: `security add-generic-password -a "$USER" -s "mcp-bearer-token" -w "<token>"`
3. Run the included `bridge/bearer-auth/middleware.py` between cloudflared and mcp-proxy (it validates the `Authorization: Bearer ...` header before forwarding)
4. Configure claude.ai connector with the bearer token (Auth dropdown → "API Key / Bearer")

See `bridge/bearer-auth/README.md` (ships in this pack) for the full middleware setup.

---

## Multi-bridge tip

One tunnel can carry many bridges. Don't run multiple cloudflared processes — that wastes ingress connections. Instead use the multi-hostname ingress config in Step 4 and route different domains to different ports.

For 5 MCP servers you only need:
- 5 wrapper scripts
- 5 mcp-proxy launchd agents (different ports)
- 1 cloudflared launchd agent with 5 ingress rules
- 5 DNS CNAME records pointing at the same tunnel
- 5 claude.ai connectors, each pointing at one subdomain

This is the right architecture for the Voice Network Pack — one of everything per-bridge, one tunnel for the whole network.
