#!/bin/bash
# Smoke test for the Claude Voice Network Pack bridge.
# Verifies all 4 layers + does a full MCP handshake through the tunnel.
#
# Usage:
#   ./smoke-test.sh                 # auto-detect tunnel URL from cloudflared log
#   ./smoke-test.sh <tunnel-url>    # explicit URL (with or without /mcp suffix)

set -u

URL_ARG="${1:-}"

echo "================================================================"
echo "  Claude Voice Network Pack — Bridge Smoke Test"
echo "================================================================"
echo

# ----------------------------------------------------------------------
# Layer 1 — local daemons
# ----------------------------------------------------------------------
echo "[1/5] launchd daemons running?"
launchctl list 2>/dev/null | grep -E "mcp-proxy|cloudflared-mcp" || {
  echo "  FAIL: no mcp-proxy or cloudflared-mcp agents under launchctl"
  echo "  Fix: launchctl bootstrap gui/\$(id -u) ~/Library/LaunchAgents/com.<your>.mcp-proxy.plist"
  exit 1
}
echo "  OK"
echo

# ----------------------------------------------------------------------
# Layer 2 — local port 8765 bound
# ----------------------------------------------------------------------
echo "[2/5] port 8765 LISTENing?"
if ! lsof -iTCP:8765 -sTCP:LISTEN 2>/dev/null | grep -q LISTEN; then
  echo "  FAIL: nothing listening on 8765"
  echo "  Fix: check ~/Library/Logs/mcp-proxy/stderr.log for startup errors"
  exit 1
fi
echo "  OK"
echo

# ----------------------------------------------------------------------
# Layer 3 — local /mcp endpoint responds
# ----------------------------------------------------------------------
echo "[3/5] local /mcp endpoint responds to initialize?"
LOCAL_RESPONSE=$(curl -sS --max-time 5 -X POST \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","method":"initialize","id":1,"params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"smoke","version":"0.1"}}}' \
  http://127.0.0.1:8765/mcp 2>&1)

if ! echo "$LOCAL_RESPONSE" | grep -q '"protocolVersion"'; then
  echo "  FAIL: local /mcp did not return a valid MCP initialize response"
  echo "  Response: $LOCAL_RESPONSE"
  exit 1
fi
echo "  OK ($(echo "$LOCAL_RESPONSE" | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d.get("result",{}).get("serverInfo",{}).get("name","?"))' 2>/dev/null || echo unknown))"
echo

# ----------------------------------------------------------------------
# Layer 4 — public tunnel URL
# ----------------------------------------------------------------------
if [ -z "$URL_ARG" ]; then
  URL=$(grep "trycloudflare.com" ~/Library/Logs/cloudflared/stderr.log 2>/dev/null | grep -oE "https://[a-z0-9-]+\.trycloudflare\.com" | tail -1)
  if [ -z "$URL" ]; then
    echo "[4/5] FAIL: could not find tunnel URL in ~/Library/Logs/cloudflared/stderr.log"
    echo "Pass the URL explicitly: ./smoke-test.sh https://your-tunnel.trycloudflare.com"
    exit 1
  fi
else
  URL="$URL_ARG"
fi

# Strip /mcp if user pasted full URL, we'll add it back
URL="${URL%/mcp}"
URL="${URL%/sse}"

echo "[4/5] tunnel URL: $URL"
echo

# ----------------------------------------------------------------------
# Layer 5 — full MCP handshake through tunnel
# ----------------------------------------------------------------------
echo "[5/5] full MCP handshake through tunnel..."

HEADERS_FILE=$(mktemp)
curl -sS --max-time 10 -D "$HEADERS_FILE" -X POST \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","method":"initialize","id":1,"params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"smoke","version":"0.1"}}}' \
  -o /tmp/smoke-init.txt \
  "$URL/mcp" > /dev/null

SID=$(grep -i "mcp-session-id" "$HEADERS_FILE" | awk '{print $2}' | tr -d '\r\n')
if [ -z "$SID" ]; then
  echo "  FAIL: no mcp-session-id in tunnel response. Tunnel may be down."
  cat /tmp/smoke-init.txt | head -c 400
  rm -f "$HEADERS_FILE"
  exit 1
fi
rm -f "$HEADERS_FILE"

curl -sS --max-time 5 -X POST \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -H "mcp-session-id: $SID" \
  -d '{"jsonrpc":"2.0","method":"notifications/initialized"}' \
  -o /dev/null \
  "$URL/mcp"

curl -sS --max-time 10 -X POST \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -H "mcp-session-id: $SID" \
  -d '{"jsonrpc":"2.0","method":"tools/list","id":2}' \
  -o /tmp/smoke-tools.txt \
  "$URL/mcp"

python3 - <<'PYEOF' > /tmp/smoke-tools-count.txt 2> /tmp/smoke-tools-list.txt
import json, sys
raw = open("/tmp/smoke-tools.txt").read().strip()
# Strip SSE "data:" framing if present
if raw.startswith("data:"):
    raw = "\n".join(
        ln[5:].lstrip() if ln.startswith("data:") else ln
        for ln in raw.splitlines()
    ).strip()
try:
    d = json.loads(raw)
except Exception as e:
    print(0)
    print(f"  parse error: {e}", file=sys.stderr)
    sys.exit(0)
tools = d.get("result", {}).get("tools", [])
print(len(tools))
for t in tools:
    print(f"  - {t.get('name','?')}", file=sys.stderr)
PYEOF
TOOL_COUNT=$(cat /tmp/smoke-tools-count.txt)

if [ "${TOOL_COUNT:-0}" -gt 0 ]; then
  echo "  OK — $TOOL_COUNT tools discovered through tunnel"
  cat /tmp/smoke-tools-list.txt
  echo
  echo "================================================================"
  echo "  PASS — bridge is healthy end-to-end."
  echo "  Paste this into claude.ai (web or phone) Custom Connector:"
  echo
  echo "     $URL/mcp"
  echo
  echo "================================================================"
  exit 0
else
  echo "  FAIL: tools/list returned no tools"
  cat /tmp/smoke-tools.txt | head -c 400
  exit 1
fi
