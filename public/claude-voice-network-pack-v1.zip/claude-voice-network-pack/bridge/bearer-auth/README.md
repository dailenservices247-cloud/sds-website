# Bearer-auth middleware + OAuth 2.1 gateway (v2)

A Python (`aiohttp`) reverse proxy that sits between cloudflared and mcp-proxy. Two authentication modes supported:

1. **OAuth 2.1** (Claude.ai default) — full Dynamic Client Registration + authorization_code + token endpoints. Claude.ai Custom Connectors authenticate automatically when the user clicks Connect. No manual token paste required.
2. **Bearer token** (fallback / direct use) — the same "master token" you stored in macOS Keychain. Useful for `curl`, testing, or non-OAuth clients.

Both modes reach the same upstream MCP server. The middleware validates whichever credential arrives and forwards to mcp-proxy if valid.

## Why this matters

Without this layer, anyone with your tunnel URL can read/write your vault. With this layer:
- Claude.ai connectors complete OAuth automatically on Connect
- Direct curl users supply the master Keychain token via `Authorization: Bearer <token>`
- Auth failures are logged for forensic review at `~/Library/Logs/mcp-bearer-auth/stderr.log`

## OAuth endpoints implemented (per RFC 8414 / 7591 / 9728)

- `GET  /.well-known/oauth-authorization-server` — Authorization Server Metadata
- `GET  /.well-known/oauth-protected-resource` — Protected Resource Metadata (RFC 9728)
- `POST /register` — Dynamic Client Registration
- `GET  /authorize` — auto-approves authorization codes for single-user local use
- `POST /token` — supports `authorization_code` and `client_credentials` grants
- `GET  /__healthz` — unauthenticated health probe for monitoring

Access tokens are issued with a 30-day TTL (configurable via `MCP_AUTH_TOKEN_TTL` env var).

---

## Architecture

```
Phone Claude.ai
   │ HTTPS  +  Authorization: Bearer <token>
   ▼
Cloudflare edge
   │ HTTPS
   ▼
cloudflared (launchd) → http://127.0.0.1:8766
   │ HTTP  +  Authorization: Bearer <token>
   ▼
mcp-bearer-auth-middleware (launchd) → port 8766
   │ validates header against Keychain
   │ 401 if invalid, forwards if valid
   ▼
mcp-proxy (launchd) → http://127.0.0.1:8765/mcp
   │
   ▼
stdio MCP server
```

The middleware strips the `Authorization` header before forwarding to mcp-proxy (so the MCP server can't see it).

---

## Install (one-time, ~10 min)

### Step 1 — generate a token

```bash
TOKEN=$(openssl rand -hex 32)
echo "$TOKEN"
# Save this somewhere safe (1Password, sticky note, doesn't matter — you'll paste it into claude.ai)
```

### Step 2 — store in Keychain

```bash
security add-generic-password \
  -a "$USER" \
  -s "mcp-bridge-bearer-token" \
  -w "$TOKEN"
```

### Step 3 — install the middleware script

```bash
cp bridge/bearer-auth/middleware.py ~/.local/bin/mcp-bearer-auth-middleware
chmod +x ~/.local/bin/mcp-bearer-auth-middleware
```

### Step 4 — install the launchd plist

```bash
sed "s|YOURUSER|$USER|g; s|YOURNAME|$(whoami | tr 'A-Z' 'a-z')|g" \
  bridge/bearer-auth/com.YOURNAME.mcp-bearer-auth.plist \
  > ~/Library/LaunchAgents/com.$(whoami | tr 'A-Z' 'a-z').mcp-bearer-auth.plist

mkdir -p ~/Library/Logs/mcp-bearer-auth

launchctl bootstrap gui/$(id -u) \
  ~/Library/LaunchAgents/com.$(whoami | tr 'A-Z' 'a-z').mcp-bearer-auth.plist
```

Verify:

```bash
launchctl list | grep mcp-bearer-auth
# Expect a PID, exit code 0
lsof -iTCP:8766 -sTCP:LISTEN
# Expect python3 listening
```

### Step 5 — repoint cloudflared at the middleware

Edit `~/Library/LaunchAgents/com.<your-domain>.cloudflared-mcp.plist`. Change the `--url` value:

```xml
<string>--url</string>
<string>http://127.0.0.1:8766</string>   <!-- was 8765 -->
```

Restart:

```bash
launchctl bootout gui/$(id -u)/com.<your-domain>.cloudflared-mcp
sleep 2
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.<your-domain>.cloudflared-mcp.plist
```

trycloudflare will issue a new URL on this restart (named tunnels don't rotate). Grab it:

```bash
grep "trycloudflare.com" ~/Library/Logs/cloudflared/stderr.log | tail -1
```

### Step 6 — test end-to-end

```bash
URL="https://<new>.trycloudflare.com/mcp"
TOKEN=$(security find-generic-password -a "$USER" -s "mcp-bridge-bearer-token" -w)

# Should return 401
curl -sS -o /dev/null -w "no auth: %{http_code}\n" -X POST "$URL"

# Should return 200 with MCP initialize response
curl -sS --max-time 8 -X POST \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"jsonrpc":"2.0","method":"initialize","id":1,"params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"test","version":"0.1"}}}' \
  "$URL"
```

### Step 7 — update Claude.ai connector

1. claude.ai → Settings → Connectors → your connector → edit
2. **URL:** paste the new tunnel URL from step 5
3. **Authentication:** change from `None` to `API Key` or `Bearer Token` (Claude.ai labels vary)
4. **Token / API Key:** paste the token from step 1
5. Connect

If the tool list shows up, you're done.

---

## Operations

```bash
# Daemon status
launchctl list | grep -E "mcp-proxy|mcp-bearer-auth|cloudflared-mcp"

# All three should show PID + exit code 0

# Live logs
tail -f ~/Library/Logs/mcp-bearer-auth/stderr.log

# Restart middleware (token reload from Keychain)
launchctl kickstart -k gui/$(id -u)/com.<your-domain>.mcp-bearer-auth

# Rotate token
security delete-generic-password -a "$USER" -s "mcp-bridge-bearer-token"
security add-generic-password -a "$USER" -s "mcp-bridge-bearer-token" -w "<new-token>"
launchctl kickstart -k gui/$(id -u)/com.<your-domain>.mcp-bearer-auth
# Then update Claude.ai connector with new token
```

---

## Security notes

**Token rotation policy:** rotate every 90 days or after any suspected leak. Rotation is `delete` + `add` in Keychain + kickstart middleware + update Claude.ai connector. ~3 minutes.

**Token entropy:** 32 bytes (64 hex chars) = 256 bits. Brute-force infeasible.

**Forensic trail:** auth failures land in `~/Library/Logs/mcp-bearer-auth/stderr.log` with timestamp + remote IP + User-Agent. Watch this log for unauthorized access attempts.

**Combine with named subdomain:** for full hardening, also follow `bridge/named-tunnel-setup.md` to swap the trycloudflare URL for `mcp.yourdomain.com`. Same bearer-auth middleware works unchanged.

**What this does NOT do:**
- Per-user authentication (one token = full access; no user accounts)
- IP allowlisting (anyone with the token + URL gets in)
- Rate limiting (if you want this, add it to the middleware or run nginx in front)
- Audit log of successful requests (the middleware logs failures only; for full audit, set access_log=True in the aiohttp app)

For the typical solo-operator use case, bearer-token + named subdomain is sufficient. For multi-user / production use cases, consider Cloudflare Access (Zero Trust) on the named subdomain instead.

---

## Health endpoint

The middleware exposes an unauthenticated `/__healthz` endpoint for monitoring:

```bash
curl https://<your-tunnel>.trycloudflare.com/__healthz
# {"status":"ok"}
```

This is intentionally unauthenticated so external uptime monitors (UptimeRobot, etc.) can probe without leaking the bearer token in monitoring config.
