#!/usr/bin/env python3
# mcp-bearer-auth-middleware
#
# Thin reverse proxy that sits in front of mcp-proxy and enforces
# Authorization: Bearer <token> on every request before forwarding.
#
# Token is loaded from macOS Keychain (service name: mcp-bridge-bearer-token).
# Upstream defaults to http://127.0.0.1:8765 (mcp-proxy's default).
# Listens on 127.0.0.1:8766 by default.
#
# Environment overrides:
#   MCP_AUTH_LISTEN_HOST    default 127.0.0.1
#   MCP_AUTH_LISTEN_PORT    default 8766
#   MCP_AUTH_UPSTREAM_HOST  default 127.0.0.1
#   MCP_AUTH_UPSTREAM_PORT  default 8765
#   MCP_AUTH_KEYCHAIN_SERVICE  default mcp-bridge-bearer-token
#
# Deps: aiohttp. Installed automatically via uvx.
#
# /// script
# requires-python = ">=3.10"
# dependencies = [
#   "aiohttp>=3.9",
# ]
# ///

import asyncio
import logging
import os
import subprocess
import sys
from aiohttp import web, ClientSession, ClientTimeout

LISTEN_HOST = os.environ.get("MCP_AUTH_LISTEN_HOST", "127.0.0.1")
LISTEN_PORT = int(os.environ.get("MCP_AUTH_LISTEN_PORT", "8766"))
UPSTREAM_HOST = os.environ.get("MCP_AUTH_UPSTREAM_HOST", "127.0.0.1")
UPSTREAM_PORT = int(os.environ.get("MCP_AUTH_UPSTREAM_PORT", "8765"))
KEYCHAIN_SERVICE = os.environ.get(
    "MCP_AUTH_KEYCHAIN_SERVICE", "mcp-bridge-bearer-token"
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("mcp-auth")


def load_token_from_keychain() -> str:
    """Pull the bearer token from macOS Keychain. Exits if missing."""
    user = os.environ.get("USER") or os.environ.get("LOGNAME")
    if not user:
        log.error("USER env var not set; cannot query Keychain")
        sys.exit(1)
    try:
        result = subprocess.run(
            ["security", "find-generic-password", "-a", user, "-s", KEYCHAIN_SERVICE, "-w"],
            capture_output=True,
            text=True,
            check=True,
            timeout=5,
        )
        token = result.stdout.strip()
        if not token:
            raise RuntimeError("empty Keychain value")
        log.info(
            "loaded bearer token from Keychain service=%s (len=%d)",
            KEYCHAIN_SERVICE,
            len(token),
        )
        return token
    except subprocess.CalledProcessError as e:
        log.error(
            "Keychain miss: service=%s account=%s stderr=%s",
            KEYCHAIN_SERVICE,
            user,
            e.stderr.strip(),
        )
        log.error(
            "Fix: security add-generic-password -a \"$USER\" -s \"%s\" -w \"<your-token>\"",
            KEYCHAIN_SERVICE,
        )
        sys.exit(1)


BEARER_TOKEN = load_token_from_keychain()
EXPECTED_HEADER = f"Bearer {BEARER_TOKEN}"
UPSTREAM_BASE = f"http://{UPSTREAM_HOST}:{UPSTREAM_PORT}"


async def proxy_handler(request: web.Request) -> web.StreamResponse:
    # Enforce Authorization header
    auth = request.headers.get("Authorization", "")
    if auth != EXPECTED_HEADER:
        log.warning(
            "auth fail: path=%s method=%s remote=%s ua=%s",
            request.path,
            request.method,
            request.remote,
            request.headers.get("User-Agent", "?")[:60],
        )
        return web.Response(status=401, text='{"error":"unauthorized"}', content_type="application/json")

    # Forward to upstream with body + headers (strip Authorization so upstream
    # can't read it; pass everything else including mcp-session-id).
    upstream_url = f"{UPSTREAM_BASE}{request.path_qs}"
    forward_headers = {
        k: v
        for k, v in request.headers.items()
        if k.lower() not in {"authorization", "host"}
    }

    body = await request.read() if request.body_exists else None

    try:
        timeout = ClientTimeout(total=300, sock_read=300)
        async with ClientSession(timeout=timeout) as session:
            async with session.request(
                request.method,
                upstream_url,
                headers=forward_headers,
                data=body,
                allow_redirects=False,
            ) as upstream_resp:
                # Stream response back (SSE/StreamableHTTP support)
                resp = web.StreamResponse(
                    status=upstream_resp.status,
                    headers={
                        k: v
                        for k, v in upstream_resp.headers.items()
                        if k.lower() not in {"content-encoding", "transfer-encoding", "connection"}
                    },
                )
                await resp.prepare(request)
                async for chunk in upstream_resp.content.iter_chunked(8192):
                    await resp.write(chunk)
                await resp.write_eof()
                return resp
    except asyncio.TimeoutError:
        log.error("upstream timeout: %s", upstream_url)
        return web.Response(status=504, text='{"error":"upstream timeout"}', content_type="application/json")
    except Exception as e:
        log.error("upstream error %s: %s", upstream_url, e)
        return web.Response(status=502, text='{"error":"upstream error"}', content_type="application/json")


async def health_handler(request: web.Request) -> web.Response:
    # Unauthenticated health endpoint at /__healthz so monitoring can probe.
    return web.Response(text='{"status":"ok"}', content_type="application/json")


def main() -> None:
    app = web.Application()
    app.router.add_route("GET", "/__healthz", health_handler)
    # Catch-all proxy
    app.router.add_route("*", "/{path:.*}", proxy_handler)

    log.info(
        "mcp-bearer-auth-middleware up: listen=%s:%d upstream=%s",
        LISTEN_HOST,
        LISTEN_PORT,
        UPSTREAM_BASE,
    )
    web.run_app(app, host=LISTEN_HOST, port=LISTEN_PORT, access_log=None)


if __name__ == "__main__":
    main()
