#!/usr/bin/env python3
# mcp-bearer-auth-middleware (v2)
#
# MCP OAuth 2.1 gateway + reverse proxy.
#
# Claude.ai Custom Connectors use MCP OAuth 2.1 (RFC 8414 / RFC 7591 / RFC 9728).
# This middleware implements the minimal server-side OAuth endpoints so Claude.ai
# can authenticate, then proxies validated requests upstream to mcp-proxy.
#
# Supported grant types:
#   authorization_code  — browser-based flow (Claude.ai "Claude-User" UA)
#   client_credentials  — machine-to-machine (some automated clients)
#
# The "master" bearer token (loaded from macOS Keychain) is also accepted directly
# on /mcp requests for backward-compat and for Dailen's own curl/test use.
#
# All OAuth state is in-memory. Restart = all clients re-register (Claude.ai
# handles this transparently via Dynamic Client Registration on reconnect).
#
# /// script
# requires-python = ">=3.10"
# dependencies = [
#   "aiohttp>=3.9",
# ]
# ///

import asyncio
import hashlib
import json
import logging
import os
import secrets
import subprocess
import sys
import time
import urllib.parse
from aiohttp import web, ClientSession, ClientTimeout

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
LISTEN_HOST = os.environ.get("MCP_AUTH_LISTEN_HOST", "127.0.0.1")
LISTEN_PORT = int(os.environ.get("MCP_AUTH_LISTEN_PORT", "8766"))
UPSTREAM_HOST = os.environ.get("MCP_AUTH_UPSTREAM_HOST", "127.0.0.1")
UPSTREAM_PORT = int(os.environ.get("MCP_AUTH_UPSTREAM_PORT", "8765"))
KEYCHAIN_SERVICE = os.environ.get("MCP_AUTH_KEYCHAIN_SERVICE", "mcp-bridge-bearer-token")
PUBLIC_BASE_URL = os.environ.get("MCP_AUTH_PUBLIC_BASE_URL", "https://mcp.synapsedynamics.io")
TOKEN_TTL = int(os.environ.get("MCP_AUTH_TOKEN_TTL", "2592000"))  # 30 days (was 3600 = 1 hr, too short for Claude.ai connectors)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("mcp-oauth")

# ---------------------------------------------------------------------------
# Keychain
# ---------------------------------------------------------------------------
def load_master_token() -> str:
    user = os.environ.get("USER") or os.environ.get("LOGNAME")
    if not user:
        log.error("USER env var not set")
        sys.exit(1)
    try:
        result = subprocess.run(
            ["security", "find-generic-password", "-a", user, "-s", KEYCHAIN_SERVICE, "-w"],
            capture_output=True, text=True, check=True, timeout=5,
        )
        token = result.stdout.strip()
        if not token:
            raise RuntimeError("empty Keychain value")
        log.info("loaded master token from Keychain service=%s (len=%d)", KEYCHAIN_SERVICE, len(token))
        return token
    except subprocess.CalledProcessError as e:
        log.error("Keychain miss: service=%s stderr=%s", KEYCHAIN_SERVICE, e.stderr.strip())
        sys.exit(1)

MASTER_TOKEN = load_master_token()
UPSTREAM_BASE = f"http://{UPSTREAM_HOST}:{UPSTREAM_PORT}"

# ---------------------------------------------------------------------------
# In-memory OAuth state
# ---------------------------------------------------------------------------
# clients[client_id] = {client_secret, redirect_uris, name}
clients: dict[str, dict] = {}
# auth_codes[code] = {client_id, redirect_uri, expires_at, code_verifier}
auth_codes: dict[str, dict] = {}
# access_tokens[token] = {client_id, expires_at}
access_tokens: dict[str, dict] = {}


def new_token(client_id: str) -> str:
    token = secrets.token_hex(32)
    access_tokens[token] = {"client_id": client_id, "expires_at": time.time() + TOKEN_TTL}
    log.info("issued access token for client_id=%s", client_id)
    return token


def validate_token(auth_header: str) -> bool:
    """Accept master token OR any issued OAuth access token."""
    if auth_header == f"Bearer {MASTER_TOKEN}":
        return True
    if auth_header.startswith("Bearer "):
        tok = auth_header[7:]
        entry = access_tokens.get(tok)
        if entry and entry["expires_at"] > time.time():
            return True
    return False

# ---------------------------------------------------------------------------
# OAuth endpoints
# ---------------------------------------------------------------------------

async def protected_resource_meta(request: web.Request) -> web.Response:
    """RFC 9728 — OAuth 2.0 Protected Resource Metadata."""
    return web.Response(
        content_type="application/json",
        text=json.dumps({
            "resource": f"{PUBLIC_BASE_URL}/mcp",
            "authorization_servers": [PUBLIC_BASE_URL],
            "bearer_methods_supported": ["header"],
            "resource_documentation": f"{PUBLIC_BASE_URL}/__healthz",
        }),
    )


async def auth_server_meta(request: web.Request) -> web.Response:
    """RFC 8414 — OAuth 2.0 Authorization Server Metadata."""
    return web.Response(
        content_type="application/json",
        text=json.dumps({
            "issuer": PUBLIC_BASE_URL,
            "authorization_endpoint": f"{PUBLIC_BASE_URL}/authorize",
            "token_endpoint": f"{PUBLIC_BASE_URL}/token",
            "registration_endpoint": f"{PUBLIC_BASE_URL}/register",
            "response_types_supported": ["code"],
            "grant_types_supported": ["authorization_code", "client_credentials"],
            "code_challenge_methods_supported": ["S256", "plain"],
            "token_endpoint_auth_methods_supported": ["client_secret_post", "client_secret_basic", "none"],
            "scopes_supported": ["mcp"],
        }),
    )


async def register_client(request: web.Request) -> web.Response:
    """RFC 7591 — Dynamic Client Registration."""
    try:
        body = await request.json()
    except Exception:
        body = {}

    client_id = secrets.token_hex(16)
    client_secret = secrets.token_hex(32)
    redirect_uris = body.get("redirect_uris", [])
    clients[client_id] = {
        "client_secret": client_secret,
        "redirect_uris": redirect_uris,
        "name": body.get("client_name", "unknown"),
    }
    log.info("registered client_id=%s name=%s", client_id, clients[client_id]["name"])
    return web.Response(
        status=201,
        content_type="application/json",
        text=json.dumps({
            "client_id": client_id,
            "client_secret": client_secret,
            "client_id_issued_at": int(time.time()),
            "client_secret_expires_at": 0,  # never expires
            "redirect_uris": redirect_uris,
            "grant_types": ["authorization_code", "client_credentials"],
            "response_types": ["code"],
            "token_endpoint_auth_method": "client_secret_post",
        }),
    )


async def authorize(request: web.Request) -> web.Response:
    """Authorization endpoint — auto-approves for single-user local use."""
    params = request.rel_url.query
    client_id = params.get("client_id", "")
    redirect_uri = params.get("redirect_uri", "")
    state = params.get("state", "")
    code_challenge = params.get("code_challenge", "")
    code_challenge_method = params.get("code_challenge_method", "plain")

    if client_id not in clients:
        return web.Response(status=400, text="unknown client_id")

    # Auto-approve: generate authorization code immediately
    code = secrets.token_hex(24)
    auth_codes[code] = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "expires_at": time.time() + 300,  # 5 min
        "code_challenge": code_challenge,
        "code_challenge_method": code_challenge_method,
    }
    log.info("issued auth code for client_id=%s redirect_uri=%s", client_id, redirect_uri[:80])

    # Redirect back to client with code
    redirect_params = {"code": code}
    if state:
        redirect_params["state"] = state
    redirect_url = redirect_uri + ("&" if "?" in redirect_uri else "?") + urllib.parse.urlencode(redirect_params)

    # Show a simple approval page first (some clients expect user interaction)
    # Immediately meta-refresh to avoid needing user click
    html = f"""<!DOCTYPE html>
<html><head>
<title>MCP Bridge — Authorized</title>
<meta http-equiv="refresh" content="0;url={redirect_url}">
</head><body>
<p>Authorized. Redirecting...</p>
<p><a href="{redirect_url}">Click here if not redirected.</a></p>
</body></html>"""
    return web.Response(content_type="text/html", text=html)


async def token_endpoint(request: web.Request) -> web.Response:
    """Token endpoint — authorization_code and client_credentials flows."""
    content_type = request.headers.get("Content-Type", "")
    if "json" in content_type:
        body = await request.json()
    else:
        raw = await request.text()
        body = dict(urllib.parse.parse_qsl(raw))

    grant_type = body.get("grant_type", "")

    if grant_type == "client_credentials":
        client_id = body.get("client_id", "")
        client_secret = body.get("client_secret", "")
        client = clients.get(client_id)
        if not client or client["client_secret"] != client_secret:
            return web.Response(status=401, content_type="application/json",
                                text='{"error":"invalid_client"}')
        token = new_token(client_id)
        return web.Response(content_type="application/json", text=json.dumps({
            "access_token": token, "token_type": "bearer", "expires_in": TOKEN_TTL,
        }))

    if grant_type == "authorization_code":
        code = body.get("code", "")
        client_id = body.get("client_id", "")
        redirect_uri = body.get("redirect_uri", "")
        code_verifier = body.get("code_verifier", "")

        code_entry = auth_codes.pop(code, None)
        if not code_entry:
            return web.Response(status=400, content_type="application/json",
                                text='{"error":"invalid_grant","error_description":"unknown or expired code"}')
        if code_entry["expires_at"] < time.time():
            return web.Response(status=400, content_type="application/json",
                                text='{"error":"invalid_grant","error_description":"code expired"}')
        if code_entry["client_id"] != client_id:
            return web.Response(status=400, content_type="application/json",
                                text='{"error":"invalid_grant","error_description":"client_id mismatch"}')

        # Verify PKCE if challenge was provided
        challenge = code_entry.get("code_challenge", "")
        method = code_entry.get("code_challenge_method", "plain")
        if challenge and code_verifier:
            if method == "S256":
                digest = hashlib.sha256(code_verifier.encode()).digest()
                import base64
                computed = base64.urlsafe_b64encode(digest).rstrip(b"=").decode()
                if computed != challenge:
                    return web.Response(status=400, content_type="application/json",
                                        text='{"error":"invalid_grant","error_description":"PKCE verification failed"}')
            elif challenge != code_verifier:
                return web.Response(status=400, content_type="application/json",
                                    text='{"error":"invalid_grant","error_description":"PKCE verification failed"}')

        token = new_token(client_id)
        return web.Response(content_type="application/json", text=json.dumps({
            "access_token": token, "token_type": "bearer", "expires_in": TOKEN_TTL,
        }))

    return web.Response(status=400, content_type="application/json",
                        text=f'{{"error":"unsupported_grant_type","error_description":"{grant_type}"}}')


# ---------------------------------------------------------------------------
# Proxy
# ---------------------------------------------------------------------------

async def proxy_handler(request: web.Request) -> web.StreamResponse:
    auth = request.headers.get("Authorization", "")
    if not validate_token(auth):
        log.warning("auth fail: path=%s method=%s ua=%s",
                    request.path, request.method,
                    request.headers.get("User-Agent", "?")[:60])
        return web.Response(
            status=401,
            content_type="application/json",
            text='{"error":"unauthorized"}',
            headers={
                "WWW-Authenticate": f'Bearer realm="mcp", resource_metadata="{PUBLIC_BASE_URL}/.well-known/oauth-protected-resource"'
            },
        )

    upstream_url = f"{UPSTREAM_BASE}{request.path_qs}"
    forward_headers = {
        k: v for k, v in request.headers.items()
        if k.lower() not in {"authorization", "host"}
    }
    body = await request.read() if request.body_exists else None

    try:
        timeout = ClientTimeout(total=300, sock_read=300)
        async with ClientSession(timeout=timeout) as session:
            async with session.request(
                request.method, upstream_url,
                headers=forward_headers, data=body, allow_redirects=False,
            ) as upstream_resp:
                resp = web.StreamResponse(
                    status=upstream_resp.status,
                    headers={
                        k: v for k, v in upstream_resp.headers.items()
                        if k.lower() not in {"content-encoding", "transfer-encoding", "connection"}
                    },
                )
                await resp.prepare(request)
                async for chunk in upstream_resp.content.iter_chunked(8192):
                    await resp.write(chunk)
                await resp.write_eof()
                return resp
    except asyncio.TimeoutError:
        return web.Response(status=504, content_type="application/json", text='{"error":"upstream timeout"}')
    except Exception as e:
        log.error("upstream error %s: %s", upstream_url, e)
        return web.Response(status=502, content_type="application/json", text='{"error":"upstream error"}')


async def health_handler(request: web.Request) -> web.Response:
    return web.Response(content_type="application/json", text='{"status":"ok"}')


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

def main() -> None:
    app = web.Application()
    # OAuth endpoints (unauthenticated)
    app.router.add_route("GET",  "/.well-known/oauth-protected-resource", protected_resource_meta)
    app.router.add_route("GET",  "/.well-known/oauth-protected-resource/{tail:.*}", protected_resource_meta)
    app.router.add_route("GET",  "/.well-known/oauth-authorization-server", auth_server_meta)
    app.router.add_route("POST", "/register", register_client)
    app.router.add_route("GET",  "/authorize", authorize)
    app.router.add_route("POST", "/token", token_endpoint)
    app.router.add_route("GET",  "/__healthz", health_handler)
    # Catch-all — proxy (requires valid token)
    app.router.add_route("*", "/{path:.*}", proxy_handler)

    log.info("mcp-oauth-gateway up: listen=%s:%d upstream=%s public=%s",
             LISTEN_HOST, LISTEN_PORT, UPSTREAM_BASE, PUBLIC_BASE_URL)
    web.run_app(app, host=LISTEN_HOST, port=LISTEN_PORT, access_log=None)


if __name__ == "__main__":
    main()
