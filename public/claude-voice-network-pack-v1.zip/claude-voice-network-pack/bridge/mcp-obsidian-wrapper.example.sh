#!/bin/bash
# Example wrapper: cyanheads/obsidian-mcp-server (v3.2.1+).
#
# This is the worked example for Obsidian. It exposes your TAOO-Vault (or
# whatever Obsidian vault) via the Local REST API plugin to Claude.ai mobile.
#
# Setup before this script will work:
#   1. Install the Obsidian Local REST API community plugin
#      (Settings > Community plugins > "Local REST API" by Adam Coddington)
#   2. Enable it. Copy the API key shown in the plugin settings.
#   3. Save the key to macOS Keychain:
#        security add-generic-password \
#          -a "$USER" \
#          -s "obsidian-rest-api-key" \
#          -w "<paste-the-key-here>"
#   4. Install the obsidian-mcp-server package:
#        npx -y obsidian-mcp-server --version
#      (the first run downloads + caches it; note the install path it prints)
#   5. Update MCP_SERVER_BINARY below to your install path.
#   6. Make this file executable: chmod +x ~/.local/bin/mcp-obsidian-wrapper

# Pull API key from macOS Keychain
export OBSIDIAN_API_KEY=$(security find-generic-password -a "$USER" -s "obsidian-rest-api-key" -w 2>/dev/null)

# cyanheads server expects OBSIDIAN_BASE_URL (NOT OBSIDIAN_API_URL)
export OBSIDIAN_BASE_URL="https://127.0.0.1:27124"

# Obsidian Local REST API plugin serves HTTPS with a self-signed cert.
# Node fetch() rejects it by default with "Error: fetch failed".
# Loopback only, so cert verification adds no real security here.
export OBSIDIAN_VERIFY_SSL=false
export NODE_TLS_REJECT_UNAUTHORIZED=0

if [ -z "$OBSIDIAN_API_KEY" ]; then
  echo "mcp-obsidian-wrapper: failed to load obsidian-rest-api-key from Keychain" >&2
  echo "Fix: security add-generic-password -a \"\$USER\" -s \"obsidian-rest-api-key\" -w \"<your-plugin-key>\"" >&2
  exit 1
fi

# Update this path to wherever npx cached the obsidian-mcp-server package.
# Find it with: ls -la $(npm root -g 2>/dev/null) || find ~/.npm-cache -name "obsidian-mcp-server" -type d 2>/dev/null
MCP_SERVER_BINARY="/Users/$USER/.npm-cache-clean/_npx/<HASH>/node_modules/obsidian-mcp-server/dist/index.js"

exec "$MCP_SERVER_BINARY" "$@"
