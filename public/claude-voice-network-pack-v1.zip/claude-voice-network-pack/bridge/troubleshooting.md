# Troubleshooting — Bridge silent-failure library

Seven distinct failure modes the build team hit while shipping this stack. Each is documented with: the symptom you see, the actual root cause, and the fix.

Run `./bridge/smoke-test.sh` first — it isolates which layer is broken before you start guessing.

---

## 1. "Error: fetch failed" on every tool call

**Symptom:** Tunnel up, daemons up, smoke-test layers 1-4 pass. Tool calls return:
```json
{"content":[{"type":"text","text":"Error: fetch failed"}],"isError":true}
```

**Root cause:** Obsidian Local REST API plugin (or any local HTTPS service) serves a self-signed cert. Node `fetch()` in the MCP server child rejects the cert by default. Generic error message hides the root cause.

**Fix:** add to your wrapper script BEFORE the `exec` line:

```bash
export NODE_TLS_REJECT_UNAUTHORIZED=0
export OBSIDIAN_VERIFY_SSL=false   # if your server reads this too
```

Then `launchctl kickstart -k gui/$(id -u)/com.<your>.mcp-proxy` to respawn child with new env.

**Why it's safe:** localhost loopback. No network path for a MITM. Cert verification adds no real security on 127.0.0.1.

---

## 2. Claude.ai connector won't connect — "unable to handshake"

**Symptom:** Add Custom Connector → paste URL → Connect → spinner forever, then "couldn't reach server" or similar. Smoke test passes from your shell.

**Root cause:** URL path. Claude.ai Custom Connectors use **StreamableHTTP** transport, served at `/mcp`. The older SSE transport at `/sse` exists in mcp-proxy but Claude.ai's handshake fails against it.

**Fix:** ensure the URL ends in `/mcp`, NOT `/sse`:

```
https://your-tunnel.trycloudflare.com/mcp   ✓
https://your-tunnel.trycloudflare.com/sse   ✗
https://your-tunnel.trycloudflare.com       ✗ (root returns 404)
```

Edit the connector, fix the URL, re-connect.

---

## 3. mcp-proxy starts but can't find uvx / wrapper / binary

**Symptom:** `~/Library/Logs/mcp-proxy/stderr.log` shows:
```
No such file or directory: uvx
```

or:

```
mcp-wrapper: command not found
```

**Root cause:** launchd starts the process with a near-empty environment. Your shell's `PATH` doesn't apply.

**Fix:** plists must (a) use **absolute paths** to every binary, (b) explicitly set `PATH` in `EnvironmentVariables`:

```xml
<key>EnvironmentVariables</key>
<dict>
    <key>PATH</key>
    <string>/Users/YOURUSER/.local/bin:/usr/local/bin:/usr/bin:/bin</string>
    <key>HOME</key>
    <string>/Users/YOURUSER</string>
</dict>
```

The pack's plist templates already do this. If you wrote your own, double-check.

---

## 4. Wrapper fails: "failed to load <service> from Keychain"

**Symptom:** mcp-proxy log shows your wrapper's error message about Keychain miss. But `security find-generic-password` works from your shell.

**Root cause one:** the Keychain entry wasn't created with `-a "$USER"` — the wrapper looks it up with `-a "$USER"` so account name has to match.

**Fix one:** verify with:

```bash
security find-generic-password -a "$USER" -s "<service-name>"
```

If "specified item not in Keychain" — recreate with matching `-a`:

```bash
security add-generic-password -a "$USER" -s "<service-name>" -w "<value>"
```

**Root cause two:** Keychain locked. If you're remote-screen-sharing with no GUI session, the login keychain may be locked.

**Fix two:** unlock the keychain at boot (login keychain unlocks automatically when you log in with the GUI). If you're running headless, consider `security unlock-keychain` in a LaunchAgent that runs before your bridge.

---

## 5. Tunnel URL rotated, claude.ai can't reach server

**Symptom:** Was working yesterday. This morning, claude.ai tool calls return fetch errors or "connector offline."

**Root cause:** trycloudflare URLs rotate each time `cloudflared` restarts. Restart triggers: Mac reboot, cloudflared crash, manual kickstart, network connectivity blip causing extended outage.

**Fix:**

```bash
# Get current URL
grep "trycloudflare.com" ~/Library/Logs/cloudflared/stderr.log | tail -1
```

Then claude.ai → Settings → Connectors → your connector → edit URL → save.

**Permanent fix:** named tunnel with your own subdomain. See `named-tunnel-setup.md`. Costs nothing on Cloudflare free tier (DNS only), gives you a stable URL like `mcp.yourdomain.com` that never rotates.

---

## 6. Claude.ai sees old tool names — "tool not found"

**Symptom:** You changed your wrapper to a different MCP server (e.g. switched packages). Smoke test shows new tool names. But claude.ai keeps trying to call the OLD tool names and gets "tool not found."

**Root cause:** Claude.ai's mobile client (and sometimes web) caches the tool schema per connector. Toggling off/on does NOT clear cache. You must **delete + recreate** the connector.

**Fix:**

1. claude.ai → Settings → Connectors → your connector → **delete** (trash icon, not toggle)
2. Add Custom → paste same URL → Connect again
3. New tool schema loads
4. If using a Project that referenced old tool names in its system instructions, re-upload the updated system instructions to the Project knowledge

---

## 7. Wrong-package endpoint paths — every tool returns 404

**Symptom:** Smoke test passes through layer 4. Tool calls return:
```json
{"content":[{"type":"text","text":"Error: API request failed: 404 Not Found"}],"isError":true}
```

**Root cause:** The MCP server package you're using hits invented REST API paths that don't exist in the target service. We hit this with `obsidian-local-rest-api-mcp` (an early package) which calls `/vault/notes/recent`, `/vault/notes/daily`, etc. The Obsidian Local REST API plugin doesn't expose those endpoints (real endpoints are `/vault/`, `/periodic/daily/`, `/search/`).

**Fix:** swap to a known-working MCP server package. For Obsidian: **`obsidian-mcp-server` by cyanheads** is the same package Claude Desktop uses successfully. Update your wrapper:

```bash
MCP_SERVER_BINARY=/path/to/obsidian-mcp-server/dist/index.js
```

Generally: when picking an MCP server for a service, prefer one that's actively maintained, has releases in the last 60 days, and shows real usage in Claude Desktop's `claude_desktop_config.json` examples.

---

## Diagnostic flow

When something breaks, do this in order:

1. `./bridge/smoke-test.sh` — which layer is red?
2. `tail -30 ~/Library/Logs/mcp-proxy/stderr.log` — wrapper / child errors?
3. `tail -30 ~/Library/Logs/cloudflared/stderr.log` — tunnel handshake / connectivity errors?
4. `launchctl list | grep -E "mcp-proxy|cloudflared-mcp"` — daemons in column-2 exit code 0?
5. `curl -sS http://127.0.0.1:8765/mcp -X POST -H 'Content-Type: application/json' -d '{"jsonrpc":"2.0","method":"initialize","id":1,"params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"diag","version":"0.1"}}}'` — local response sane?
6. Same curl against the tunnel URL — does the cloudflared edge proxy through?

Whichever step first fails is where the bug lives.
