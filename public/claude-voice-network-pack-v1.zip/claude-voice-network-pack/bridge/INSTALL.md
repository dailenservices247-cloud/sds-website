# Bridge install — Claude Voice Network Pack

Expose any stdio-based MCP server on your Mac to Claude.ai mobile (voice mode included) via launchd + cloudflared. ~20 min wall-clock for the Obsidian example.

This guide walks the Obsidian Local REST API path. For any other stdio MCP, swap the wrapper script's MCP_SERVER_BINARY + Keychain service name. The launchd plists do not change.

---

## Prerequisites

1. **macOS** (this pack is Mac-only — launchd is Mac-specific)
2. **uv / uvx** — `curl -LsSf https://astral.sh/uv/install.sh | sh`
3. **cloudflared** — [download binary](https://developers.cloudflare.com/cloudflared/install/) to `~/.local/bin/cloudflared` + `chmod +x`
4. **Obsidian** with the **Local REST API** community plugin installed and enabled (for the worked example)
5. A Claude.ai account on web + phone (same account, sync via cloud)

---

## 5-step install

### Step 1 — save the MCP server's API key to Keychain

Don't hardcode secrets in plists. Use macOS Keychain.

```bash
# Obsidian example. Replace 'obsidian-rest-api-key' with the service name
# you want and paste the actual key when prompted.
security add-generic-password \
  -a "$USER" \
  -s "obsidian-rest-api-key" \
  -w "<PASTE-YOUR-PLUGIN-API-KEY-HERE>"
```

Verify:

```bash
security find-generic-password -a "$USER" -s "obsidian-rest-api-key" -w
```

Should print the key.

### Step 2 — install the wrapper script

```bash
mkdir -p ~/.local/bin
cp bridge/mcp-obsidian-wrapper.example.sh ~/.local/bin/mcp-obsidian-wrapper
chmod +x ~/.local/bin/mcp-obsidian-wrapper
```

Edit `~/.local/bin/mcp-obsidian-wrapper` and update `MCP_SERVER_BINARY` to the path where `obsidian-mcp-server` is installed. Find it with:

```bash
npx -y obsidian-mcp-server --version
# Note the path. Common: /Users/$USER/.npm-cache-clean/_npx/<hash>/node_modules/obsidian-mcp-server/dist/index.js
```

### Step 3 — install the launchd plists

```bash
# Replace YOURUSER + YOURNAME in both files before copying
sed "s|YOURUSER|$USER|g; s|YOURNAME|$(whoami | tr 'A-Z' 'a-z')|g" \
  bridge/plists/com.YOURNAME.mcp-proxy.plist \
  > ~/Library/LaunchAgents/com.$(whoami | tr 'A-Z' 'a-z').mcp-proxy.plist

sed "s|YOURUSER|$USER|g; s|YOURNAME|$(whoami | tr 'A-Z' 'a-z')|g" \
  bridge/plists/com.YOURNAME.cloudflared-mcp.plist \
  > ~/Library/LaunchAgents/com.$(whoami | tr 'A-Z' 'a-z').cloudflared-mcp.plist
```

### Step 4 — bootstrap both agents

```bash
mkdir -p ~/Library/Logs/mcp-proxy ~/Library/Logs/cloudflared

launchctl bootstrap gui/$(id -u) \
  ~/Library/LaunchAgents/com.$(whoami | tr 'A-Z' 'a-z').mcp-proxy.plist

launchctl bootstrap gui/$(id -u) \
  ~/Library/LaunchAgents/com.$(whoami | tr 'A-Z' 'a-z').cloudflared-mcp.plist
```

Both should show up under launchctl list within 10-15 sec:

```bash
launchctl list | grep -E "mcp-proxy|cloudflared-mcp"
# Expect two lines, exit code 0 in column 2
```

### Step 5 — get the public URL + run smoke test

```bash
# Get URL
grep "trycloudflare.com" ~/Library/Logs/cloudflared/stderr.log | tail -1

# Or run the full smoke test (auto-detects URL):
./bridge/smoke-test.sh
```

Output ends with:

```
PASS — bridge is healthy end-to-end.
Paste this into claude.ai (web or phone) Custom Connector:

   https://<your-words>.trycloudflare.com/mcp
```

---

## Wire to Claude.ai

1. **claude.ai web** (easier than phone for the first-time setup) → Settings → Connectors → **Add Custom**
2. **Name:** anything (e.g. `Obsidian Vault`)
3. **Server URL:** the URL from step 5 — **must end in `/mcp`** (not `/sse`)
4. **Authentication:** None
5. **Connect**. Claude.ai will discover the tools. For Obsidian you should see 12 tools (`obsidian_get_note`, `obsidian_list_notes`, etc.)
6. The connector syncs to phone Claude.ai automatically. Open phone → any Project → tools available.

---

## URL stability

The trycloudflare URL persists until `cloudflared` restarts. Restarts happen on:

- Mac reboot
- cloudflared crash (rare; launchd auto-restarts but URL rotates)
- Manual `launchctl kickstart -k`

If URL changes, get new one via:

```bash
grep "trycloudflare.com" ~/Library/Logs/cloudflared/stderr.log | tail -1
```

Then update claude.ai → Connectors → edit URL.

For a **permanent URL** (`mcp.<yourdomain>.com`), see `named-tunnel-setup.md`.

---

## Adding more MCP servers

You can run multiple bridges. Each one needs its own port + its own launchd plist pair + its own tunnel URL.

Suggested ports:

| Server | Port |
|---|---|
| Obsidian | 8765 |
| Stripe | 8766 |
| GitHub | 8767 |
| Supabase | 8768 |
| Custom #1 | 8770 |

For each: copy the wrapper + 2 plists, change ports + Label + paths, bootstrap. Each bridge gets its own trycloudflare URL.

To minimize cost (1 tunnel = 1 Cloudflare conn per server is fine on free tier) consider a single named tunnel with ingress rules routing different paths to different ports. See `named-tunnel-setup.md`.

---

## Operations

```bash
# Live logs
tail -f ~/Library/Logs/mcp-proxy/stderr.log
tail -f ~/Library/Logs/cloudflared/stderr.log

# Restart one daemon (rotates tunnel URL!)
launchctl kickstart -k gui/$(id -u)/com.<your>.cloudflared-mcp

# Stop everything
launchctl bootout gui/$(id -u)/com.<your>.cloudflared-mcp
launchctl bootout gui/$(id -u)/com.<your>.mcp-proxy

# Start everything
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.<your>.mcp-proxy.plist
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.<your>.cloudflared-mcp.plist
```

---

## Security note

The trycloudflare URL has **no built-in authentication.** Anyone with the URL can read/write your vault. Mitigations:

1. URL is a 4-random-word subdomain (~30 bits entropy)
2. Cloudflare doesn't expose a discovery API
3. URL is only stored: this README copy, your launchd log file, claude.ai connector config

If the URL leaks (screenshot, paste in a public chat, log file shared), an attacker could enumerate the vault. To rotate: `launchctl kickstart -k` cloudflared, capture new URL, update claude.ai.

**Permanent hardening — SHIPPED IN v1.0 (recommended for all installs):**

- `bridge/bearer-auth/` — ~10-min add-on. Bearer-token middleware in front of mcp-proxy. Token stored in macOS Keychain. Claude.ai connector supports `Authorization: Bearer <token>` natively. After install: an attacker needs the URL AND a 256-bit token to read your vault.
- `bridge/named-tunnel-setup.md` — eliminates URL rotation pain. Permanent `mcp.<yourdomain>.com` URL.

Combine both for the production-grade install.

---

## Trouble?

Read `troubleshooting.md`. Covers all 7 silent-failure modes I hit while building this:

1. Self-signed TLS cert rejection ("fetch failed")
2. Transport mismatch (`/sse` vs `/mcp`)
3. launchd-spawned env stripped of PATH
4. Keychain unlock state under launchd
5. Tunnel URL rotation on restart
6. Tool-name schema cache in Claude.ai client
7. Wrong-package endpoint paths (404 on every tool)
